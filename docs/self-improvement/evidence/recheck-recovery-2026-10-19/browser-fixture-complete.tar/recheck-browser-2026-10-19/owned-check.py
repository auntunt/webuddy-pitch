
import json,os,pathlib,signal,subprocess,sys,time
action=sys.argv[1]; control=pathlib.Path(sys.argv[2]); cwd=pathlib.Path.cwd()
if action=='child':
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    (control/'child.json').write_text(json.dumps({'pid':os.getpid(),'pgid':os.getpgrp(),'cwd':str(cwd)}))
    while True:time.sleep(.03)
text=(cwd/'app.py').read_text()
assert text in ('VALUE = 0\n','VALUE = 1\n'),repr(text)
value=1 if '1' in text else 0
with (control/'commands.jsonl').open('a') as f:
    f.write(json.dumps({'action':action,'value':value,'cwd':str(cwd),'pid':os.getpid()})+'\n')
if action=='test' and value==1 and (control/'hold').exists():
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    (control/'leader.json').write_text(json.dumps({'pid':os.getpid(),'pgid':os.getpgrp(),'cwd':str(cwd)}))
    subprocess.Popen([sys.executable,__file__,'child',str(control)])
    os.write(1,b'recheck-candidate-started\x00\xff\n')
    while True:time.sleep(.03)
print('REAL_CHECK '+json.dumps({'action':action,'value':value,'cwd':str(cwd)}),flush=True)
