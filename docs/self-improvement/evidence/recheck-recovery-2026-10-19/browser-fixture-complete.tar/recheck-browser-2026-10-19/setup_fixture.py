"""Prepare only. --serve explicitly starts the isolated browser service on 8797.

No model or human review is simulated. Original checks are real local commands;
the candidate code and requirement are labelled synthetic. No recheck operation
starts until the browser operator explicitly presses the recheck button.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import socket
import subprocess
import sys

DATA = Path(__file__).resolve().parent
REPO = DATA.parents[1]
ROOT = DATA / "project"
sys.path.insert(0, str(REPO))


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True, stderr=subprocess.STDOUT).strip()


def setup():
    from tests.test_recheck_crash_independent import WORKER
    from tmh import config
    from tmh.platform import fixloop, signoff
    from tmh.platform.agents import make_worktree, worktree_diff
    from tmh.platform.server import Platform
    from tmh.platform.store import now

    if (DATA / "platform.db").exists() or ROOT.exists():
        raise RuntimeError("Refusing to overwrite prepared fixture data")
    save(DATA / "autoflow.json", {"on": False, "commit": False, "check_timeout": 120, "recheck_timeout": 120, "rounds": 0})
    worker = DATA / "owned-check.py"
    worker.write_text(WORKER, encoding="utf-8")
    # This custom agent is intentionally not launched; only the configured build
    # and test commands run during this fixture and browser recheck.
    save(DATA / "agents.json", {"local-fixture": {"title": "本地合成检查器（不调用模型）", "timeout": 120,
        "cmd": [sys.executable, str(worker), "build", str(DATA)]}})
    ROOT.mkdir()
    (ROOT / "app.py").write_text("VALUE = 0\n")
    (ROOT / ".gitignore").write_text("__pycache__/\n")
    (ROOT / "README.md").write_text("# 独立重新验证浏览器夹具\n\n合成候选代码；没有真实客户、模型调用、人工复核、签收或发布。\n")
    conf = config.load(ROOT)
    conf["commands"].update({kind: shlex.join([sys.executable, str(worker), kind, str(DATA)]) for kind in ("build", "test")})
    config.save(ROOT, conf)
    git("init", "-q")
    git("config", "user.name", "Webuddy synthetic recheck fixture")
    git("config", "user.email", "fixture@localhost")
    git("add", ".")
    git("commit", "-qm", "Synthetic local recheck fixture baseline")

    P = Platform(DATA, user="合成验证准备")
    try:
        project = P.store.add_project("RECHK", "重新验证中断恢复 · 合成验收", str(ROOT))
        body = ("这是隔离的合成浏览器验收事项，没有真实客户或模型调用。\n"
                "原候选 app.py 的 VALUE = 1 已由真实本地 build/test 命令检查。\n"
                "下一次重新验证会在 test 过程中等待 hold 控制文件；浏览器点击后才启动进程。"
                "操作人将强杀自己拥有的平台服务，再重启相同目录。\n"
                "验收观察：原实现运行保持 done，新的验证过程单独记录中断；旧通过结果不能冒充当前有效结论；"
                "进程回执完整后，删除 hold 再显式重新验证才能生成新的当前检查。\n"
                "本夹具不创建人工复核、客户签收或发布记录。")
        ticket = P.store.create_ticket(project["id"], "原实现完成后重新验证遇到服务中断（合成验收）", "合成验证准备", body=body, auto=False)
        prompt = "【合成原始任务，完整保留】\n" + body + "\n要求只将 app.py 的 VALUE 从 0 改成 1，不提交，不合并，不签收。\n完整原始提示词末尾。"
        row = P.store.create_run(project["id"], ticket["id"], "local-fixture", "fix", "合成验证准备", prompt)
        rid = row["id"]
        wt, branch = make_worktree(DATA, project, ticket, rid)
        (wt / "app.py").write_text("VALUE = 1\n")
        P.runner._control(rid, {"local-fixture": {"timeout": 120}}, "local-fixture")
        P.store.update_run(rid, status="running", started=now(), workdir=str(wt), diff=worktree_diff(wt))
        checked = fixloop.recheck(P.runner, rid, allow_running=True)
        assert checked["check"] == "pass" and len(checked["commands"]) == 2, checked
        P.runner.finish_invocation(rid, 0,
            "【合成原实现已结束】候选 VALUE = 1 已执行本地 build/test，两条命令均退出 0。\n"
            "没有调用模型，没有人工复核、客户验收、合并或发布。\n完整原运行结论末尾。")
        source = P.store.run(rid)
        assert source["status"] == "done" and source["exit_code"] == 0
        P.store.update_ticket(ticket["id"], "合成验证准备", status="verify")
        ticket = P.store.ticket(ticket["id"])
        signoff.pack(P, ticket, "合成验证准备", "实际本地构建测试的普通证据包；没有人工复核或签收")
        package = signoff.state(DATA, ticket["key"])
        assert package["snapshot"]["check"]["result"] == "pass"
        assert not package.get("review") and not package.get("decision")
        folder = DATA / "runs" / str(rid)
        original = DATA / "original-evidence"
        original.mkdir()
        shutil.copytree(folder, original / "run-files")
        save(original / "run.json", source)
        save(original / "verification.json", checked)
        save(original / "package.json", package)
        save(original / "package-records.json", signoff.records(DATA, ticket["key"]))
        (original / "output.txt").write_text(source["output"], encoding="utf-8")
        (original / "prompt.md").write_text(source["prompt"], encoding="utf-8")
        (original / "result.md").write_text(source["result"], encoding="utf-8")
        (original / "candidate.patch").write_text(source["diff"], encoding="utf-8")
        shutil.copyfile(DATA / "commands.jsonl", original / "commands-before-recheck.jsonl")
        save(original / "file-index.json", {str(p.relative_to(original)): {"bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in original.rglob("*") if p.is_file()})
        assert not (DATA / "leader.json").exists() and not (DATA / "child.json").exists()
        assert P.store.one("SELECT COUNT(*) AS n FROM verification_operations")["n"] == 0
        (DATA / "hold").write_text("Synthetic control: keep candidate test waiting until this file is intentionally removed before a NEW recheck.\n")
        manifest = {"synthetic_only": True, "service_started": False, "recheck_started": False,
            "ticket": ticket["key"], "source_run": rid, "url": "http://127.0.0.1:8797/#/t/" + ticket["key"],
            "health_api": "http://127.0.0.1:8797/api/meta", "data_dir": str(DATA), "project_root": str(ROOT),
            "original_worktree": str(wt), "branch": branch, "main_head": git("rev-parse", "HEAD"),
            "worker_source": "tests/test_recheck_crash_independent.py:WORKER", "worker_sha256": hashlib.sha256(worker.read_bytes()).hexdigest(),
            "raw_marker_base64": base64.b64encode(b"recheck-candidate-started\x00\xff\n").decode(),
            "start_command": shlex.join([sys.executable, "-u", str(Path(__file__).resolve()), "--serve"]),
            "service_log": str(DATA / "service.log"), "control_file": str(DATA / "hold"),
            "baseline_commands": json.loads((DATA / "commands.jsonl").read_text().splitlines()[0]),
            "source_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()}
        save(DATA / "fixture-manifest.json", manifest)
        print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)
    finally:
        P.store.db.close()


def serve_fixture():
    from tmh.platform.server import serve
    assert (DATA / "fixture-manifest.json").is_file(), "Run setup first"
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(("127.0.0.1", 8797))
    for key in ("TMH_TOKEN", "TMH_PREVIEW_PORT", "TMH_PREVIEW_BASE", "TMH_PUBLIC_URL"):
        os.environ.pop(key, None)
    os.environ["TMH_UNDERSTAND"] = "rules"
    save(DATA / "service-owner.json", {"pid": os.getpid(), "script": str(Path(__file__).resolve()), "data_dir": str(DATA), "port": 8797})
    return serve(DATA, host="127.0.0.1", port=8797, user="合成浏览器验收", brand="Webuddy · 重新验证隔离验收")


if __name__ == "__main__":
    if "--serve" in sys.argv:
        raise SystemExit(serve_fixture())
    setup()
