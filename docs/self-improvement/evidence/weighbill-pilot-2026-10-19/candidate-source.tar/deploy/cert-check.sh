#!/usr/bin/env bash
# 证书剩余不足 3 天就报警(退出码 1 + 写 journal)。IP 证书只有 6 天;域名证书 90 天,也一样查。
# 用法: cert-check.sh <主机名或IP> [端口,默认443]
set -euo pipefail
HOST=${1:?用法: cert-check.sh <主机名或IP> [端口,默认443]}
END=$(echo | openssl s_client -connect "$HOST:${2:-443}" -servername "$HOST" 2>/dev/null | openssl x509 -noout -enddate | cut -d= -f2)
LEFT=$(( ( $(date -d "$END" +%s) - $(date +%s) ) / 3600 ))
if [ "$LEFT" -lt 72 ]; then
  echo "$HOST 证书剩余 ${LEFT} 小时(到期 $END),Caddy 自动续期可能失败:journalctl -u caddy 查原因" | systemd-cat -t weighbill-cert -p err
  echo "$HOST 证书剩余 ${LEFT} 小时,需要处理"; exit 1
fi
echo "$HOST 证书剩余 ${LEFT} 小时"
