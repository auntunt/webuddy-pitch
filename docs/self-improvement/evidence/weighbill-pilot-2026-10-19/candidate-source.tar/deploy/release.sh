#!/usr/bin/env bash
# 在 Mac 上执行:把当前已提交的版本发布到服务器。用法: deploy/release.sh <用户>@<主机>
# 只发布已提交的代码(git archive HEAD),工作区有改动就拒绝——服务器上跑的永远对应一个确定的提交。
set -euo pipefail
TARGET=${1:?用法: [WB_SSH_KEY=私钥路径] deploy/release.sh <用户>@<主机>}
SSH=(ssh -o BatchMode=yes); SCP=(scp -q -o BatchMode=yes)
if [ -n "${WB_SSH_KEY:-}" ]; then SSH+=(-i "$WB_SSH_KEY" -o IdentitiesOnly=yes); SCP+=(-i "$WB_SSH_KEY" -o IdentitiesOnly=yes); fi
cd "$(git rev-parse --show-toplevel)"
[ -z "$(git status --porcelain)" ] || { echo "工作区有未提交改动,先提交再发布"; exit 1; }
SHA=$(git rev-parse --short HEAD)
PKG=$(mktemp -t weighbill-XXXX).tgz
git archive --format=tar.gz -o "$PKG" HEAD
echo "发布 $SHA -> $TARGET"
"${SCP[@]}" "$PKG" "$TARGET:/tmp/weighbill-$SHA.tgz"
rm -f "$PKG"
"${SSH[@]}" "$TARGET" "SHA=$SHA WB_EXTRAS=${WB_EXTRAS:-cpu-ocr} bash -s" <<'REMOTE'
set -euo pipefail
R=/opt/weighbill/releases/$SHA
PREV=$(readlink /opt/weighbill/current || true)
sudo mkdir -p "$R" && sudo tar -xzf /tmp/weighbill-$SHA.tgz -C "$R" && rm -f /tmp/weighbill-$SHA.tgz
# 版本号不变时 pip 会认为「已安装」直接跳过(实测),必须强制重装本包;依赖另装一遍
# 依赖带上 cpu-ocr(无显卡识别,RapidOCR + onnxruntime,模型随包自带);配置里不用 cpu_ocr 时它只是装着不加载
# 私有部署用 OceanBase + 对象存储时:WB_EXTRAS=cpu-ocr,s3,oceanbase deploy/release.sh …
install_pkg(){ sudo /opt/weighbill/venv/bin/pip install -q "$1[${WB_EXTRAS:-cpu-ocr}]" && sudo /opt/weighbill/venv/bin/pip install -q --no-deps --force-reinstall "$1"; }
healthy(){ for i in $(seq 1 30); do curl -sf -o /dev/null http://127.0.0.1:8000/api/v1/health && return 0; sleep 1; done; return 1; }
# 任何一步失败都切回上一版并确认它起得来:服务跑的是 venv 里装好的包,装到一半退出的话,
# 下次重启/开机就会加载没验过的新代码(安全审计)。
rollback(){
  trap - ERR
  echo "发布失败,切回 ${PREV:-(无上一版)}"
  if [ -n "$PREV" ]; then
    sudo ln -sfn "$PREV" /opt/weighbill/current && install_pkg "$PREV" && sudo systemctl restart weighbill
    if healthy; then echo "已回到 $(basename "$PREV"),运行正常"; else echo "!!! 回滚后也起不来,需要人工处理"; fi
  fi
  sudo journalctl -u weighbill -n 30 --no-pager || true
  exit 1
}
trap rollback ERR
install_pkg "$R"
sudo ln -sfn "$R" /opt/weighbill/current
sudo systemctl restart weighbill
healthy || rollback
RUNNING=$(sudo /opt/weighbill/venv/bin/python -c 'import weighbill,pathlib;print(pathlib.Path(weighbill.__file__).parent)')
sudo diff -rq --exclude=__pycache__ "$R/weighbill" "$RUNNING" >/dev/null || { echo "装好的代码与发布包不一致: $RUNNING"; rollback; }
trap - ERR
curl -s http://127.0.0.1:8000/api/v1/health | python3 -c "import sys,json;h=json.load(sys.stdin);print('上线',h['version'],h['status'],h['capabilities'])"
ls -1dt /opt/weighbill/releases/* | tail -n +6 | xargs -r sudo rm -rf    # 保留最近 5 个版本
REMOTE
