# 部署

**已部署**:`https://gangsaomiao.bbstack.date/`(采集页)、`https://gangsaomiao.bbstack.date/report`(台账),2026-10-13 起 0.3.2。
旧入口 `https://43.153.76.85/` 仍可用(同一套转发规则,保留给已经发出去的链接)。域名在 Cloudflare,记录必须保持 DNS only(灰云),否则 Caddy 签不到证书、Basic 认证也会被代理层干扰。

没有 Caddy 的服务器(如以后集团/总部的机器)用 `deploy/nginx-weighbill.conf`,规则与 Caddy 版一一对应。

服务器上的网关是 **Caddy**(v2.11,同时承载 harness.cloudwaveai.cn 和 80 端口的 New API)。称重单作为 Caddy 里的一个站点块接入,证书由 Caddy 自己申请和续期,没有 nginx、没有 certbot。

| 位置 | 内容 |
|---|---|
| `/opt/weighbill/releases/<提交号>/` | 每次发布的代码,保留最近 5 个 |
| `/opt/weighbill/current` | 指向当前版本的软链 |
| `/opt/weighbill/venv/` | Python 环境 |
| `/etc/weighbill/config.json` | 配置与 OpenRouter key,属主 weighbill,权限 600,不进 git |
| `/var/lib/weighbill/` | 台账库与图片 |
| `/var/backups/weighbill/` | 每天 03:00 备份,保留 14 天 |
| `/etc/caddy/Caddyfile` 末尾 | 称重单站点块(内容见 `deploy/caddy-weighbill.caddy`) |
| `/etc/caddy/weighbill-users` | 登录账号(用户名 + bcrypt 哈希),root:caddy 640 |
| `/etc/cron.d/weighbill-cert` | 每 6 小时查证书剩余,不足 72 小时写 err 日志 |
| 日志 | `journalctl -u weighbill`、`journalctl -u caddy` |

## 访问与证书

- 只走 HTTPS。`http://43.153.76.85` 是 harness 项目原有的规则(308 跳 harness 域名),没有改动。
- 证书是 Let's Encrypt 的 IP 地址证书,强制 6 天有效(`profile shortlived`),Caddy 自动续。用 IP 访问时浏览器不带 SNI,靠 Caddyfile 顶部全局选项 `default_sni 43.153.76.85` 选中这张证书;带 SNI 的域名站点不受影响。
- 操作人 = 登录用户名。Caddy 用 `header_up X-Portal-User {http.auth.user.id}` 覆盖浏览器自带的同名头,伪造无效(已在生产验证)。
- (已于 2026-10-13 加上域名 gangsaomiao.bbstack.date,IP 入口保留)以后如要撤掉 IP 入口(如 `cloudwaveai.cn` 的子域名,Cloudflare 记录须为 DNS only 灰云):把站点地址 `https://43.153.76.85` 改成域名、删掉 `tls { … }` 块和全局 `default_sni` 即可,证书变为普通 90 天证书。

## 网关密钥(0.5.0)

应用只认带着网关密钥的操作人头:本机别的程序、借别的服务转发过来的请求一律当匿名(匿名不能审核)。
密钥放两处,内容相同,都不进 git:`/etc/weighbill/config.json` 的 `gateway_secret`(weighbill 600),
`/etc/caddy/weighbill-gateway-secret.caddy`(root:caddy 640,一行 `header_up X-Gateway-Secret "<密钥>"`)。
换密钥:两处一起改,`sudo systemctl reload caddy && sudo systemctl restart weighbill`。

## 日常操作

发布(在 Mac 上;只发布已提交的代码,新版本起不来自动切回上一版):

```bash
WB_SSH_KEY=~/.ssh/cc-deploy-20260923 deploy/release.sh ubuntu@43.153.76.85
```

加一个登录账号(用户名会记为台账里的操作人):

```bash
ssh ubuntu@43.153.76.85
echo "zhangsan $(caddy hash-password)" | sudo tee -a /etc/caddy/weighbill-users   # 按提示输入两次密码
sudo systemctl reload caddy
```

改 Caddy 配置前后务必:

```bash
sudo caddy validate --adapter caddyfile --config /etc/caddy/Caddyfile && sudo systemctl reload caddy
```

## 回滚与恢复

```bash
# 代码回到旧版本
sudo ln -sfn /opt/weighbill/releases/<旧提交号> /opt/weighbill/current
sudo /opt/weighbill/venv/bin/pip install -q --no-deps --force-reinstall /opt/weighbill/current && sudo systemctl restart weighbill
# 从备份恢复数据
sudo systemctl stop weighbill
sudo -u weighbill tar -xzf /var/backups/weighbill/weighbill-<时间>.tgz -C /var/lib/weighbill
sudo systemctl start weighbill
# 整个撤掉称重单的网关接入(恢复部署前的 Caddyfile)
sudo cp /etc/caddy/Caddyfile.bak.20260923-192102-before-weighbill /etc/caddy/Caddyfile && sudo systemctl reload caddy
```

## 从零在新服务器上装

```bash
ssh <用户>@<主机> 'bash -s' < deploy/preflight.sh                     # 只读现场检查
sudo useradd --system --home /var/lib/weighbill --shell /usr/sbin/nologin weighbill
sudo install -d -o weighbill -g weighbill -m 750 /var/lib/weighbill /var/backups/weighbill
sudo install -d -m 755 /opt/weighbill/releases && sudo install -d -o root -g weighbill -m 750 /etc/weighbill
sudo python3 -m venv /opt/weighbill/venv
# 配置从 Mac 经 ssh 管道直接写入,不落 /tmp:
#   ssh <主机> 'sudo sh -c "umask 077; cat > /etc/weighbill/config.json && chown weighbill:weighbill /etc/weighbill/config.json"' < config.json
# 装 deploy/weighbill.service、weighbill-backup.{service,timer} 到 /etc/systemd/system,enable 后执行一次 release.sh
# 网关:Caddy 按 deploy/caddy-weighbill.caddy;先用 Let's Encrypt 测试环境(issuer acme 里加
#   dir https://acme-staging-v02.api.letsencrypt.org/directory)走通,再去掉那一行。
#   注意:换正式环境时 reload 不会替换内存里仍有效的测试证书,要把
#   /var/lib/caddy/.local/share/caddy/certificates/acme-staging-v02… 挪走并 restart caddy。
```
