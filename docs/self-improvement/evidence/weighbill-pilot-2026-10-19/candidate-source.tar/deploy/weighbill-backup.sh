#!/usr/bin/env bash
# 每日备份:SQLite 用在线备份接口取一致快照(直接拷正在写的库可能拿到半截),再连同图片打包。保留 14 天。
set -euo pipefail
DATA=/var/lib/weighbill
OUT=/var/backups/weighbill
STAMP=$(date +%Y%m%d-%H%M)
mkdir -p "$OUT"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
/opt/weighbill/venv/bin/python - "$DATA/ledger.db" "$TMP/ledger.db" <<'PY'
import sqlite3, sys
src, dst = sqlite3.connect(sys.argv[1]), sqlite3.connect(sys.argv[2])
src.backup(dst); dst.close(); src.close()
PY
# 页面上改的设置(磅差阈值)也在数据目录里,一起备份;先写临时文件,成功了才改名,失败不留半截的包
EXTRA=$(cd "$DATA" && ls events.jsonl thresholds.json 2>/dev/null || true)
tar -czf "$OUT/.weighbill-$STAMP.tgz.part" -C "$TMP" ledger.db -C "$DATA" images $EXTRA
mv "$OUT/.weighbill-$STAMP.tgz.part" "$OUT/weighbill-$STAMP.tgz"
find "$OUT" -name 'weighbill-*.tgz' -mtime +14 -delete
find "$OUT" -name '.weighbill-*.part' -mmin +120 -delete
echo "备份完成 $OUT/weighbill-$STAMP.tgz $(du -h "$OUT/weighbill-$STAMP.tgz" | cut -f1)"
