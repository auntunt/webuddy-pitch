#!/usr/bin/env bash
# 在服务器上只读执行:不安装、不改配置。输出部署方案需要的全部现场信息。
set -u
h(){ printf '\n=== %s ===\n' "$1"; }
h "系统";        . /etc/os-release 2>/dev/null && echo "$PRETTY_NAME"; uname -m
h "时区";        timedatectl 2>/dev/null | grep -i "time zone" || date +%Z
h "Python";      for p in python3 python3.12 python3.11 python3.10; do command -v $p >/dev/null && echo "$p -> $($p -V 2>&1)"; done
h "venv 模块";   python3 -c "import venv, ensurepip; print('ok')" 2>&1 | tail -1
h "反向代理";   for x in caddy nginx; do command -v $x >/dev/null && echo "$x: $($x version 2>/dev/null || $x -v 2>&1)"; done
                 systemctl is-active nginx 2>/dev/null
h "nginx 已有站点"; ls /etc/nginx/sites-enabled /etc/nginx/conf.d 2>/dev/null
h "已占用端口";   (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | awk 'NR>1{print $4}' | sort -u
h "磁盘";        df -h / | tail -1
h "OpenRouter 连通"; curl -sS -o /dev/null -m 10 -w "HTTP %{http_code}, %{time_total}s\n" https://openrouter.ai/api/v1/models 2>&1
h "sudo";        sudo -n true 2>/dev/null && echo "免密 sudo 可用" || echo "sudo 需要密码或不可用"
h "防火墙";      (sudo -n ufw status 2>/dev/null || sudo -n firewall-cmd --state 2>/dev/null) | head -3
