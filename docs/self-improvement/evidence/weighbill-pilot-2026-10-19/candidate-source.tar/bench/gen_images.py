# -*- coding: utf-8 -*-
"""用 openai/gpt-5.4-image-2 生成 10 组真实拍摄条件下的称重单照片。
每组针对一种现场会遇到的坏条件,不是 10 张同质图。"""
import json, base64, time, sys
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
OUT = BASE/"bench"/"gen"; OUT.mkdir(parents=True, exist_ok=True)
KEY = json.loads((BASE/"config.json").read_text("utf-8"))["api_key"]
MODEL = "openai/gpt-5.4-image-2"

COMMON = ("A photorealistic smartphone photo of a Chinese paper truck weighbridge ticket "
          "(过磅称重单). The printed form has clearly legible Chinese field labels in a vertical list: "
          "客户名, 序号, 日期, 入站时间, 出站时间, 车号, 货名, 收费, 总重, 皮重, 净重, "
          "and at the bottom 称重员签名 with a handwritten blue-ink signature. "
          "Values are dot-matrix printed. Use plausible fictional values: a Chinese company name, "
          "an 11-digit serial, a 2026 date, two HH:MM times, a Chinese licence plate, "
          "a bulk cargo name, and three weights in kg where 总重 minus 皮重 equals 净重 exactly. "
          "Do not add any logo of a real company. ")

SCENES = [
  ("01_flat_clean",     "Shot straight down on a clean office desk, even indoor lighting, whole ticket in frame, sharp."),
  ("02_tilted",         "Held at an angle about 30 degrees off-axis, so the ticket appears as a trapezoid with perspective distortion."),
  ("03_wrinkled",       "The paper is crumpled and creased, with fold lines running across the printed values."),
  ("04_glare",          "Strong overhead fluorescent glare producing a bright specular hotspot washing out part of the ticket."),
  ("05_two_tickets",    "TWO separate weighbridge tickets lying side by side on the same desk, both fully visible, each with its own different values and its own signature."),
  ("06_three_tickets",  "THREE weighbridge tickets spread on a desk, slightly overlapping at the corners, each with different values."),
  ("07_dim_light",      "Dim warm indoor light at dusk, noticeable image noise and low contrast, slightly underexposed."),
  ("08_handheld_blur",  "Slight motion blur from a handheld shot, held over a dark car dashboard as background."),
  ("09_outdoor_shadow", "Outdoors in bright sun, a hard diagonal shadow from the photographer falling across the lower half of the ticket."),
  ("10_thermal_curl",   "A narrow thermal-paper ticket that curls at the edges, lying on a dirty concrete surface at a weighbridge station."),
]

def gen(name, scene):
    body = json.dumps({
        "model": MODEL, "modalities": ["image", "text"],
        "messages": [{"role": "user", "content": COMMON + scene}],
    }).encode()
    req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", data=body,
        headers={"Authorization": "Bearer " + KEY, "Content-Type": "application/json"})
    j = json.load(urllib.request.urlopen(req, timeout=300))
    msg = j["choices"][0]["message"]
    imgs = msg.get("images") or []
    if not imgs:
        return None, "无图片返回: " + json.dumps(msg)[:200]
    url = imgs[0]["image_url"]["url"]
    raw = base64.b64decode(url.split(",", 1)[1])
    p = OUT/f"{name}.png"; p.write_bytes(raw)
    return p, None

for name, scene in SCENES:
    t0 = time.time()
    try:
        p, err = gen(name, scene)
        print(f"{name:20} {'OK ' + str(p.stat().st_size//1024) + 'KB' if p else '失败 ' + err}  {time.time()-t0:.1f}s", flush=True)
    except Exception as e:
        print(f"{name:20} 异常 {type(e).__name__}: {str(e)[:160]}", flush=True)
