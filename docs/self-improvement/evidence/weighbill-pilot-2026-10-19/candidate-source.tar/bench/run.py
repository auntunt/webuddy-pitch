# -*- coding: utf-8 -*-
"""模型配置对比台架:同一组图 + 同一份真值,只改模型。"""
import json, subprocess, time, sys, os, urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
BENCH = BASE / "bench"
TRUTH = json.loads((BENCH / "truth.json").read_text("utf-8"))
KEY = json.loads((BASE / "config.json").read_text("utf-8"))["api_key"]
FIELDS = ["客户名","序号","日期","入站时间","出站时间","车号","货名","收费","总重","皮重","净重"]

CONFIGS = [
    ("baseline_双模型",  "google/gemini-3.8-flash",          "qwen/qwen3-vl-30b-a3b-instruct"),
    ("单模型_30b",       "qwen/qwen3-vl-30b-a3b-instruct",   "qwen/qwen3-vl-30b-a3b-instruct"),
    ("单模型_32b",       "qwen/qwen3-vl-32b-instruct",       "qwen/qwen3-vl-32b-instruct"),
    ("单模型_8b",        "qwen/qwen3-vl-8b-instruct",        "qwen/qwen3-vl-8b-instruct"),
]

def sh(c, **k): return subprocess.run(c, shell=True, capture_output=True, text=True, **k)

def spend():
    r = urllib.request.Request("https://openrouter.ai/api/v1/key",
                               headers={"Authorization": "Bearer " + KEY})
    return json.load(urllib.request.urlopen(r, timeout=30))["data"]["usage"]

def restart(seg, rec):
    sh("kill $(lsof -t -iTCP:8000 -sTCP:LISTEN) 2>/dev/null"); time.sleep(1)
    cfg = json.loads((BASE / "config.json").read_text("utf-8"))
    cfg["seg_model"], cfg["rec_model"] = seg, rec
    (BASE / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
    subprocess.Popen(f"cd {BASE} && .venv/bin/python -m uvicorn app:app --host 0.0.0.0 --port 8000",
                     shell=True, stdout=open("/tmp/wb_bench.log","a"), stderr=subprocess.STDOUT)
    for _ in range(40):
        time.sleep(0.5)
        try:
            live = json.load(urllib.request.urlopen("http://127.0.0.1:8000/api/config", timeout=3))
            if live["seg_model"] == seg and live["rec_model"] == rec:
                return                      # 判据:服务端确实换了模型,不是"起来了就算"
        except Exception: pass
    raise RuntimeError(f"服务未在预期模型下就绪 seg={seg} rec={rec}")

def upload(img):
    t0 = time.time()
    r = sh(f'curl -s -m 300 -X POST http://127.0.0.1:8000/api/upload -F "photo=@{img}"')
    dt = time.time() - t0
    try: return json.loads(r.stdout), dt
    except Exception: return {"error": r.stdout[:300]}, dt

def norm(v): return "" if v is None else str(v).strip()

def score(recs, truths):
    """按序号配对(序号错则退位置),逐字段计分。"""
    used, pairs = set(), []
    for t in truths:
        hit = next((i for i,r in enumerate(recs)
                    if i not in used and norm(r["fields"].get("序号")) == t["序号"]), None)
        if hit is None:
            hit = next((i for i in range(len(recs)) if i not in used), None)
        if hit is not None: used.add(hit)
        pairs.append((t, recs[hit] if hit is not None else None))
    ok = tot = 0; wrong = []
    for t, r in pairs:
        for f in FIELDS:
            tot += 1
            got = norm(r["fields"].get(f)) if r else ""
            if got == t[f]: ok += 1
            else: wrong.append(f"{t['序号']}.{f}: 期望{t[f]!r} 得到{got!r}")
    return ok, tot, wrong, pairs

report = []
for name, seg, rec in CONFIGS:
    print(f"\n{'='*60}\n>>> {name}  seg={seg}\n              rec={rec}", flush=True)
    try: restart(seg, rec)
    except Exception as e:
        report.append({"config":name,"error":str(e)}); print("  就绪失败:",e); continue
    s0 = spend(); row = {"config":name,"seg":seg,"rec":rec,"cases":{}}
    for case, truths in TRUTH.items():
        res, dt = upload(BENCH / f"{case}.jpg")
        if "records" not in res:
            row["cases"][case] = {"error": res.get("detail") or res.get("error"), "sec": round(dt,1)}
            print(f"  {case}: 失败 {row['cases'][case]['error']}"); continue
        recs = res["records"]
        ok, tot, wrong, pairs = score(recs, truths)
        sig = sum(1 for r in recs if r.get("sig_path"))
        row["cases"][case] = {"期望单据数":len(truths),"实得单据数":len(recs),
            "字段正确":f"{ok}/{tot}","准确率":round(ok/tot*100,1),
            "重量校验通过":sum(1 for r in recs if r["weight_ok"]),
            "auto_ok":sum(1 for r in recs if r["status"]=="auto_ok"),
            "签名截到":f"{sig}/{len(recs)}","sec":round(dt,1),"错项":wrong}
        print(f"  {case}: 单据{len(recs)}/{len(truths)} 字段{ok}/{tot} "
              f"({ok/tot*100:.0f}%) 签名{sig}/{len(recs)} {dt:.1f}s")
        for w in wrong[:6]: print("      ✗", w)
    time.sleep(3)
    row["花费USD"] = round(spend() - s0, 5)
    print(f"  花费 ${row['花费USD']}")
    report.append(row)

(BENCH / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), "utf-8")
print("\n报告已写入 bench/report.json")
