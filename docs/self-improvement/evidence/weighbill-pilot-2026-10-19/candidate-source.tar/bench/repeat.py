# -*- coding: utf-8 -*-
"""复验:双单据分割是否稳定。单跑一轮的结论不作数。"""
import json, subprocess, time, urllib.request
from pathlib import Path
BASE = Path(__file__).resolve().parent.parent; BENCH = BASE/"bench"
TRUTH = json.loads((BENCH/"truth.json").read_text("utf-8"))["case_b"]
KEY = json.loads((BASE/"config.json").read_text("utf-8"))["api_key"]
F = ["客户名","序号","日期","入站时间","出站时间","车号","货名","收费","总重","皮重","净重"]
N = 3
MODELS = ["qwen/qwen3-vl-8b-instruct","qwen/qwen3-vl-30b-a3b-instruct","qwen/qwen3-vl-32b-instruct"]

def sh(c): return subprocess.run(c, shell=True, capture_output=True, text=True)
def spend():
    r=urllib.request.Request("https://openrouter.ai/api/v1/key",headers={"Authorization":"Bearer "+KEY})
    return json.load(urllib.request.urlopen(r,timeout=30))["data"]["usage"]
def restart(m):
    sh("kill $(lsof -t -iTCP:8000 -sTCP:LISTEN) 2>/dev/null"); time.sleep(1)
    c=json.loads((BASE/"config.json").read_text("utf-8")); c["seg_model"]=c["rec_model"]=m
    (BASE/"config.json").write_text(json.dumps(c,ensure_ascii=False,indent=2),"utf-8")
    subprocess.Popen(f"cd {BASE} && .venv/bin/python -m uvicorn app:app --host 0.0.0.0 --port 8000",
                     shell=True,stdout=open("/tmp/wb_bench.log","a"),stderr=subprocess.STDOUT)
    for _ in range(40):
        time.sleep(0.5)
        try:
            l=json.load(urllib.request.urlopen("http://127.0.0.1:8000/api/config",timeout=3))
            if l["seg_model"]==m: return
        except Exception: pass
    raise RuntimeError("未就绪 "+m)

out={}
for m in MODELS:
    restart(m); s0=spend(); trials=[]
    print(f"\n>>> {m}  x{N}",flush=True)
    for i in range(N):
        t0=time.time()
        r=sh(f'curl -s -m 300 -X POST http://127.0.0.1:8000/api/upload -F "photo=@{BENCH}/case_b.jpg"')
        dt=time.time()-t0
        try: d=json.loads(r.stdout); recs=d["records"]
        except Exception: trials.append({"n":0,"acc":0,"sec":round(dt,1),"err":r.stdout[:120]}); print(f"  #{i+1} 异常"); continue
        got={ (x["fields"].get("序号") or "").strip() for x in recs }
        ok=sum(1 for t in TRUTH for f in F
               for x in recs if (x["fields"].get("序号") or "").strip()==t["序号"]
               and ((x["fields"].get(f) or "").strip()==t[f]))
        trials.append({"n":len(recs),"序号命中":sorted(got),"字段正确":f"{ok}/22","sec":round(dt,1)})
        print(f"  #{i+1} 单据{len(recs)}/2 字段{ok}/22 {dt:.1f}s 序号={sorted(got)}")
    time.sleep(20)                      # 账目有延迟,等一等再读
    out[m]={"trials":trials,"花费USD":round(spend()-s0,5)}
    print(f"  {N}轮合计 ${out[m]['花费USD']}")
(BENCH/"repeat.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),"utf-8")
print("\n写入 bench/repeat.json")
