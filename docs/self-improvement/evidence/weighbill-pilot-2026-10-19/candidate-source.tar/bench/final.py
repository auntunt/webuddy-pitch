# -*- coding: utf-8 -*-
import json, subprocess, time, urllib.request
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent; BENCH=BASE/"bench"
TRUTH=json.loads((BENCH/"truth.json").read_text("utf-8"))
KEY=json.loads((BASE/"config.json").read_text("utf-8"))["api_key"]
F=["客户名","序号","日期","入站时间","出站时间","车号","货名","收费","总重","皮重","净重"]
N=3
CONFIGS=[("单模型_8b","qwen/qwen3-vl-8b-instruct","qwen/qwen3-vl-8b-instruct"),
         ("基线_双模型","google/gemini-3.8-flash","qwen/qwen3-vl-30b-a3b-instruct")]
def sh(c): return subprocess.run(c,shell=True,capture_output=True,text=True)
def spend():
    r=urllib.request.Request("https://openrouter.ai/api/v1/key",headers={"Authorization":"Bearer "+KEY})
    return json.load(urllib.request.urlopen(r,timeout=30))["data"]["usage"]
def restart(seg,rec):
    sh("kill $(lsof -t -iTCP:8000 -sTCP:LISTEN) 2>/dev/null"); time.sleep(1)
    c=json.loads((BASE/"config.json").read_text("utf-8")); c["seg_model"],c["rec_model"]=seg,rec
    (BASE/"config.json").write_text(json.dumps(c,ensure_ascii=False,indent=2),"utf-8")
    subprocess.Popen(f"cd {BASE} && .venv/bin/python -m uvicorn app:app --host 0.0.0.0 --port 8000",
                     shell=True,stdout=open("/tmp/wb_f.log","a"),stderr=subprocess.STDOUT)
    for _ in range(40):
        time.sleep(0.5)
        try:
            l=json.load(urllib.request.urlopen("http://127.0.0.1:8000/api/config",timeout=3))
            if l["seg_model"]==seg and l["rec_model"]==rec: return
        except Exception: pass
    raise RuntimeError("未就绪")
def norm(v): return "" if v is None else str(v).strip()
out=[]
for name,seg,rec in CONFIGS:
    restart(seg,rec); s0=spend()
    print(f"\n=== {name}")
    agg={"字段对":0,"字段总":0,"单据对":0,"单据总":0,"签名":0,"记录":0,"auto_ok":0,"秒":0.0}
    for case,truths in TRUTH.items():
        for k in range(N):
            t0=time.time()
            r=sh(f'curl -s -m 300 -X POST http://127.0.0.1:8000/api/upload -F "photo=@{BENCH}/{case}.jpg"')
            dt=time.time()-t0; agg["秒"]+=dt
            try: recs=json.loads(r.stdout)["records"]
            except Exception: print(f"  {case}#{k+1} 异常"); agg["单据总"]+=len(truths); agg["字段总"]+=len(truths)*11; continue
            agg["单据总"]+=len(truths); agg["单据对"]+=min(len(recs),len(truths))
            agg["记录"]+=len(recs); agg["签名"]+=sum(1 for x in recs if x.get("sig_path"))
            agg["auto_ok"]+=sum(1 for x in recs if x["status"]=="auto_ok")
            ok=0
            for t in truths:
                m=next((x for x in recs if norm(x["fields"].get("序号"))==t["序号"]),None)
                for f in F:
                    agg["字段总"]+=1
                    if m and norm(m["fields"].get(f))==t[f]: ok+=1; agg["字段对"]+=1
            print(f"  {case}#{k+1} 单据{len(recs)}/{len(truths)} 字段{ok}/{len(truths)*11} {dt:.1f}s")
    time.sleep(20)
    cost=round(spend()-s0,5)
    n=N*len(TRUTH)
    print(f"  --> 字段准确 {agg['字段对']}/{agg['字段总']} ({agg['字段对']/agg['字段总']*100:.1f}%) "
          f"单据 {agg['单据对']}/{agg['单据总']} 签名 {agg['签名']}/{agg['记录']} "
          f"auto_ok {agg['auto_ok']}/{agg['记录']} 均耗时 {agg['秒']/n:.1f}s 花费 ${cost} (均${cost/n:.5f})")
    out.append({"config":name,**agg,"花费USD":cost,"次数":n})
(BENCH/"final.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),"utf-8")
