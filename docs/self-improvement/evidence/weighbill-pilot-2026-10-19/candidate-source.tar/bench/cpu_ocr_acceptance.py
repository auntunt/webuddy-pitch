"""CPU-only regression benchmark against approved original images. No model API calls."""
import sys,json,sqlite3,tempfile,asyncio,time,hashlib,platform,io
from pathlib import Path
from decimal import Decimal,InvalidOperation
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from weighbill.config import load_settings
from weighbill.bootstrap import build_service
from weighbill.domain import norm_plate,normalize_date
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
FIELDS=['车号','总重','皮重','净重','序号','日期','入站时间','出站时间']
def norm(k,v):
 if v is None or str(v).strip()=='':return None
 s=str(v).strip()
 if k=='车号':return norm_plate(s)
 if k in ['总重','皮重','净重']:
  try:return str(Decimal(s.replace(',','')).normalize())
  except InvalidOperation:return s
 if k=='日期':return normalize_date(s)
 if k in ['入站时间','出站时间']:
  import re
  m=re.search(r'(\d{1,2}):(\d{2})(?::(\d{2}))?',s)
  return f'{int(m[1]):02}:{m[2]}:{m[3] or "00"}' if m else s
 return s.upper().replace(' ','')
def equivalent(k, actual, expected):
 if k not in ('入站时间', '出站时间'):
  return norm(k,actual)==norm(k,expected)
 import re
 pattern = r'(\d{1,2}):(\d{2})(?::(\d{2}))?'
 a=re.search(pattern,str(actual or ''));e=re.search(pattern,str(expected or ''))
 if not a or not e:return str(actual or '').strip()==str(expected or '').strip()
 if (int(a[1]),int(a[2])) != (int(e[1]),int(e[2])):return False
 if e[3] is not None and a[3] != e[3]:return False
 # Compare only precision present in the human ledger; preserve every recognized value in details.
 date_pattern=r'(\d{4})-(\d{1,2})-(\d{1,2})'
 ed=re.search(date_pattern,str(expected));ad=re.search(date_pattern,str(actual))
 return not ed or (bool(ad) and tuple(map(int,ed.groups()))==tuple(map(int,ad.groups())))

async def main():
 import argparse
 ap=argparse.ArgumentParser(description='CPU OCR原图验收；结果保存在指定本地目录，生产台账只读')
 ap.add_argument('--data-dir',type=Path,default=ROOT/'data')
 ap.add_argument('--config',type=Path,default=ROOT/'config.json')
 ap.add_argument('--output',type=Path,required=True)
 ap.add_argument('--profile',choices=['v6-small','v6-mixed','v6-medium','v5-server'],default='v6-small')
 ap.add_argument('--ref-no', action='append', default=None, help='Only retest specified registration numbers')
 ap.add_argument('--serial-prefix',action='append',default=None,help='Known weighbridge serial prefix; never inferred from expected answers')
 args=ap.parse_args();OUT=args.output;OUT.mkdir(parents=True,exist_ok=True,mode=0o700)
 s=load_settings(config_path=args.config); s.vision_adapter='cpu_ocr';s.record_store='sqlite';s.blob_store='local';s.event_sink='null';s.spool_dir='';s.blob_cache_dir='';s.api_key=''
 if args.serial_prefix is not None:s.serial_prefixes=args.serial_prefix
 db=sqlite3.connect(f'file:{args.data_dir}/ledger.db?mode=ro',uri=True);db.row_factory=sqlite3.Row
 rows=db.execute("SELECT * FROM records WHERE stage='approved' AND voided_at IS NULL ORDER BY CASE doc_type WHEN 'supplier_out' THEN 0 WHEN 'site_in' THEN 1 ELSE 2 END,created_at,id").fetchall();db.close()
 if args.ref_no:rows=[r for r in rows if r['ref_no'] in args.ref_no]
 results=[];start=time.perf_counter()
 with tempfile.TemporaryDirectory(prefix='wb-cpu-accept-') as tmp:
  from rapidocr import RapidOCR, ModelType, OCRVersion, EngineType
  from weighbill.adapters.vision_cpu_ocr import CpuOcrVision
  import numpy as np
  v5=args.profile=='v5-server'
  det_size=ModelType.SERVER if v5 else ModelType.MEDIUM if args.profile=='v6-medium' else ModelType.SMALL
  rec_size=ModelType.SERVER if v5 else ModelType.SMALL if args.profile=='v6-small' else ModelType.MEDIUM
  version=OCRVersion.PPOCRV5 if v5 else OCRVersion.PPOCRV6
  rapid_engine=RapidOCR(params={
   'Det.engine_type':EngineType.ONNXRUNTIME,'Rec.engine_type':EngineType.ONNXRUNTIME,
   'Det.ocr_version':version,'Rec.ocr_version':version,
   'Det.model_type':det_size,'Rec.model_type':rec_size,
   'EngineConfig.onnxruntime.use_cuda':False,'EngineConfig.onnxruntime.use_coreml':False,
  })
  def engine(im):
   result=rapid_engine(np.array(im.convert('RGB')))
   return list(result.boxes) if result.boxes is not None else [],list(result.txts or [])
  s.data_dir=tmp;svc=build_service(s,vision=CpuOcrVision(engine=engine,anchors=s.ocr_anchors,serial_prefixes=s.serial_prefixes))
  providers={k:getattr(rapid_engine, '_load_' + k + '_model')().session.session.get_providers() for k in ('det','cls','rec')}
  if any(v != ['CPUExecutionProvider'] for v in providers.values()):raise RuntimeError(f'CPU-only verification failed: {providers}')
  inference_started=time.perf_counter()
  for i,row in enumerate(rows):
   truth=json.loads(row['fields']);raw=(args.data_dir/(row['orig_path'] or row['crop_path'])).read_bytes();t=time.perf_counter()
   with Image.open(io.BytesIO(raw)) as im:size=im.size
   try:
    records=await svc.ingest_detailed(raw,'cpu验收',doc_type=row['doc_type'],origin_id=row['origin_id'])
    r,dup=records[0]; checks={k:equivalent(k,r.fields.get(k),truth.get(k)) for k in FIELDS if norm(k,truth.get(k)) is not None}
    wrong={k:{'expected':truth.get(k),'actual':r.fields.get(k)} for k,v in checks.items() if not v}
    results.append({'ref_no':row['ref_no'],'type':row['doc_type'],'origin_id':row['origin_id'],'image_sha256':hashlib.sha256(raw).hexdigest(),'size':size,'seconds':round(time.perf_counter()-t,3),'count':len(records),'duplicate':dup,'status':r.status,'warnings':r.warnings,'weight_message':r.weight_msg,'checks':checks,'wrong':wrong,'critical_correct':all(checks.get(k,False) for k in FIELDS[:4]) and len(records)==1,'all_correct':not wrong and len(records)==1,'unflagged_error':(bool(wrong) or len(records)!=1) and r.status=='auto_ok','recognized':r.fields,'expected':truth})
   except Exception as e:results.append({'ref_no':row['ref_no'],'type':row['doc_type'],'error':str(e),'critical_correct':False,'all_correct':False,'unflagged_error':False})
   (OUT/'details.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
   if (i+1)%10==0: print(f'{i+1}/{len(rows)} elapsed={time.perf_counter()-start:.1f}s',flush=True)
 summary={'model':args.profile,'det_model':det_size.value,'rec_model':rec_size.value,'rapidocr_version':__import__('importlib.metadata',fromlist=['version']).version('rapidocr'),'onnxruntime_version':__import__('importlib.metadata',fromlist=['version']).version('onnxruntime'),'time_comparison':'按真值精度比较，保留OCR原始秒数；真值含日期时同时核对日期','providers':providers,'serial_prefixes':s.serial_prefixes,'count':len(results),'critical_correct':sum(r['critical_correct'] for r in results),'all_eight_fields_correct':sum(r['all_correct'] for r in results),'unflagged_error':sum(r['unflagged_error'] for r in results),'exceptions':sum('error' in r for r in results),'elapsed_seconds':round(time.perf_counter()-start,2),'inference_seconds':round(time.perf_counter()-inference_started,2),'machine':platform.machine(),'fields':{k:{'correct':sum(r.get('checks',{}).get(k,False) for r in results),'tested':sum(k in r.get('checks',{}) for r in results)} for k in FIELDS},'by_type':{k:{'count':sum(r['type']==k for r in results),'critical_correct':sum(r['type']==k and r['critical_correct'] for r in results),'all_correct':sum(r['type']==k and r['all_correct'] for r in results),'unflagged_error':sum(r['type']==k and r['unflagged_error'] for r in results)} for k in ['supplier_out','site_in','site_out']}}
 import resource,statistics
 timings=[r['seconds'] for r in results if 'seconds' in r]
 summary['median_seconds']=round(statistics.median(timings),3) if timings else None
 summary['p95_seconds']=sorted(timings)[min(len(timings)-1,int(len(timings)*0.95))] if timings else None
 summary['peak_rss_mib']=round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024),1)
 summary['no_silent_error_gate_passed'] = bool(results) and summary['exceptions']==0 and summary['unflagged_error']==0
 (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
 return 0 if summary['no_silent_error_gate_passed'] else 2
if __name__ == '__main__':
 sys.exit(asyncio.run(main()))
