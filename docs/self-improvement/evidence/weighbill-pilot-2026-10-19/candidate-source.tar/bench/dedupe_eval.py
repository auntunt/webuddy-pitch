# -*- coding: utf-8 -*-
"""防重复登记验收:每张有真值的磅单先正常上传一次,再把同一张单「重拍」(缩放、转 1.5°、压暗)再传一次,
看第二次是不是被认成已登记。走产品的 service.ingest_detailed,临时目录,不碰原数据。

    python bench/dedupe_eval.py <数据目录> [--config config.json] [--adapter cpu_ocr]
"""
from __future__ import annotations

import argparse, asyncio, io, sqlite3, sys, tempfile
from pathlib import Path

from PIL import Image, ImageEnhance

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from weighbill.bootstrap import build_service          # noqa: E402
from weighbill.config import load_settings             # noqa: E402


def reshoot(raw: bytes) -> bytes:
    im = Image.open(io.BytesIO(raw)).convert("RGB")
    im = im.resize((int(im.width * 0.85), int(im.height * 0.85)))
    im = im.rotate(1.5, expand=True, fillcolor=(235, 235, 230))
    im = ImageEnhance.Brightness(im).enhance(0.85)
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=80); return buf.getvalue()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data_dir"); ap.add_argument("--config"); ap.add_argument("--adapter", default="cpu_ocr")
    a = ap.parse_args()
    src = Path(a.data_dir)
    rows = sqlite3.connect(src / "ledger.db").execute(
        "select doc_type, crop_path from records where stage='approved' and crop_path is not null "
        "order by case doc_type when 'supplier_out' then 0 when 'site_in' then 1 else 2 end, created_at").fetchall()
    s = load_settings(config_path=Path(a.config) if a.config else None); s.vision_adapter = a.adapter
    with tempfile.TemporaryDirectory() as tmp:
        s.data_dir = tmp; svc = build_service(s)
        first = [asyncio.run(svc.ingest_detailed((src / c).read_bytes(), "eval", doc_type=t)) for t, c in rows]
        n_new_first = sum(d is None for res in first for _, d in res)
        caught = missed = failed = 0
        for (t, c), res in zip(rows, first):
            again = asyncio.run(svc.ingest_detailed(reshoot((src / c).read_bytes()), "eval", doc_type=t))
            r0 = res[0][0]
            if r0.status == "failed" or again[0][0].status == "failed":
                failed += 1
            elif all(d for _, d in again):
                caught += 1
            else:
                missed += 1
                print("  漏:", t, r0.fields.get("序号"), r0.fields.get("车号"), "|", again[0][0].fields.get("序号"), again[0][0].fields.get("车号"))
        total = len(svc.store.query(__import__("weighbill.ports", fromlist=["RecordQuery"]).RecordQuery(limit=5000)))
    print(f"第一次上传 {len(rows)} 张 → 新登记 {n_new_first} 条(应 = {len(rows)},<{len(rows)} 说明把不同的单当成了同一张)")
    print(f"重拍再传:认出已登记 {caught},漏认(多出一条){missed},识别失败无从比较 {failed};库里最终 {total} 条")


if __name__ == "__main__":
    main()
