# -*- coding: utf-8 -*-
"""生成带已知真值的测试照片。真值与图像同源,避免我事后对答案。"""
import os, json
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

OUT = Path(__file__).parent
FP = next(p for p in ["/System/Library/Fonts/STHeiti Medium.ttc",
                      "/System/Library/Fonts/Hiragino Sans GB.ttc"] if os.path.exists(p))
F = lambda s: ImageFont.truetype(FP, s)

R1 = {"客户名":"华东建材有限公司","序号":"20260922031","日期":"2026-09-22","入站时间":"08:15",
      "出站时间":"09:02","车号":"苏A38756","货名":"河砂","收费":"120",
      "总重":"38560","皮重":"12340","净重":"26220"}
R2 = {"客户名":"宁通物流有限公司","序号":"20260922047","日期":"2026-09-22","入站时间":"10:27",
      "出站时间":"11:05","车号":"浙B72914","货名":"碎石","收费":"150",
      "总重":"41200","皮重":"13850","净重":"27350"}

ORDER = ["客户名","序号","日期","入站时间","出站时间","车号","货名","收费","总重","皮重","净重"]

def draw_receipt(w, h, rec, scale=1.0):
    """单张单据(白纸),签名留在纸内、不贴底边。"""
    im = Image.new("RGB", (w, h), (252, 251, 246))
    d = ImageDraw.Draw(im)
    s = lambda v: max(10, int(v * scale))
    d.rectangle([0, 0, w-1, h-1], outline=(190, 185, 175), width=3)
    d.text((w*0.30, h*0.04), "过磅称重单", font=F(s(40)), fill=(20, 20, 20))
    y = h*0.13
    step = h*0.062
    for k in ORDER:
        d.text((w*0.07, y), k+":", font=F(s(28)), fill=(30, 30, 30))
        d.text((w*0.34, y), rec[k], font=F(s(28)), fill=(10, 10, 60))
        d.line([(w*0.07, y+step*0.78), (w*0.93, y+step*0.78)], fill=(215,210,200), width=2)
        y += step
    d.text((w*0.07, y+h*0.015), "称重员签名:", font=F(s(28)), fill=(30,30,30))
    # 手写签名:留出下方空白,不贴纸张底边
    sy = y + h*0.055
    pts = [(w*0.40,sy),(w*0.44,sy-h*0.035),(w*0.47,sy),(w*0.51,sy-h*0.030),
           (w*0.55,sy-h*0.004),(w*0.59,sy-h*0.033),(w*0.64,sy-h*0.006)]
    d.line(pts, fill=(25,25,110), width=max(3,s(5)), joint="curve")
    d.line([(w*0.39,sy+h*0.012),(w*0.66,sy+h*0.010)], fill=(25,25,110), width=max(2,s(4)))
    return im

# --- A: 单张单据 ---
bg = Image.new("RGB", (1400, 1000), (205, 200, 190))
bg.paste(draw_receipt(1000, 820, R1), (200, 90))
bg.save(OUT/"case_a.jpg", quality=92)

# --- B: 同一张照片里两张单据(考分割) ---
bg = Image.new("RGB", (1600, 1100), (198, 194, 186))
bg.paste(draw_receipt(700, 930, R1, scale=0.72), (60, 85))
bg.paste(draw_receipt(700, 930, R2, scale=0.72), (840, 85))
bg.save(OUT/"case_b.jpg", quality=92)

truth = {"case_a": [R1], "case_b": [R1, R2]}
(OUT/"truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2), "utf-8")
print("wrote case_a.jpg (1 receipt), case_b.jpg (2 receipts), truth.json")
