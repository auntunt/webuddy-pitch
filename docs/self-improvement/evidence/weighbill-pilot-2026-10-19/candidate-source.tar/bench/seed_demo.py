# -*- coding: utf-8 -*-
"""给页面评审用的演示数据:3 天业务,不调用任何模型(脚本化回放),不联网。
用法: python bench/seed_demo.py <数据目录>      图片用 bench/gen/*.png(生成图,非真实单据)
"""
import asyncio, datetime as dt, random, sys
from pathlib import Path

from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings

random.seed(7)
DATA = Path(sys.argv[1]); GEN = Path(__file__).parent / "gen"
PHOTOS = sorted(GEN.glob("*.png")) or sys.exit("缺 bench/gen/*.png,先跑 bench/gen_images.py")
BOX = [{"x": 4, "y": 4, "w": 92, "h": 92}]
PLATES = ["粤B·D3K216", "粤B·7F8820", "湘L·48284", "粤W·U8593", "粤B·5J1027"]
today = dt.date.today()


def fields(plate, day, tin, tout, gross, tare, sn, cust="比亚迪汽车工业有限公司", goods="冲压边角料"):
    return {"客户名": cust, "序号": sn, "日期": day.isoformat(), "入站时间": tin, "出站时间": tout, "车号": plate,
            "货名": goods, "收费": None, "总重": str(gross), "皮重": str(tare), "净重": str(gross - tare),
            "签名框": {"x": 35, "y": 82, "w": 30, "h": 8}}


def hm(t): return f"{t.hour:02d}:{t.minute:02d}"


async def main():
    s = Settings(api_key="demo", data_dir=str(DATA))
    plan = []
    for back in (2, 1, 0):
        day = today - dt.timedelta(days=back)
        for i, plate in enumerate(PLATES):
            trips = 3 if i < 2 else 2
            for k in range(trips):
                out = dt.datetime.combine(day, dt.time(7 + k * 4 + i % 2, (13 * i + 7 * k) % 60))
                if back == 0 and out.hour >= 15:
                    continue
                tare = random.randint(15200, 18600); net = random.randint(26000, 33000)
                supplier = fields(plate, day, hm(out - dt.timedelta(minutes=18)), hm(out), tare + net, tare,
                             f"BYD{day:%y%m%d}{i}{k}{random.randint(100,999)}")
                plan.append(("supplier_out", supplier, back))
                if back == 0 and i == 4 and k == 1:
                    continue                                   # 在途,加工厂还没到
                lost = 3000 if (back, i, k) == (1, 2, 0) else 1200 if (back, i, k) == (2, 0, 2) else random.randint(-20, 90)
                arr = out + dt.timedelta(minutes=random.choice([35, 48, 62, 95, 118]))
                p_net = net - lost; p_tare = tare + random.randint(-60, 60)
                plan.append(("site_in", fields(plate, arr.date(), hm(arr), hm(arr + dt.timedelta(minutes=22)), p_tare + p_net,
                                                 p_tare, f"GZD{arr:%y%m%d%H%M}{random.randint(1000,9999)}", "广富源", "汽车切片打包块"), back))
        plan.append(("site_in", fields("粤A·99Z01", day, "16:40", "17:02", 41000, 16000,
                                        f"GZD{day:%y%m%d}1640{random.randint(1000,9999)}", "广富源", "汽车切片打包块"), back) if back == 1 else None)
        for j, cust in enumerate(["广富源", "湛江钢铁", "湛江钢铁"]):
            plan.append(("site_out", fields(f"粤G·{random.randint(10000,99999)}", day, f"{13+j}:05", f"{13+j}:31",
                                               random.randint(45000, 49000), random.randint(15000, 17000),
                                               f"CP{day:%y%m%d}{j}{random.randint(100,999)}", cust, "破碎料") | {"_cust": cust}, back))
    plan = [p for p in plan if p]
    for n, (kind, f, back) in enumerate(plan):
        cust = f.pop("_cust", None)
        svc = build_service(s, vision=ScriptedVision(seg=[BOX], rec=[f], sig=[None]))
        who = {"supplier_out": "王建(比亚迪现场)", "site_in": "刘洋(加工厂地磅)", "site_out": "刘洋(加工厂地磅)"}[kind]
        rec = (await svc.ingest(PHOTOS[n % len(PHOTOS)].read_bytes(), who, doc_type=kind, customer=cust))[0]
        if back == 0 and n % 4 == 0:
            continue                                           # 今天有几张还没在现场确认
        svc.submit(rec.id, {}, who)
        if back == 2 or (back == 1 and n % 3):
            svc.approve([rec.id], "荣经理", privileged=True)
    print(f"已写入 {len(plan)} 张演示磅单 -> {DATA}")

asyncio.run(main())
