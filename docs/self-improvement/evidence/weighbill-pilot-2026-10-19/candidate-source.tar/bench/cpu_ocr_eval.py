# -*- coding: utf-8 -*-
"""无显卡识别的端到端验收:把一个数据目录里已审核的磅单图片,按「上传」同一条路重新识别一遍,和台账值比。

    python bench/cpu_ocr_eval.py <有真值的数据目录> [--config config.json] [--limit N]

走的是产品的 service.ingest(切单 → 识别 → 重量复读 → 车队纠车号 → 校验),在临时目录里跑,不碰原数据。
先灌厂商出厂单再灌进场单(进场单纠车号要靠当天的厂商车队)。只在本机 CPU 上跑,图片不出机器。

报告里最要紧的是「静默错」:车号或三项重量有错,但记录是 auto_ok(没有任何提示)——这种会直接进台账。
"""
from __future__ import annotations

import argparse, asyncio, json, sqlite3, sys, tempfile, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from weighbill.bootstrap import build_service          # noqa: E402
from weighbill.config import load_settings             # noqa: E402
from weighbill.domain import norm_plate                # noqa: E402

CORE = ("车号", "总重", "皮重", "净重")


def norm(k, v):
    if k == "车号":
        return norm_plate(v) or None
    try:
        return int(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data_dir"); ap.add_argument("--config", default=None); ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()
    src = Path(a.data_dir)
    rows = sqlite3.connect(src / "ledger.db").execute(
        "select doc_type, crop_path, fields from records where stage='approved' and crop_path is not null "
        "order by case doc_type when 'supplier_out' then 0 when 'site_in' then 1 else 2 end, created_at").fetchall()
    if a.limit:
        rows = rows[:a.limit]
    s = load_settings(config_path=Path(a.config) if a.config else None)
    s.vision_adapter = "cpu_ocr"
    with tempfile.TemporaryDirectory() as tmp:
        s.data_dir = tmp
        svc = build_service(s)
        out, t0 = [], time.time()
        for doc_type, crop, fields in rows:
            truth = json.loads(fields)
            recs = asyncio.run(svc.ingest((src / crop).read_bytes(), "eval", doc_type=doc_type))
            r = recs[0]
            ok = {k: norm(k, r.fields.get(k)) == norm(k, truth.get(k)) for k in CORE if truth.get(k)}
            core = all(ok.values()) and len(recs) == 1
            flagged = r.status != "auto_ok"
            out.append({"type": doc_type, "core": core, "flagged": flagged, "silent": not core and not flagged,
                        "split": len(recs), "warn": r.warnings[:2],
                        "plate": (r.fields.get("车号"), truth.get("车号")), "wmsg": r.weight_msg, "missing": [k for k in ("序号", "车号", "净重") if not r.fields.get(k)], **{f"ok_{k}": v for k, v in ok.items()}})
        dt = (time.time() - t0) / max(len(rows), 1)
    n = len(out)
    print(json.dumps({"张数": n, "车号+三项重量全对": sum(x["core"] for x in out),
                      "提示人看(非 auto_ok)": sum(x["flagged"] for x in out),
                      "静默错": sum(x["silent"] for x in out), "切出不是 1 张": sum(x["split"] != 1 for x in out),
                      **{k: f"{sum(x.get('ok_' + k, False) for x in out)}/{sum(('ok_' + k) in x for x in out)}" for k in CORE},
                      "每张秒数": round(dt, 2)}, ensure_ascii=False))
    for t in ("supplier_out", "site_in", "site_out"):
        xs = [x for x in out if x["type"] == t]
        print(f"  {t:13s} {len(xs):3d} 张  全对 {sum(x['core'] for x in xs):3d}  提示 {sum(x['flagged'] for x in xs):3d}  静默错 {sum(x['silent'] for x in xs)}")
    from collections import Counter
    why = Counter(w.split("「")[0][:18] for x in out if x["flagged"] for w in x["warn"] or ["(无提示,状态非 auto_ok)"])
    print("  提示原因:", dict(why.most_common(8)))
    for x in out:
        if x["flagged"] and not x["warn"]:
            print("  无字提示:", x["type"], x["core"], x["wmsg"], x["missing"])
    for x in out:
        if x["silent"]:
            print("  静默错:", x)


if __name__ == "__main__":
    main()
