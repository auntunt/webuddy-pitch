# -*- coding: utf-8 -*-
"""开发工具(不属于产品,不随包发布):把客户线下过磅登记表(.xlsx)装进一个数据目录,供本地演示与验收。
产品本身只导出、不导入(2026-10-13 用户要求)。

用法: python tools/load_ledgers.py <数据目录> 登记表.xlsx ... [--year 2026] [--dry-run]
WPS 的 .et 另存为 .xlsx 即可;.et 本身取不出图片。

表样(2026-10-12 收到):第 1 行表名,第 2 行「日期：10月11日」,第 3 行表头,之后每行一车,
「磅单图片」列里嵌的图片锚在同一行;末尾是「合计」行和「说明：……」。
列按表头名字认,不按位置——客户加列、换列顺序都不会错位。
"""
from __future__ import annotations

import datetime as dt
import re
from pathlib import Path
from typing import Iterator, Optional

from openpyxl import load_workbook

from weighbill.domain import DOC_SUPPLIER_OUT, DOC_SITE_IN, DOC_SITE_OUT

HEADER_TO_FIELD = {"磅单号": "序号", "入站时间": "入站时间", "出站时间": "出站时间", "出库时间": "出站时间",
                   "车牌号": "车号", "车号": "车号", "货名": "货名", "装点": "装点", "总重": "总重",
                   "空重": "皮重", "皮重": "皮重", "净重": "净重", "监磅员": "监磅员", "供应商": "供应商", "备注": "备注"}


def doc_type_of(title: str) -> Optional[str]:
    t = title or ""
    # 按角色词认表,不认厂商名:厂商出厂 / 进我们场 / 出我们场
    if "出厂" in t:
        return DOC_SUPPLIER_OUT
    if "入库" in t or "进场" in t:
        return DOC_SITE_IN
    if "出库" in t or "出场" in t:
        return DOC_SITE_OUT
    return None


def _cell(v, year: int) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        return str(int(v)) if float(v).is_integer() else str(v)
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.strftime("%Y-%m-%d")
    if isinstance(v, dt.time):
        return v.strftime("%H:%M:%S") if v.second else v.strftime("%H:%M")
    s = str(v).strip()
    m = re.fullmatch(r"(\d{1,2})-(\d{1,2})\s+(\d{1,2}:\d{2}(?::\d{2})?)", s)   # 厂商台账「10-10 17:21」补年份
    if m:
        return f"{year}-{int(m.group(1)):02d}-{int(m.group(2)):02d} {m.group(3)}"
    return s or None


def _sheet_date(ws, header_row: int, year: int) -> Optional[dt.date]:
    texts = [str(ws.cell(row=r, column=1).value or "") for r in range(1, header_row)] + [ws.title]
    for t in texts:
        m = re.search(r"(\d{1,2})\s*月\s*(\d{1,2})\s*日", t)
        if m:
            return dt.date(year, int(m.group(1)), int(m.group(2)))
    return None


def read_ledger(path: Path, year: Optional[int] = None) -> Iterator[dict]:
    """逐行产出 {doc_type, date, fields, image, customer, where}。只读,不改文件。"""
    year = year or dt.date.today().year
    wb = load_workbook(path, data_only=True)
    for ws in wb:
        header_row = next((r for r in range(1, 8)
                           if any(str(c.value or "").strip() == "磅单号" for c in ws[r])), None)
        if header_row is None:
            continue                               # 月度汇总等没有逐车明细的表
        doc_type = doc_type_of(str(ws.cell(row=1, column=1).value or ""))
        if doc_type is None:
            continue
        day = _sheet_date(ws, header_row, year)
        cols = {}
        img_col = None
        for c in ws[header_row]:
            name = str(c.value or "").strip()
            if name in HEADER_TO_FIELD:
                cols[c.column] = HEADER_TO_FIELD[name]
            elif name.startswith("磅单图片"):
                img_col = c.column
        images = {}
        for im in ws._images:
            fr = im.anchor._from
            images.setdefault(fr.row + 1, im._data())
        m = re.search(r"[（(]([^）)]+)[）)]", ws.title)
        customer = re.sub(r"出船$", "", m.group(1)) if (m and doc_type == DOC_SITE_OUT) else None
        for r in range(header_row + 1, ws.max_row + 1):
            first = str(ws.cell(row=r, column=1).value or "")
            if first.startswith("说明"):
                break
            fields = {f: _cell(ws.cell(row=r, column=c).value, year) for c, f in cols.items()}
            sn = fields.get("序号")
            if not sn:
                continue
            if sn == "合计":
                break
            fields["日期"] = day.isoformat() if day else None
            yield {"doc_type": doc_type, "date": day, "fields": fields, "image": images.get(r),
                   "customer": customer, "where": f"{Path(path).name} / {ws.title} / 第{r}行"}


def load_record(svc, doc_type: str, fields, image: Optional[bytes], customer: Optional[str],
                actor: str = "线下台账导入", approve: bool = True, origin_id=None):
    """把台账里的一行变成一条记录。同类型同磅单号已存在则跳过(返回 None),可重复执行。
    线下台账是人工核对过的,默认直接「已审核」,审核人记「线下台账」。"""
    import io
    from PIL import Image
    from weighbill.domain import (DOC_TYPES, FIELDS, Record, STAGE_APPROVED, STAGE_SUBMITTED, auto_status,
                                  validate_fields, weight_check)
    from weighbill.ports import RecordQuery
    if doc_type not in DOC_TYPES:
        raise ValueError(f"未知的单据类型 {doc_type!r}")
    origin_id = svc.resolve_origin(origin_id, doc_type)
    f = {k: (fields or {}).get(k) for k in FIELDS}
    sn = str(f.get("序号") or "").strip()
    if not sn:
        raise ValueError("磅单号为空")
    if any(r.origin_id == origin_id and str(r.fields.get("序号") or "").strip() == sn
           for r in svc.store.query(RecordQuery(doc_type=doc_type, q=sn, limit=None, origin_id=origin_id))):
        return None
    now_dt = svc.clock(); now = now_dt.isoformat(timespec="seconds")
    day = (f.get("日期") or now_dt.date().isoformat()).replace("-", "")
    batch = svc.new_id()[:12]
    orig_key = crop_key = None
    if image:
        with Image.open(io.BytesIO(image)) as im:
            fmt = im.format
        ext = {"JPEG":"jpg", "PNG":"png", "WEBP":"webp", "TIFF":"tiff", "GIF":"gif", "BMP":"bmp"}.get(fmt, "bin")
        mime = Image.MIME.get(fmt, "application/octet-stream")
        orig_key = svc.blobs.put(f"images/{day}/{batch}_orig.{ext}", image, mime)
        crop_key = svc.blobs.put(f"images/{day}/{batch}_r1.{ext}", image, mime)
    warns = validate_fields(f)
    wok, wmsg = weight_check(f)
    rec = Record(id=svc.new_id(), created_at=now, uploader=actor, batch_id=batch, seq_in_batch=1,
                 orig_key=orig_key, crop_key=crop_key, sig_key=None, fields=f, warnings=warns,
                 weight_ok=wok, weight_msg=wmsg, status=auto_status(warns, wok, f), model=None, seg_model=None,
                 doc_type=doc_type, customer=customer or None, origin_id=origin_id,
                 stage=STAGE_APPROVED if approve else STAGE_SUBMITTED,
                 submitted_by=f.get("监磅员") or actor, submitted_at=now,
                 approved_by="线下台账" if approve else None, approved_at=now if approve else None)
    svc._commit(rec)                   # 走服务的写入口:同样发登记编号
    return rec


def main(argv=None) -> int:
    import argparse, json, os
    from weighbill.bootstrap import build_service
    from weighbill.config import load_settings
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("data_dir"); ap.add_argument("files", nargs="+", type=Path)
    ap.add_argument("--year", type=int, default=None); ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    s = load_settings(); s.data_dir = a.data_dir
    svc = None if a.dry_run else build_service(s)
    stats = {}
    for path in a.files:
        for row in read_ledger(path, a.year):
            k = (path.name, s.naming.labels[row["doc_type"]], row["date"].isoformat() if row["date"] else "无日期")
            st = stats.setdefault(k, {"行": 0, "有图": 0, "新增": 0, "已存在": 0, "总重": 0, "空重": 0, "净重": 0})
            st["行"] += 1; st["有图"] += bool(row["image"])
            for col, key in (("总重", "总重"), ("空重", "皮重"), ("净重", "净重")):
                st[col] += int(float(row["fields"].get(key) or 0))
            if svc is not None:
                rec = load_record(svc, row["doc_type"], row["fields"], row["image"], row["customer"])
                st["新增" if rec else "已存在"] += 1
    for (fname, kind, day), st in stats.items():
        print(json.dumps({"文件": fname, "类型": kind, "磅单日期": day, **st}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
