# -*- coding: utf-8 -*-
"""图像处理:解码归一化、增强、按百分比框裁剪、签名墨迹吸附与校验。纯函数。

逐字取自 0.1 版 app.py;唯一改动是 normalize 的 max_side 由全局配置改为参数。
"""
from __future__ import annotations

import io, base64

import numpy as np
from PIL import Image, ImageOps

try:  # HEIC 支持(iPhone/微信伪装jpg),未安装时自动跳过
    from pillow_heif import register_heif_opener
    register_heif_opener()
except Exception:
    pass


# 解码前的像素上限。一张 18 万字节的 PNG 能声明 1.69 亿像素,解开要 690MB 内存、卡住整个服务(安全审计复现)。
# JPEG 先按缩小比例解码(draft),手机 48~108MP 的原图也只占很少内存;PNG/HEIC 没法缩着解,超过上限直接拒。
MAX_PIXELS = 60_000_000


class TooManyPixels(ValueError):
    pass


def normalize(raw: bytes, max_side: int = 2000) -> Image.Image:
    """解码(含HEIC)->按EXIF转正->RGB->限制最长边"""
    im = Image.open(io.BytesIO(raw))
    if im.format == "JPEG":
        im.draft("RGB", (max_side, max_side))
    if im.size[0] * im.size[1] > MAX_PIXELS:
        raise TooManyPixels(f"图片 {im.size[0]}×{im.size[1]} 像素太大")
    im = ImageOps.exif_transpose(im).convert("RGB")
    m = max(im.size)
    if m > max_side:
        s = max_side / m
        im = im.resize((int(im.width * s), int(im.height * s)))
    return im


PREVIEW = {"t": 360, "m": 1400}     # 缩略图按宽,中图按最长边


def preview(data: bytes, size: str) -> bytes:
    """生成预览图:t = 宽 360 的缩略图(列表用),m = 最长边 1400 的中图(详情用)。"""
    im = normalize(data, PREVIEW["m"])  # 预览用受限解码副本，避免全分辨率原图占满内存
    if size == "t":
        w = PREVIEW["t"]
        if im.width > w:
            im = im.resize((w, max(1, round(im.height * w / im.width))), Image.LANCZOS)
        q = 78
    else:
        m = PREVIEW["m"]
        if max(im.size) > m:
            s = m / max(im.size)
            im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
        q = 85
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=q, optimize=True, progressive=True)
    return buf.getvalue()


def enhance(im: Image.Image) -> Image.Image:
    g = np.asarray(im.convert("L"), dtype=np.float32)
    lo, hi = np.percentile(g, [2, 98])
    g = np.clip((g - lo) * 255.0 / max(1.0, hi - lo), 0, 255).astype(np.uint8)
    return Image.fromarray(g).convert("RGB")


def data_url(im: Image.Image, max_side=1400) -> str:
    m = max(im.size)
    if m > max_side:
        s = max_side / m
        im = im.resize((int(im.width * s), int(im.height * s)))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=90)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def norm_box(box):
    """把模型返回的框统一成百分比(0-100)框;无法解释则 None。

    模型不但可能不按"百分比"作答(Qwen-VL 常给 0-1000 归一化坐标),
    实测还会在同一个框里混用两套单位,例如 {x:40,y:81,w:45,h:90}
    ——x,y 是 0-1000 而 w,h 是百分比。所以位置(x,y)和尺寸(w,h)
    各自独立判定缩放,枚举 4 种组合,取"落在画面内"的解;
    并列时先取缩放次数少的(更贴近模型原意),再取面积大的。
    """
    if not isinstance(box, dict) or not all(isinstance(box.get(k), (int, float)) for k in ("x", "y", "w", "h")):
        return None   # 0.1 版这里对数组/字符串会抛 AttributeError,让整批上传 500
    x0, y0, w0, h0 = (float(box[k]) for k in ("x", "y", "w", "h"))
    if min(x0, y0, w0, h0) < 0 or max(x0, y0, w0, h0) > 1000.0 * 1.05:
        return None

    cands = []
    for ds, (x, y) in ((0, (x0, y0)), (1, (x0 / 10.0, y0 / 10.0))):
        for dd, (w, h) in ((0, (w0, h0)), (1, (w0 / 10.0, h0 / 10.0))):
            if w <= 0 or h <= 0:
                continue
            if x > 100.0 or y > 100.0 or x + w > 100.5 or y + h > 100.5:
                continue
            cands.append((ds + dd, -(w * h), {"x": x, "y": y,
                                              "w": min(w, 100.0 - x), "h": min(h, 100.0 - y)}))
    if not cands:
        return None
    return min(cands, key=lambda c: (c[0], c[1]))[2]


def crop_percent(im: Image.Image, box: dict, pad=2.0):
    box = norm_box(box)
    if box is None:
        return None
    W, H = im.size
    x = max(0.0, box["x"] - pad); y = max(0.0, box["y"] - pad)
    w = min(100 - x, box["w"] + 2 * pad); h = min(100 - y, box["h"] + 2 * pad)
    px = (int(x*W/100), int(y*H/100), int((x+w)*W/100), int((y+h)*H/100))
    if px[2] - px[0] < 8 or px[3] - px[1] < 8:
        return None
    return im.crop(px)


def _remove_runs(m: np.ndarray, axis: int, frac: float) -> np.ndarray:
    """抹掉沿axis方向长度超过frac*边长的连续暗段(表格线/边框)"""
    view = m if axis == 1 else m.T
    L = view.shape[1]; th = int(L * frac)
    for r in view:
        edges = np.flatnonzero(np.diff(np.concatenate(([0], r.astype(np.int8), [0]))))
        for s, e in zip(edges[::2], edges[1::2]):
            if e - s > th:
                r[s:e] = False
    return m


def ink_snap(im: Image.Image, box: dict):
    """以LLM粗框为中心,按实际墨迹重新收紧定位;返回百分比框或None"""
    box = norm_box(box)
    if box is None:
        return None
    pad = 10.0
    rx = max(0.0, box["x"] - pad); ry = max(0.0, box["y"] - pad)
    rw = min(100 - rx, box["w"] + 2 * pad); rh = min(100 - ry, box["h"] + 2 * pad)
    W, H = im.size
    region = im.crop((int(rx*W/100), int(ry*H/100), int((rx+rw)*W/100), int((ry+rh)*H/100)))
    if region.width < 8 or region.height < 8:
        return None
    s = min(1.0, 400 / region.width)
    rs = region.resize((max(1, int(region.width*s)), max(1, int(region.height*s))))
    g = np.asarray(rs.convert("L"))
    m = g < 110
    m = _remove_runs(m, 1, 0.2)
    m = _remove_runs(m, 0, 0.2)
    ys, xs = np.nonzero(m)
    if xs.size < m.size * 0.002:
        return None
    x1, x2 = np.percentile(xs, [2, 98]); y1, y2 = np.percentile(ys, [2, 98])
    w, h = m.shape[1], m.shape[0]
    return {"x": rx + x1/w*rw, "y": ry + y1/h*rh,
            "w": max(1.0, (x2-x1)/w*rw), "h": max(1.0, (y2-y1)/h*rh)}


def sig_valid(receipt: Image.Image, sig: Image.Image):
    g = np.asarray(sig.convert("L"))
    r = float((g < 110).mean())
    area = (sig.width * sig.height) / (receipt.width * receipt.height)
    if 0.004 <= r <= 0.35 and 0.004 <= area <= 0.4:
        return r
    return None
