# -*- coding: utf-8 -*-
"""数据迁移:把一套部署的台账、图片、修改记录、设置原样搬到另一套(试点 SQLite + 本地图片 → OceanBase + 对象存储)。

    weighbill migrate --source-config 旧.json --target-config 新.json [--dry-run]

原则:
- 不改来源的数据:只读来源的记录、图片、修改记录、设置(打开来源库时同版本的表结构检查是空操作)。
  来源服务器暂存区里还有没处理完的照片就拒绝开始:那些照片还没登记,搬走台账它们就落空了。
- 每条记录的顺序是:图片 → 修改记录 → 记录本身。记录写进目标就代表这一条搬完了;中途断了重跑,
  搬完的跳过,半截的接着搬(修改记录按条数补尾巴,不会重复),可以放心反复跑。
- 原样保留:记录 ID、登记编号、版本号、作废/有疑问、修改记录、预览图、磅差阈值。
  目标库的发号计数器抬到不小于已有最大号,迁移后新登记的单不会撞号。
- 每张图写完立即从目标读回比对 SHA-256;最后整体核对:逐条字段、逐张图字节、修改记录条数、
  各类张数与净重合计、磅差逐日结果。任何一项对不上,退出码 1。
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from dataclasses import dataclass, field
from typing import Optional

from .blob_keys import variant_key
from .domain import DOC_TYPES, Record
from .ports import RecordQuery

_REF = re.compile(r"^(?P<scope>[A-Z]+-\d{8})-(?P<n>\d+)$")
# 迁移后要逐项一致的记录字段(version 不比:目标写入时一样,但同一记录在来源后续还在变时由核对报出来)
_SAME = ("created_at", "uploader", "batch_id", "seq_in_batch", "orig_key", "crop_key", "sig_key", "fields", "warnings",
         "weight_ok", "weight_msg", "status", "model", "error", "seg_model", "reviewed_by", "reviewed_at", "doc_type",
         "customer", "stage", "submitted_by", "submitted_at", "approved_by", "approved_at", "ref_no", "voided_by",
         "voided_at", "void_reason", "flag_note", "source", "origin_id")


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


@dataclass
class Report:
    records_total: int = 0
    records_copied: int = 0
    records_already: int = 0
    images_copied: int = 0
    images_already: int = 0
    history_rows_copied: int = 0
    problems: list = field(default_factory=list)
    checks: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.problems and all(v.get("ok") for v in self.checks.values())

    def as_dict(self) -> dict:
        return {"ok": self.ok, "records_total": self.records_total, "records_copied": self.records_copied,
                "records_already_there": self.records_already, "images_copied": self.images_copied,
                "images_already_there": self.images_already, "history_rows_copied": self.history_rows_copied,
                "problems": self.problems[:200], "problem_count": len(self.problems), "checks": self.checks}


def _keys(r: Record, blobs) -> list[str]:
    """一条记录涉及的所有图:原图、单据图、签名图,以及来源里已经生成过的预览图。"""
    keys = [k for k in (r.orig_key, r.crop_key, r.sig_key) if k]
    for base in (r.orig_key, r.crop_key):
        for size in ("t", "m"):
            v = variant_key(base, size)
            if v and _exists(blobs, v):
                keys.append(v)
    return keys


def _exists(blobs, key: str) -> bool:
    f = getattr(blobs, "exists", None)
    if f:
        return f(key)
    try:
        blobs.open(key); return True
    except (FileNotFoundError, KeyError):
        return False


def _ctype(key: str) -> str:
    import mimetypes
    return mimetypes.guess_type(key)[0] or "application/octet-stream"


def migrate(src, dst, dry_run: bool = False, log=lambda s: None, stop_after: Optional[int] = None) -> Report:
    """src / dst:装配好的服务(只用其中的 store、blobs、spool)。stop_after 只给测试模拟「迁到一半断了」。"""
    rep = Report()
    pending = [m for m in src.spool.pending_items() if m.get("status") != "rejected"]
    if pending:
        rep.problems.append({"kind": "source_spool_pending", "count": len(pending),
                             "hint": "来源服务器暂存区还有没处理完的照片,先等它们登记完(或停机后处理完)再迁移"})
        return rep

    recs = sorted(src.store.query(RecordQuery(limit=None, voided="all")), key=lambda r: (r.created_at, r.seq_in_batch, r.id))
    rep.records_total = len(recs)
    source_origins = {o["id"]: o["name"] for o in src.settings.origin_catalog}
    target_origins = {o["id"]: o["name"] for o in dst.settings.origin_catalog}
    for origin in {r.origin_id for r in recs} - {""}:
        if origin not in source_origins or target_origins.get(origin) != source_origins[origin]:
            rep.problems.append({"kind": "origin_catalog_mismatch", "origin_id": origin,
                                 "hint": "先同步来源目录中的编号和名称，再迁移数据"})
    if rep.problems:
        return rep
    scopes: dict[str, int] = {}
    for i, r in enumerate(recs, 1):
        if stop_after is not None and i > stop_after:
            raise RuntimeError(f"(测试)迁到第 {i} 条中断")
        m = _REF.match(r.ref_no or "")
        if m:
            scopes[m["scope"]] = max(scopes.get(m["scope"], 0), int(m["n"]))
        # ① 图片:写完读回比对
        for k in _keys(r, src.blobs):
            try:
                data = src.blobs.open(k)
            except (FileNotFoundError, KeyError):
                rep.problems.append({"kind": "source_image_missing", "id": r.id, "ref_no": r.ref_no, "key": k})
                continue
            if _exists(dst.blobs, k) and _sha(dst.blobs.open(k)) == _sha(data):
                rep.images_already += 1; continue
            if not dry_run:
                dst.blobs.put(k, data, _ctype(k))
                if _sha(dst.blobs.open(k)) != _sha(data):
                    rep.problems.append({"kind": "image_readback_mismatch", "id": r.id, "key": k}); continue
            rep.images_copied += 1
        # ② 修改记录:补上目标还缺的尾巴
        sh, th = src.store.history(r.id), dst.store.history(r.id)
        if th[:len(sh)] != sh[:len(th)]:
            rep.problems.append({"kind": "history_diverged", "id": r.id, "ref_no": r.ref_no})
        else:
            for h in sh[len(th):]:
                if not dry_run:
                    dst.store.append_history(r.id, h["at"], h["actor"], h["action"], h["detail"])
                rep.history_rows_copied += 1
        # ③ 记录本身(最后写:它在 = 这一条搬完了)
        if dst.store.get(r.id) is not None:
            rep.records_already += 1
        else:
            if not dry_run:
                dst.store.insert(r)
            rep.records_copied += 1
        if i % 50 == 0:
            log(f"已处理 {i}/{len(recs)} 条")

    if not dry_run:
        for scope, n in scopes.items():
            dst.store.ensure_ref_at_least(scope, n)
        saved = _source_thresholds(src)
        if saved is not None and dst.store.get_setting("thresholds") is None:
            dst.store.set_setting("thresholds", saved)
        verify_into(rep, src, dst, recs)
    return rep


def verify_into(rep: Report, src, dst, recs=None) -> Report:
    """整体核对:每条字段、每张图字节、修改记录、各类合计、磅差逐日结果、设置。"""
    recs = recs if recs is not None else src.store.query(RecordQuery(limit=None, voided="all"))
    bad_fields, bad_images, bad_hist = [], [], []
    for r in recs:
        t = dst.store.get(r.id)
        if t is None:
            bad_fields.append({"id": r.id, "ref_no": r.ref_no, "what": "目标里没有"}); continue
        diff = [k for k in _SAME if getattr(r, k) != getattr(t, k)]
        if diff:
            bad_fields.append({"id": r.id, "ref_no": r.ref_no, "fields": diff})
        for k in _keys(r, src.blobs):
            try:
                if _sha(src.blobs.open(k)) != _sha(dst.blobs.open(k)):
                    bad_images.append({"id": r.id, "key": k})
            except (FileNotFoundError, KeyError):
                bad_images.append({"id": r.id, "key": k, "what": "缺"})
        if len(src.store.history(r.id)) != len(dst.store.history(r.id)):
            bad_hist.append(r.id)
    rep.checks["records"] = {"ok": not bad_fields, "count": len(recs), "mismatch": bad_fields[:50]}
    rep.checks["images"] = {"ok": not bad_images, "mismatch": bad_images[:50]}
    rep.checks["history"] = {"ok": not bad_hist, "mismatch": bad_hist[:50]}

    def totals(svc):
        out = {}
        for k in DOC_TYPES:
            rs = svc.store.query(RecordQuery(doc_type=k, limit=None, voided="all"))
            out[k] = {"tickets": len(rs), "voided": sum(bool(r.voided_at) for r in rs),
                      "net": sum(float(str((r.fields or {}).get("净重") or 0).replace(",", "") or 0)
                                 for r in rs if r.status != "failed" and not r.voided_at)}
        return out
    a, b = totals(src), totals(dst)
    rep.checks["totals"] = {"ok": a == b, "source": a, "target": b}
    ra = [(d["date"], d["supplier_net"], d["site_net"], d["diff"], d["trucks"]) for d in src.reconciliation()["days"]]
    rb = [(d["date"], d["supplier_net"], d["site_net"], d["diff"], d["trucks"]) for d in dst.reconciliation()["days"]]
    rep.checks["reconciliation"] = {"ok": ra == rb, "days": len(ra), **({} if ra == rb else {"source": ra, "target": rb})}
    rep.checks["settings"] = {"ok": _source_thresholds(src) in (None, dst.store.get_setting("thresholds"))}
    return rep


def _source_thresholds(src):
    """来源的磅差阈值:库里有用库里的;0.5 及以前存在数据目录 thresholds.json 的直接读文件(不经服务,免得往来源里写)。"""
    saved = src.store.get_setting("thresholds")
    if saved is None:
        f = src._threshold_file()
        if f.exists():
            saved = json.loads(f.read_text("utf-8"))
    return saved


def main(src_settings, dst_settings, dry_run: bool = False) -> int:
    from .bootstrap import build_service
    # 来源只读:不跑 build_service 里的「补发编号」;直接按来源配置装配存储
    from . import adapters
    from .service import WeighbillService
    parts = {p: adapters.build(p, src_settings) for p in ("record_store", "blob_store", "event_sink", "identity")}
    src = WeighbillService(vision=None, store=parts["record_store"], blobs=parts["blob_store"], events=parts["event_sink"],
                           identity=parts["identity"], settings=src_settings)
    dst = build_service(dst_settings)
    rep = migrate(src, dst, dry_run=dry_run, log=lambda s: print(s, file=sys.stderr))
    print(json.dumps(rep.as_dict(), ensure_ascii=False, indent=1, default=str))
    return 0 if rep.ok else 1
