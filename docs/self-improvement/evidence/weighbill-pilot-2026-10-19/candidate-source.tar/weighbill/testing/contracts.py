# -*- coding: utf-8 -*-
"""端口契约测试套件。新适配器接入前必须通过对应的检查。

用法(在接入方自己的测试里):
    from weighbill.testing.contracts import check_record_store
    def test_my_mysql_store():
        check_record_store(lambda: MySQLRecordStore(dsn=...))

每个 check_* 接收一个「每次调用都返回全新空实例」的工厂;失败时抛 AssertionError。
"""
from __future__ import annotations

import asyncio
from typing import Callable, Optional

from PIL import Image

from ..domain import FIELDS, Record, STATUS_NEEDS_REVIEW, STATUS_REVIEWED
from ..ports import RecordQuery


def _rec(i: int, created_at: str, **kw) -> Record:
    base = dict(id=f"rec-{i:04d}", created_at=created_at, uploader="张三", batch_id=f"b{i}",
                seq_in_batch=1, orig_key=f"images/x/{i}_orig.jpg", crop_key=f"images/x/{i}_r1.jpg",
                sig_key=None, fields={k: None for k in FIELDS} | {"客户名": f"客户{i}", "车号": "苏A12345"},
                warnings=["签名定位失败,需人工框选"], weight_ok=0, weight_msg="重量数据不全",
                status=STATUS_NEEDS_REVIEW, model="m-rec", seg_model="m-seg", error=None)
    base.update(kw)
    return Record(**base)


def check_record_store(make: Callable[[], object]) -> None:
    s = make()
    a = _rec(1, "2026-09-20T08:00:00")
    s.insert(a)
    got = s.get(a.id)
    assert got is not None, "insert 之后 get 不到"
    assert got.to_dict() == a.to_dict(), f"往返不一致:\n写入 {a.to_dict()}\n读出 {got.to_dict()}"
    try:
        s.insert(_rec(1, "2026-09-21T08:00:00"))
    except Exception:
        pass
    else:
        raise AssertionError("重复 id 的 insert 必须失败,不得静默覆盖")
    assert s.get(a.id).created_at == a.created_at, "重复 insert 改写了已有记录"
    assert s.get("no-such-id") is None, "查不到应返回 None"

    s.insert(_rec(2, "2026-09-21T09:00:00", status=STATUS_REVIEWED,
                  fields={k: None for k in FIELDS} | {"客户名": "华东建材"}))
    s.insert(_rec(3, "2026-09-22T23:59:59"))
    ids = [r.id for r in s.query(RecordQuery())]
    assert ids == ["rec-0003", "rec-0002", "rec-0001"], f"query 须按 created_at 倒序,得到 {ids}"
    assert [r.id for r in s.query(RecordQuery(status=STATUS_REVIEWED))] == ["rec-0002"], "status 过滤"
    assert [r.id for r in s.query(RecordQuery(q="华东"))] == ["rec-0002"], "q 须在字段值里做子串匹配"
    assert [r.id for r in s.query(RecordQuery(date_from="2026-09-21", date_to="2026-09-21"))] == ["rec-0002"], \
        "日期区间两端都应含当天"
    assert [r.id for r in s.query(RecordQuery(date_to="2026-09-22"))][0] == "rec-0003", \
        "date_to 当天 23:59:59 的记录必须包含在内"
    assert len(s.query(RecordQuery(limit=1))) == 1, "limit"
    s.insert(_rec(4, "2026-10-12T09:00:00", doc_type="supplier_out", stage="submitted", customer=None,
                  fields={k: None for k in FIELDS} | {"日期": "2026-10-10", "车号": "粤B12345"}))
    assert [r.id for r in s.query(RecordQuery(doc_type="supplier_out"))] == ["rec-0004"], "doc_type 过滤"
    assert [r.id for r in s.query(RecordQuery(stage="submitted"))] == ["rec-0004"], "stage 过滤"
    assert [r.id for r in s.query(RecordQuery(ticket_from="2026-10-10", ticket_to="2026-10-10"))] == ["rec-0004"], \
        "按磅单日期过滤(不是上传时间)"
    got4 = s.get("rec-0004")
    assert (got4.doc_type, got4.stage) == ("supplier_out", "submitted")

    upd = s.get("rec-0001")
    upd.fields = dict(upd.fields, 净重="100"); upd.status = STATUS_REVIEWED
    upd.warnings = []; upd.weight_ok = 1; upd.weight_msg = "ok"
    upd.reviewed_by = "李四"; upd.reviewed_at = "2026-09-23T10:00:00"
    upd.uploader = "不该被改"
    s.update(upd)
    after = s.get("rec-0001")
    assert after.fields["净重"] == "100" and after.status == STATUS_REVIEWED and after.reviewed_by == "李四"
    assert after.uploader == "张三", "update 只能改可变列,uploader 不可变"

    # 登记编号(0.4.2)
    assert [s.next_ref("RK-20261014") for _ in range(3)] == [1, 2, 3], "同一 scope 从 1 起逐个加一"
    assert s.next_ref("CC-20261014") == 1, "不同 scope 各自从 1 起"
    s.insert(_rec(5, "2026-10-14T09:00:00", ref_no="RK-20261014-0001"))
    assert s.get("rec-0005").ref_no == "RK-20261014-0001"
    try:
        s.insert(_rec(6, "2026-10-14T09:01:00", ref_no="RK-20261014-0001"))
    except Exception:
        pass
    else:
        raise AssertionError("登记编号必须唯一:重复的 ref_no 插入要失败")
    assert [r.id for r in s.query(RecordQuery(q="RK-20261014-0001"))] == ["rec-0005"], "q 要能按登记编号搜"
    r5 = s.get("rec-0005"); r5.ref_no = "改掉"; r5.fields = dict(r5.fields, 净重="1"); s.update(r5)
    assert s.get("rec-0005").ref_no == "RK-20261014-0001", "update 不得改登记编号"
    assert "rec-0001" in {r.id for r in s.without_ref()} and "rec-0005" not in {r.id for r in s.without_ref()}
    assert s.assign_ref("rec-0001", "JC-20260920-0001") is True and s.get("rec-0001").ref_no == "JC-20260920-0001"
    assert s.assign_ref("rec-0001", "JC-20260920-0099") is False, "已经有号的不许再改"

    # 版本号核对(0.6.0):多台服务器共用库时防覆盖
    from ..ports import StaleRecord
    x1, x2 = s.get("rec-0002"), s.get("rec-0002")
    x1.fields = dict(x1.fields, 备注="先写"); s.update(x1)
    assert x1.version == x2.version + 1, "写成后版本号加一并回填"
    x2.fields = dict(x2.fields, 备注="后写(读的是旧版本)")
    try:
        s.update(x2)
    except StaleRecord:
        pass
    else:
        raise AssertionError("拿旧版本写回必须抛 StaleRecord,不能覆盖")
    assert s.get("rec-0002").fields["备注"] == "先写"
    assert s.get_setting("nope") is None
    s.set_setting("thresholds", {"diff_alert_pct": 1.5}); s.set_setting("thresholds", {"diff_alert_pct": 2})
    assert s.get_setting("thresholds") == {"diff_alert_pct": 2}
    try:
        s.update(_rec(999, "2026-09-23T00:00:00"))
    except KeyError:
        pass
    else:
        raise AssertionError("update 不存在的记录必须抛 KeyError")
    s.ping()


def check_blob_store(make: Callable[[], object]) -> None:
    b = make()
    k = "images/20260923/abc_r1.jpg"
    assert b.put(k, b"\xff\xd8hello", "image/jpeg") == k, "put 应返回 key"
    assert b.open(k) == b"\xff\xd8hello", "open 读回的字节不一致"
    b.put(k, b"v2", "image/jpeg")
    assert b.open(k) == b"v2", "同 key 再 put 应覆盖"
    for bad in ("", "/etc/passwd", "../x", "images/../../x", "a\\b"):
        try:
            b.put(bad, b"x", "text/plain")
        except ValueError:
            continue
        raise AssertionError(f"非法 key 必须抛 ValueError: {bad!r}")
    u = b.url(k)
    assert isinstance(u, str) and u, "url 应返回非空字符串"
    try:
        b.open("images/20260923/abc_r9.jpg")
    except FileNotFoundError:
        pass
    else:
        raise AssertionError("不存在的键 open 必须抛 FileNotFoundError(预览图「没有就现做」靠它)")
    b.ping()


def check_identity(make: Callable[[], object], header: str = "X-Portal-User") -> None:
    r = make()
    anon = r.resolve({})
    assert isinstance(anon, str) and anon, "认不出时应返回非空匿名标识"
    assert r.resolve({header: "zhangsan"}) == "zhangsan"
    assert r.resolve({header.lower(): "zhangsan"}) == "zhangsan", "头名须大小写不敏感"
    mojibake = "张三".encode("utf-8").decode("latin-1")     # ASGI 交给我们的样子
    assert r.resolve({header: mojibake}) == "张三", f"UTF-8 中文头未还原: {r.resolve({header: mojibake})!r}"


def check_event_sink(make: Callable[[], object], read_back: Optional[Callable[[object], list]] = None) -> None:
    s = make()
    ev = {"specversion": "1.0", "id": "e1", "source": "/weighbill", "type": "com.weighbill.record.created",
          "time": "2026-09-23T00:00:00+00:00", "data": {"客户名": "华东建材"}}
    s.publish(ev)
    d = s.describe()
    assert "delivery" in d, "describe() 须声明投递语义 delivery"
    if read_back is not None:
        got = read_back(s)
        assert got and got[-1] == ev, f"读回的事件与发布的不一致: {got[-1] if got else None}"


def check_vision(vision, sample: Optional[Image.Image] = None) -> None:
    """对真实视觉适配器做形状检查(会真的调用模型)。"""
    im = sample or Image.new("RGB", (800, 600), "white")
    d = vision.describe()
    assert "api_key" not in d and not any("key" in str(v).lower() and len(str(v)) > 20 for v in d.values()), \
        "describe() 不得泄露密钥"
    assert "configured" in d, "describe() 须包含 configured"
    seg = asyncio.run(vision.segment(im))
    assert isinstance(seg, (list, dict)), f"segment 应返回数组(或单个对象),得到 {type(seg).__name__}"
    rec = asyncio.run(vision.recognize(im))
    assert isinstance(rec, dict), f"recognize 应返回对象,得到 {type(rec).__name__}"
