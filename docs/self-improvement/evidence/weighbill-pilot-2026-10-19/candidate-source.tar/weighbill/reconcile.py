# -*- coding: utf-8 -*-
"""磅差对比:厂商出厂磅单 ↔ 本场入库磅单。纯函数,不碰 IO。

配对规则(2026-10-12 会议):同一车号,两边各按时间排序,第 1 趟对第 1 趟。
实现为:每一趟厂商出厂,配「之后最早到达、且还没被配走」的那一趟入库。
- 允许跨零点(厂商 23:30 出,本场次日 01:10 到)。
- 厂商「过磅时间」不等于「出门时间」,中间要等出门审批,实测差两小时也正常,
  所以时间差只作信息列;是否标红由 transit_alert_minutes 决定,默认 0 = 不标。
- 配不上的两边都单列:在途、漏传、车号认错都会表现为配不上,这本身就是要人看的异常。
磅差 = 本场净重 − 厂商净重(2026-10-14 用户定:正数 = 本场称得多,负数 = 比本场少了/途中少了)。
比例仍以厂商净重为基准。客户手工《磅差对比表》是反方向(厂商 − 本场),数值相同符号相反。
"""
from __future__ import annotations

import datetime as dt
import re
from collections import defaultdict
from typing import Iterable, Optional

from .domain import Record, norm_plate

EARLY_TOLERANCE = dt.timedelta(minutes=15)    # 两边地磅时钟不一定对齐


def _num(v) -> Optional[float]:
    m = re.search(r"-?\d+(\.\d+)?", str(v or "").replace(",", ""))
    return float(m.group()) if m else None


def _date(v) -> Optional[dt.date]:
    m = re.search(r"(\d{4})\D{0,3}(\d{1,2})\D{0,3}(\d{1,2})", str(v or ""))
    if not m:
        return None
    try:
        return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def _time(v) -> Optional[dt.time]:
    m = re.search(r"(\d{1,2})[:：](\d{2})(?:[:：](\d{2}))?", str(v or ""))
    if not m:
        return None
    try:
        return dt.time(int(m.group(1)), int(m.group(2)), int(m.group(3) or 0))
    except ValueError:
        return None


def _stamp(v, day: Optional[dt.date]) -> Optional[dt.datetime]:
    """时间字段可能自带日期(厂商:「2026-10-10 17:21」「10-10 17:21」),有就用它自己的日期。"""
    t = _time(v)
    if t is None:
        return None
    s = str(v or "")
    full = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
    short = re.search(r"(?<!\d)(\d{1,2})-(\d{1,2})\s", s)
    try:
        if full:
            day = dt.date(int(full.group(1)), int(full.group(2)), int(full.group(3)))
        elif short and day:
            day = dt.date(day.year, int(short.group(1)), int(short.group(2)))
    except ValueError:
        return None
    return dt.datetime.combine(day, t) if day else None


def ticket_moment(rec: Record, prefer: str) -> tuple[Optional[dt.date], Optional[dt.datetime]]:
    """磅单的业务日期与时刻。厂商取出站(离开)时间,本场取入站(到达)时间,缺了用另一个。
    业务日期 = 磅单「日期」;厂商台账按出站那天归档(前一天傍晚入站、当天早上出站)。"""
    f = rec.fields or {}
    d = _date(f.get("日期"))
    other = "出站时间" if prefer == "入站时间" else "入站时间"
    at = _stamp(f.get(prefer), d) or _stamp(f.get(other), d)
    # 日期没认出来:用时间里带的日期,再没有就用登记日期——不能让这张单从对账和日汇总里消失
    return d or (at.date() if at else None) or _date(rec.created_at), at


def reconcile(supplier: Iterable[Record], site: Iterable[Record], diff_alert_pct: float = 1.0,
              transit_alert_minutes: int = 0, max_gap_hours: float = 12.0, diff_alert_kg: float = 0) -> dict:
    """单车标红 = |磅差率| 超过 diff_alert_pct,且(diff_alert_kg>0 时)|磅差| 也超过 diff_alert_kg。
    两个条件同时满足才标:8 吨的小车差 90 kg 就过 1%,加 kg 下限可以挡掉这类噪声。"""
    max_gap = dt.timedelta(hours=max_gap_hours)

    def prep(recs, prefer):
        out = []
        for r in recs:
            if r.status == "failed":
                continue
            d, at = ticket_moment(r, prefer)
            f = r.fields or {}
            out.append({"rec": r, "plate": norm_plate(f.get("车号")), "date": d, "at": at,
                        "gross": _num(f.get("总重")), "tare": _num(f.get("皮重")), "net": _num(f.get("净重"))})
        # 有时刻的按时刻;没时刻的按日期 + 上传先后,保证「顺序」仍然有意义
        out.sort(key=lambda x: (x["at"] or dt.datetime.combine(x["date"] or dt.date.min, dt.time.min),
                                x["rec"].created_at))
        return out

    B, P = prep(supplier, "出站时间"), prep(site, "入站时间")
    site_by_plate = defaultdict(list)
    for p in P:
        site_by_plate[(p["rec"].origin_id, p["plate"])].append(p)

    # 同一来源、同一辆车下一趟出厂的时刻:第 k 趟到达本场不可能晚于第 k+1 趟出厂。
    # 没有这条约束时,少传一张入库单会让后面的车次整体错位(真实数据出现过 +14650 kg 的假磅差)。
    next_departure, last = {}, {}
    for b in B:
        if b["plate"] and b["at"]:
            key = (b["rec"].origin_id, b["plate"])
            prev = last.get(key)
            if prev is not None:
                next_departure[id(prev)] = b["at"]
            last[key] = b

    used, pairs, lonely_supplier = set(), [], []
    for b in B:
        hit = None
        limit = next_departure.get(id(b))
        for p in site_by_plate.get((b["rec"].origin_id, b["plate"]), []) if b["plate"] and b["rec"].origin_id else []:
            if id(p) in used:
                continue
            if b["at"] and p["at"]:
                if limit is not None and p["at"] >= limit:
                    break                          # 再往后的入库单属于下一趟
                if b["at"] - EARLY_TOLERANCE <= p["at"] <= b["at"] + max_gap:
                    hit = p; break
            elif b["date"] and p["date"] and p["date"] in (b["date"], b["date"] + dt.timedelta(days=1)):
                hit = p; break
        if hit is None:
            lonely_supplier.append(b); continue
        used.add(id(hit))
        diff = (hit["net"] - b["net"]) if b["net"] is not None and hit["net"] is not None else None
        pct = (diff / b["net"] * 100) if diff is not None and b["net"] else None
        gap = int((hit["at"] - b["at"]).total_seconds() // 60) if b["at"] and hit["at"] else None
        pairs.append({
            "date": b["date"], "plate": b["plate"], "supplier": b["rec"], "site": hit["rec"],
            "supplier_gross": b["gross"], "supplier_tare": b["tare"], "site_gross": hit["gross"], "site_tare": hit["tare"],
            "supplier_net": b["net"], "site_net": hit["net"], "diff": diff, "diff_pct": pct, "gap_min": gap,
            "diff_alert": pct is not None and abs(pct) > diff_alert_pct and (not diff_alert_kg or abs(diff) > diff_alert_kg),
            "gap_alert": bool(transit_alert_minutes) and gap is not None and gap > transit_alert_minutes,
        })
    lonely_site = [p for p in P if id(p) not in used]

    days = defaultdict(lambda: {"pairs": [], "unmatched_supplier": [], "unmatched_site": [], "supplier_all": [], "site_all": []})
    for b in B:
        days[b["date"]]["supplier_all"].append(b)
    for p in P:
        days[p["date"]]["site_all"].append(p)
    for x in pairs:
        days[x["date"]]["pairs"].append(x)
    for b in lonely_supplier:
        days[b["date"]]["unmatched_supplier"].append(b["rec"])
    for p in lonely_site:
        days[p["date"]]["unmatched_site"].append(p["rec"])

    def total(xs):
        return sum(v for v in xs if v is not None)

    # 汇总口径与客户手工《磅差对比表》一致(当天两边全部车各自合计再相减),方向为 本场 − 厂商,
    # 总重、空重、净重三项都比,比例以厂商净重为基准。配对情况(每车磅差、没配上的)另列。
    out_days = []
    for d in sorted(days, key=lambda v: v or dt.date.min, reverse=True):
        g = days[d]
        B_, P_ = g.pop("supplier_all"), g.pop("site_all")
        tot = {f"{side}_{k}": total(x[k] for x in xs)
               for side, xs in (("supplier", B_), ("site", P_)) for k in ("gross", "tare", "net")}
        out_days.append({
            "date": d.isoformat() if d else None,
            "supplier_count": len(B_), "site_count": len(P_), "trucks": len(g["pairs"]), **tot,
            "diff_gross": tot["site_gross"] - tot["supplier_gross"], "diff_tare": tot["site_tare"] - tot["supplier_tare"],
            "diff": tot["site_net"] - tot["supplier_net"],
            "diff_pct": ((tot["site_net"] - tot["supplier_net"]) / tot["supplier_net"] * 100) if tot["supplier_net"] else None,
            "alerts": sum(x["diff_alert"] or x["gap_alert"] for x in g["pairs"]),
            "unmatched": len(g["unmatched_supplier"]) + len(g["unmatched_site"]),
            **g,
        })
    return {"days": out_days,
            "params": {"diff_alert_pct": diff_alert_pct, "diff_alert_kg": diff_alert_kg, "transit_alert_minutes": transit_alert_minutes,
                       "max_gap_hours": max_gap_hours}}
