# -*- coding: utf-8 -*-
"""称重单采集与台账子系统。

分层:
  domain / imaging / prompts  纯逻辑,不碰 IO
  ports                       对外依赖的抽象(视觉模型、台账存储、文件存储、身份、事件)
  adapters                    端口的具体实现,固定清单,不做动态加载
  service                     业务编排,只依赖端口
  bootstrap                   唯一装配点——HTTP 与 CLI 都从这里拿服务
  http_api / cli              入站适配器
"""
__version__ = "0.9.0"
SUBSYSTEM_ID = "weighbill"
