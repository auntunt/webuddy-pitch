# -*- coding: utf-8 -*-
"""Excel 导出,版式照客户线下台账(2026-10-12 收到):

- 三类登记表:每天一张表(表名、「日期：10月11日」、表头、逐车记录、合计、说明),「磅单图片」列嵌影像;
  另加月度汇总表。系统多出的「审核状态 / 审核人 / 登记编号」放在图片列之后,不打乱原表的列。
- 磅差:照客户的《厂商&本场过磅磅差对比表》——两行表头,厂商/本场/磅差各三列(总总重/总空重/总净重),
  净重磅差比例以厂商净重为基准;另加原表没有的「每车磅差明细」(两边影像并排)与「没配上的」。
所有名字(厂商、场、表名、说明)来自配置(domain.Naming),这里不写具体客户。
重量写成数值,Excel 里可以直接求和。
"""
from __future__ import annotations

import io
import re
from collections import OrderedDict
from typing import Callable, Optional

from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from PIL import Image

from .domain import DOC_COLUMNS, DOC_SITE_OUT, Naming, STAGES, Record, col_label

THUMB_H = 150                       # 影像缩略图高度(像素)
ROW_H_PT = THUMB_H * 0.75 + 6
TITLE = Font(bold=True, size=14)
HEAD = Font(bold=True)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
MID = Alignment(vertical="center", wrap_text=True)
THIN = Side(style="thin", color="999999")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
RED = PatternFill("solid", fgColor="FBE2DF")
AMBER = PatternFill("solid", fgColor="FFF2CC")
NUMERIC = {"总重", "皮重", "净重"}


def _num(v) -> Optional[float]:
    m = re.search(r"-?\d+(\.\d+)?", str(v or "").replace(",", ""))
    if not m:
        return None
    x = float(m.group())
    return int(x) if x.is_integer() else x


class ExportImageError(ValueError):
    """Do not deliver an incomplete workbook when an expected image is unavailable."""


def _thumb(load: Callable[[str], bytes], key: Optional[str]) -> Optional[XLImage]:
    if not key:
        return None
    try:
        raw = load(key)
        with Image.open(io.BytesIO(raw)) as im:
            if im.format not in {"JPEG", "PNG", "GIF"}:
                raise ValueError("该图片编码不能原样嵌入 Excel")
            width, height = im.size
            im.verify()
        x = XLImage(io.BytesIO(raw))
        # Only change the drawing dimensions. The embedded file remains byte-identical.
        x.width, x.height = max(1, round(width * THUMB_H / height)), THUMB_H
        return x
    except Exception as exc:
        raise ExportImageError(f"影像读取失败，未生成缺图报表：{key}。请恢复影像后重试。") from exc


def _put_img(ws, row, col, img):
    if img is None:
        ws.cell(row=row, column=col, value="无影像")
        return
    ws.add_image(img, f"{get_column_letter(col)}{row}")
    ws.row_dimensions[row].height = ROW_H_PT
    letter = get_column_letter(col)
    ws.column_dimensions[letter].width = max(ws.column_dimensions[letter].width or 0, img.width / 7 + 2)


def _title(ws, row, text, ncols, font=TITLE):
    ws.cell(row=row, column=1, value=text).font = font
    ws.cell(row=row, column=1).alignment = CENTER if font is TITLE else Alignment(vertical="center")
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)


def ledger_order(r: Record):
    """客户台账的行序:出站(出库)时间先后,同一时刻按磅单号。小时补零,否则「10:03」会排在「8:30」前面。"""
    f = r.fields or {}
    t = str(f.get("出站时间") or f.get("入站时间") or "")
    t = re.sub(r"(^|\s)(\d):", r"\g<1>0\2:", t)
    m = re.search(r"\d{2}:\d{2}(:\d{2})?$", t)
    return (f.get("日期") or "", t[: m.start()] if m else "", m.group(0).ljust(8, "0") if m else "", str(f.get("序号") or ""))


def _md(day: str) -> str:
    m = re.match(r"\d{4}-(\d{2})-(\d{2})", day or "")
    return f"{int(m.group(1))}月{int(m.group(2))}日" if m else (day or "无日期")


def records_workbook(doc_type: str, recs: list[Record], load: Callable[[str], bytes], naming: Naming = None, origin_name=None) -> bytes:
    naming = naming or Naming.build()
    origin_name = origin_name or (lambda key: key or "未关联来源")
    wb = Workbook(); wb.remove(wb.active)
    cols = DOC_COLUMNS[doc_type]
    head = ["序号"] + [col_label(doc_type, k) for k in cols] + ["磅单图片", "审核状态", "审核人", "登记编号", "来源单位", "来源编号"]
    img_col = len(cols) + 2
    widths = {"序号": 22, "入站时间": 17, "出站时间": 17, "车号": 11, "货名": 12, "装点": 6, "监磅员": 9,
              "供应商": 9, "备注": 14, "登记编号": 18}

    by_day = OrderedDict()
    for r in sorted(recs, key=ledger_order):
        by_day.setdefault((r.fields or {}).get("日期") or "", []).append(r)

    summary = []
    for day, rows in by_day.items():
        custs = {r.customer for r in rows if r.customer}
        name = _md(day) + (naming.out_sheet_suffix.format(customer=custs.pop()) if doc_type == DOC_SITE_OUT and len(custs) == 1 else "")
        ws = wb.create_sheet(_sheet_title(name))
        _title(ws, 1, naming.titles[doc_type], len(head))
        _title(ws, 2, f"日期：{_md(day)}", len(head), font=HEAD)
        ws.append(head)
        for c in ws[3]:
            c.font = HEAD; c.alignment = CENTER; c.border = BOX
        tot = {k: 0 for k in NUMERIC}
        for i, r in enumerate(rows, start=1):
            f = r.fields or {}
            vals = [_num(f.get(k)) if k in NUMERIC else f.get(k) for k in cols]
            ws.append([i] + vals + [None, STAGES.get(r.stage, r.stage), r.approved_by, r.ref_no, origin_name(r.origin_id), r.origin_id])
            row = ws.max_row
            for c in ws[row]:
                c.alignment = MID; c.border = BOX
            _put_img(ws, row, img_col, _thumb(load, r.orig_key or r.crop_key))
            if not r.weight_ok:
                for k in NUMERIC:
                    ws.cell(row=row, column=cols.index(k) + 2).fill = RED
            for k in NUMERIC:
                tot[k] += _num(f.get(k)) or 0
        ws.append([len(rows) + 1, "合计"] + [tot[k] if k in NUMERIC else None for k in cols[1:]])
        for c in ws[ws.max_row]:
            c.font = HEAD; c.border = BOX
        ws.append([naming.notes[doc_type]])
        ws.merge_cells(start_row=ws.max_row, start_column=1, end_row=ws.max_row, end_column=len(head))
        ws.cell(row=ws.max_row, column=1).alignment = MID
        ws.row_dimensions[ws.max_row].height = 34
        ws.freeze_panes = "A4"
        for i, h in enumerate(head, start=1):
            key = cols[i - 2] if 2 <= i <= len(cols) + 1 else h
            ws.column_dimensions[get_column_letter(i)].width = max(ws.column_dimensions[get_column_letter(i)].width or 0,
                                                                  widths.get(key, 10 if i != img_col else 30))
        goods = sorted({(r.fields or {}).get("货名") for r in rows if (r.fields or {}).get("货名")})
        summary.append((day, "、".join(goods), len(rows), tot["总重"], tot["皮重"], tot["净重"],
                        "、".join(sorted({r.customer for r in rows if r.customer}))))

    month = next((re.match(r"\d{4}-(\d{2})", d).group(1) for d, *_ in summary if re.match(r"\d{4}-\d{2}", d or "")), "")
    sm = wb.create_sheet(_sheet_title(naming.summary_sheet(doc_type)))
    sh = ["序号", "日期", "货名", "车数", "总重", "空重", "净重", "客户" if doc_type == DOC_SITE_OUT else "备注"]
    _title(sm, 1, naming.summary_titles[doc_type].format(m=int(month) if month else ""), len(sh))
    sm.append(sh)
    for c in sm[2]:
        c.font = HEAD; c.alignment = CENTER; c.border = BOX
    for day, goods, n, g, t, net, cust in summary:
        dnum = int(day[8:10]) if re.match(r"\d{4}-\d{2}-\d{2}", day or "") else None
        sm.append([dnum, day, goods, n, g, t, net, cust or None])
        for c in sm[sm.max_row]:
            c.border = BOX
    for i, w in enumerate([6, 12, 16, 7, 12, 12, 12, 16], start=1):
        sm.column_dimensions[get_column_letter(i)].width = w
    wb.move_sheet(sm, offset=-(len(wb.sheetnames) - 1))
    return _save(wb)


def reconciliation_workbook(res: dict, load: Callable[[str], bytes], naming: Naming = None, origin_name=None) -> bytes:
    naming = naming or Naming.build()
    origin_name = origin_name or (lambda key: key or "未关联来源")
    sup, site_name = naming.supplier, naming.site
    """res 是 service.reconciliation() 的结果(带 Record 对象)。"""
    wb = Workbook(); ws = wb.active; ws.title = "月度磅差汇总表"
    p = res["params"]
    _title(ws, 1, f"{sup}&{site_name}月度磅差汇总表", 13)
    ws.append(["序号", "日期", sup, None, None, site_name, None, None, f"磅差（{site_name} − {sup}）", None, None,
               f"净重磅差比例\n（以{sup}磅单为基准）", "备注"])
    ws.append([None, None, "总总重", "总空重", "总净重", "总总重", "总空重", "总净重", "总总重", "总空重", "总净重", None, None])
    for a, b in (("A2", "A3"), ("B2", "B3"), ("C2", "E2"), ("F2", "H2"), ("I2", "K2"), ("L2", "L3"), ("M2", "M3")):
        ws.merge_cells(f"{a}:{b}")
    for r in (2, 3):
        for c in ws[r]:
            c.font = HEAD; c.alignment = CENTER; c.border = BOX
    for d in sorted(res["days"], key=lambda d: d["date"] or ""):
        date = d["date"]
        note = [f"配对 {d['trucks']} 车"]
        if d["unmatched"]:
            note.append(f"没配上 {d['unmatched']} 张")
        if d["alerts"]:
            note.append(f"单车超 {p['diff_alert_pct']}%" + (f" 且超 {p['diff_alert_kg']:g} kg" if p.get("diff_alert_kg") else "")
                        + f" 共 {d['alerts']} 车")
        ws.append([int(date[8:10]) if date else None, date,
                   d["supplier_gross"], d["supplier_tare"], d["supplier_net"], d["site_gross"], d["site_tare"], d["site_net"],
                   d["diff_gross"], d["diff_tare"], d["diff"],
                   (d["diff_pct"] / 100) if d["diff_pct"] is not None else None, ";".join(note)])
        for c in ws[ws.max_row]:
            c.border = BOX
        ws.cell(row=ws.max_row, column=12).number_format = "0.00%"
        if (d["diff_pct"] is not None and abs(d["diff_pct"]) > p["diff_alert_pct"]
                and (not p.get("diff_alert_kg") or abs(d["diff"]) > p["diff_alert_kg"])):     # 与单车、页面同一规则
            for col in (11, 12):
                ws.cell(row=ws.max_row, column=col).fill = RED
    for i, w in enumerate([6, 12, 12, 12, 12, 12, 12, 12, 10, 10, 10, 16, 30], start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[2].height = 32

    dt = wb.create_sheet("每车磅差明细")
    dh = ["日期", "车牌号", f"{sup}出站", f"{site_name}入站", "时间差(分钟)", f"{sup}磅单号", f"{sup}净重",
          f"{sup}磅单", f"{site_name}磅单号", f"{site_name}净重", f"{site_name}磅单", f"净重磅差（{site_name} − {sup}）", "磅差比例",
          f"{sup}登记编号", f"{site_name}登记编号", "来源单位", "来源编号"]
    dt.append(dh)
    for c in dt[1]:
        c.font = HEAD; c.alignment = CENTER; c.border = BOX
    un = wb.create_sheet("没配上的")
    un.append(["日期", "哪一边", "车牌号", "时间", "磅单号", "净重", "磅单图片", "登记编号", "来源单位", "来源编号"])
    for c in un[1]:
        c.font = HEAD; c.alignment = CENTER; c.border = BOX
    for d in sorted(res["days"], key=lambda d: d["date"] or ""):
        for x in d["pairs"]:
            bf, pf = x["supplier"].fields or {}, x["site"].fields or {}
            dt.append([d["date"], bf.get("车号"), bf.get("出站时间") or bf.get("入站时间"),
                       pf.get("入站时间") or pf.get("出站时间"), x["gap_min"], bf.get("序号"), x["supplier_net"], None,
                       pf.get("序号"), x["site_net"], None, x["diff"],
                       (x["diff_pct"] / 100) if x["diff_pct"] is not None else None, x["supplier"].ref_no, x["site"].ref_no, origin_name(x["supplier"].origin_id), x["supplier"].origin_id])
            row = dt.max_row
            for c in dt[row]:
                c.alignment = MID; c.border = BOX
            dt.cell(row=row, column=13).number_format = "0.00%"
            _put_img(dt, row, 8, _thumb(load, x["supplier"].orig_key or x["supplier"].crop_key))
            _put_img(dt, row, 11, _thumb(load, x["site"].orig_key or x["site"].crop_key))
            if x["diff_alert"]:
                for col in (12, 13):
                    dt.cell(row=row, column=col).fill = RED
            if x["gap_alert"]:
                dt.cell(row=row, column=5).fill = AMBER
        for side, recs in ((f"{sup}出厂(没找到{site_name}进场)", d["unmatched_supplier"]), (f"{site_name}进场(没找到{sup}出厂)", d["unmatched_site"])):
            for r in recs:
                f = r.fields or {}
                un.append([d["date"], side, f.get("车号"), f.get("出站时间") or f.get("入站时间"), f.get("序号"),
                           _num(f.get("净重")), None, r.ref_no, origin_name(r.origin_id), r.origin_id])
                for c in un[un.max_row]:
                    c.alignment = MID; c.border = BOX
                _put_img(un, un.max_row, 7, _thumb(load, r.orig_key or r.crop_key))
    for i, w in enumerate([11, 11, 17, 17, 9, 20, 10, 30, 22, 10, 30, 10, 9, 18, 18], start=1):
        dt.column_dimensions[get_column_letter(i)].width = w
    for i, w in enumerate([11, 22, 11, 17, 22, 10, 30, 18], start=1):
        un.column_dimensions[get_column_letter(i)].width = w
    dt.freeze_panes = un.freeze_panes = "A2"
    return _save(wb)


def _save(wb) -> bytes:
    # 导出里没有一个格子是我们写的公式;凡是会被当成公式的(车号、备注里填了「=…」)一律按文字存。
    # 否则现场链接填一个 =HYPERLINK(…) 就能在审核员打开 Excel 时把别的格子发出去(安全审计复现过)。
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if c.data_type == "f":
                    c.data_type = "s"
    buf = io.BytesIO(); wb.save(buf); return buf.getvalue()


_BAD_TITLE = re.compile(r"[\\/?*\[\]:]")


def _sheet_title(name: str) -> str:
    """Excel 表名不许有 / \\ ? * [ ] :,最长 31 字。一个「2026/10/6」或「甲/乙」客户名不能让整个导出 500。"""
    return (_BAD_TITLE.sub("-", str(name or "")) or "未命名")[:31]
