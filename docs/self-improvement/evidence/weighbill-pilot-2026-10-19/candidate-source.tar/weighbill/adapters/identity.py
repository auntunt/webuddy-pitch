# -*- coding: utf-8 -*-
"""从门户/网关注入的请求头认出操作人。"""
from __future__ import annotations

from typing import Mapping


def repair_header_text(value: str) -> str:
    """HTTP 头按 latin-1 解码(ASGI 规范),网关直接塞 UTF-8 中文会变成 "å¼ ä¸‰" 这种乱码。
    能按 UTF-8 重新解释就还原;本来就是 ASCII 或合法 latin-1 文本则原样返回。"""
    try:
        return value.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return value


class HeaderIdentity:
    def __init__(self, header: str = "X-Portal-User", anonymous: str = "匿名"):
        self.header = header
        self.anonymous = anonymous

    def resolve(self, headers: Mapping[str, str]) -> str:
        v = None
        for k, val in headers.items():             # 头名大小写不敏感
            if k.lower() == self.header.lower():
                v = val; break
        v = repair_header_text(v).strip() if v else ""
        return v or self.anonymous

    def describe(self) -> dict:
        return {"adapter": "header", "header": self.header, "anonymous": self.anonymous}
