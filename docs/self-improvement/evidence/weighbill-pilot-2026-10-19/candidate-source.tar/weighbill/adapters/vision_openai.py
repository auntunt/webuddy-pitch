# -*- coding: utf-8 -*-
"""OpenAI 兼容 Chat Completions 的视觉模型适配器。

覆盖 OpenRouter、内网 vLLM、以及任何兼容 /v1/chat/completions + image_url 的服务。
请求体、提示词、增强策略与 0.1 版逐项一致:
  分割 = seg_model + 增强图;识别 = rec_model + 增强图;签名专项 = seg_model + 原图。
"""
from __future__ import annotations

import httpx
from PIL import Image

from ..imaging import data_url, enhance as _enhance
from ..prompts import SEG_PROMPT, REC_PROMPT, SIG_PROMPT, WEIGHT_PROMPT, bbox_to_percent, extract_json


class OpenAICompatibleVision:
    def __init__(self, base_url: str, api_key: str, seg_model: str, rec_model: str,
                 enhance: bool = True, timeout: float = 180, max_tokens: int = 2000,
                 transport=None):
        self.base_url = base_url
        self.api_key = api_key
        self.seg_model = seg_model
        self.rec_model = rec_model
        self.enhance = enhance
        self.timeout = timeout
        self.max_tokens = max_tokens
        self.transport = transport      # 测试注入 httpx.MockTransport;生产为 None

    async def _chat(self, model: str, prompt: str, im: Image.Image) -> str:
        if not self.api_key:
            raise RuntimeError("视觉模型未配置 api_key")
        async with httpx.AsyncClient(transport=self.transport) as client:
            r = await client.post(
                self.base_url.rstrip("/") + "/chat/completions",
                headers={"Authorization": "Bearer " + self.api_key, "X-Title": "weighbill-system"},
                json={"model": model, "temperature": 0, "max_tokens": self.max_tokens, "messages": [
                    {"role": "user", "content": [
                        {"type": "image_url", "image_url": {"url": data_url(im)}},
                        {"type": "text", "text": prompt}]}]},
                timeout=self.timeout)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]

    def _prep(self, im: Image.Image) -> Image.Image:
        return _enhance(im) if self.enhance else im

    async def segment(self, image):
        seg = extract_json(await self._chat(self.seg_model, SEG_PROMPT, self._prep(image)))
        return [bbox_to_percent(b) for b in seg] if isinstance(seg, list) else bbox_to_percent(seg)

    async def recognize(self, receipt):
        res = extract_json(await self._chat(self.rec_model, REC_PROMPT, self._prep(receipt)))
        if isinstance(res, dict) and res.get("签名框") is not None:
            res["签名框"] = bbox_to_percent(res["签名框"])
        return res

    async def locate_signature(self, receipt):
        return bbox_to_percent(extract_json(await self._chat(self.seg_model, SIG_PROMPT, receipt)))

    async def reread_weights(self, receipt):
        return extract_json(await self._chat(self.rec_model, WEIGHT_PROMPT, self._prep(receipt)))

    def describe(self) -> dict:
        return {"adapter": "openai_compatible", "base_url": self.base_url,
                "seg_model": self.seg_model, "rec_model": self.rec_model,
                "configured": bool(self.api_key), "enhance": self.enhance}
