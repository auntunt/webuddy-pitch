# -*- coding: utf-8 -*-
"""适配器固定清单。

刻意不支持「在配置里写模块路径动态加载」:配置文件不该成为执行任意代码的入口。
新增适配器 = 写实现 + 在下面登记一行 + 通过 weighbill.testing.contracts 的契约测试。
"""
from __future__ import annotations

from typing import Callable

from ..config import Settings
from .blob_local import LocalBlobStore
from .blob_s3 import S3BlobStore
from .events import JsonlEventSink, NullEventSink, WebhookEventSink
from .identity import HeaderIdentity
from .store_oceanbase import OceanBaseRecordStore
from .store_sqlite import SQLiteRecordStore
from .vision_cpu_ocr import CpuOcrVision
from .vision_openai import OpenAICompatibleVision

VISION: dict[str, Callable[[Settings], object]] = {
    "openai_compatible": lambda s: OpenAICompatibleVision(s.base_url, s.api_key, s.seg_model,
                                                          s.rec_model, enhance=s.enhance),
    # 无显卡、数据不出服务器:RapidOCR(CPU)+ 标签配值规则
    "cpu_ocr": lambda s: CpuOcrVision(anchors=s.ocr_anchors, serial_prefixes=s.serial_prefixes),
}
RECORD_STORES: dict[str, Callable[[Settings], object]] = {
    "sqlite": lambda s: SQLiteRecordStore(s.data_path / "ledger.db"),
    # 私有部署:多台应用节点共用一个库(MySQL 模式;MySQL 8 也能用)
    "oceanbase": lambda s: OceanBaseRecordStore(s.db_host, s.db_port, s.db_user, s.db_password, s.db_name),
}
BLOB_STORES: dict[str, Callable[[Settings], object]] = {
    "local": lambda s: LocalBlobStore(s.data_path),
    # 私有部署:S3 协议对象存储(RustFS / Ceph RGW / 信创对象存储)。本机读缓存在 blob_cache_dir
    "s3": lambda s: S3BlobStore(s.s3_endpoint, s.s3_access_key, s.s3_secret_key, s.s3_bucket, s.s3_region,
                                cache_dir=s.blob_cache_path, cache_max_mb=s.blob_cache_mb),
}
EVENT_SINKS: dict[str, Callable[[Settings], object]] = {
    "null": lambda s: NullEventSink(),
    "jsonl": lambda s: JsonlEventSink(s.events_file),
    "webhook": lambda s: WebhookEventSink(s.webhook_url, s.webhook_secret),
}
IDENTITIES: dict[str, Callable[[Settings], object]] = {
    "header": lambda s: HeaderIdentity(s.identity_header, s.anonymous_name),
}

REGISTRY = {
    "vision": (VISION, "vision_adapter"),
    "record_store": (RECORD_STORES, "record_store"),
    "blob_store": (BLOB_STORES, "blob_store"),
    "event_sink": (EVENT_SINKS, "event_sink"),
    "identity": (IDENTITIES, None),         # 目前只有一种,不开放配置
}


def build(port: str, settings: Settings):
    table, attr = REGISTRY[port]
    name = getattr(settings, attr) if attr else next(iter(table))
    if name not in table:
        raise ValueError(f"端口 {port} 没有名为 {name!r} 的适配器;可选: {sorted(table)}")
    return table[name](settings)


def available() -> dict:
    return {port: sorted(table) for port, (table, _) in REGISTRY.items()}
