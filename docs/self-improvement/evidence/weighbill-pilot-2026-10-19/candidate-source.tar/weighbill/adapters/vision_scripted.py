# -*- coding: utf-8 -*-
"""按脚本回放的视觉模型:测试、离线演示、以及新适配器写契约测试时的对照组。

每类调用各有一个队列;队列元素若是异常实例则抛出。调用会被逐条记录在 calls 里,
测试可以据此断言「真实调用顺序」而不只是最终结果。
"""
from __future__ import annotations

import copy
from collections import deque


class ScriptedVision:
    def __init__(self, seg=(), rec=(), sig=(), weights=(), seg_model="scripted-seg", rec_model="scripted-rec"):
        self._q = {"segment": deque(seg), "recognize": deque(rec), "locate_signature": deque(sig),
                   "reread_weights": deque(weights)}
        self.calls: list[tuple[str, tuple[int, int]]] = []
        self.seg_model, self.rec_model = seg_model, rec_model

    def _next(self, kind, im):
        self.calls.append((kind, im.size))
        q = self._q[kind]
        if not q:
            raise AssertionError(f"ScriptedVision: {kind} 的脚本已耗尽(第 {len(self.calls)} 次调用)")
        item = q.popleft()
        if isinstance(item, BaseException):
            raise item
        return copy.deepcopy(item)

    async def segment(self, image):
        return self._next("segment", image)

    async def recognize(self, receipt):
        return self._next("recognize", receipt)

    async def locate_signature(self, receipt):
        return self._next("locate_signature", receipt)

    async def reread_weights(self, receipt):
        return self._next("reread_weights", receipt)

    def describe(self) -> dict:
        return {"adapter": "scripted", "seg_model": self.seg_model, "rec_model": self.rec_model,
                "configured": True}
