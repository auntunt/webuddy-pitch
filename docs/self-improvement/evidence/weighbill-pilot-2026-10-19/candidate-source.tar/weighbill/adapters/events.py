# -*- coding: utf-8 -*-
"""领域事件出口的三个默认实现。"""
from __future__ import annotations

import hashlib, hmac, json, threading
from pathlib import Path

import httpx


class NullEventSink:
    """不向外通知。默认值——没配置下游就不该假装通知过谁。"""
    def publish(self, event: dict) -> None:
        return None

    def describe(self) -> dict:
        return {"adapter": "null", "delivery": "none"}


class JsonlEventSink:
    """追加写入本地 JSONL 出箱文件,供对方系统 tail/定时拉取。落盘即成功。"""
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def publish(self, event: dict) -> None:
        line = json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n"
        with self._lock, open(self.path, "a", encoding="utf-8") as f:
            f.write(line); f.flush()

    def describe(self) -> dict:
        return {"adapter": "jsonl", "path": str(self.path), "delivery": "at-least-once(本地落盘)"}


class WebhookEventSink:
    """同步 POST 到对方地址,单次尝试、不重试(at-most-once)。

    需要可靠投递时:用 jsonl 出箱,或在网关侧做重试。签名头:
      X-Weighbill-Signature: sha256=<hex(HMAC-SHA256(secret, 原始请求体))>
    """
    def __init__(self, url: str, secret: str = "", timeout: float = 5.0):
        if not url:
            raise ValueError("webhook 事件出口需要 webhook_url")
        self.url, self.secret, self.timeout = url, secret, timeout

    def publish(self, event: dict) -> None:
        body = json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers = {"Content-Type": "application/cloudevents+json; charset=utf-8"}
        if self.secret:
            sig = hmac.new(self.secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
            headers["X-Weighbill-Signature"] = "sha256=" + sig
        r = httpx.post(self.url, content=body, headers=headers, timeout=self.timeout)
        r.raise_for_status()

    def describe(self) -> dict:
        return {"adapter": "webhook", "url": self.url, "signed": bool(self.secret),
                "delivery": "at-most-once"}
