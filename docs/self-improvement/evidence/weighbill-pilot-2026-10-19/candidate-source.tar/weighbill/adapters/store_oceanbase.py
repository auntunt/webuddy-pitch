# -*- coding: utf-8 -*-
"""OceanBase(MySQL 模式)台账存储。私有部署多台应用节点共用一个库,靠这里保证:
- 版本号核对:UPDATE … WHERE id=? AND version=?,读出来以后被别的节点改过就拒绝(StaleRecord),不覆盖。
- 登记编号:事务里 SELECT … FOR UPDATE 锁住那一行再加一(OceanBase MySQL 模式没有 RETURNING)。
  前提是会话真的不在自动提交里——见 _conn(),PyMySQL 对 OceanBase 默认关不掉,要显式关并核对。
- 业务日期单独存一列 biz_date 并建索引(磅单日期,没认出来就用登记日期):日期筛选不用每次去 JSON 里抠,台账大了也快。

字段、行的映射与 SQLite 版共用(SQLiteRecordStore._to_row/_from_row),两边永远一致。
同样适用于 MySQL 8(开发、对照测试用)。
"""
from __future__ import annotations

import json
import re
import threading
from typing import Optional

from ..domain import LEGACY_DOC_TYPES, Record, normalize_date
from ..ports import RecordQuery, StaleRecord
from .store_sqlite import QUERY_LIMIT_CAP, SQLiteRecordStore, _MUTABLE

_COLS = """
  id VARCHAR(64) NOT NULL PRIMARY KEY,
  created_at VARCHAR(32) NOT NULL, uploader VARCHAR(200), batch_id VARCHAR(32), seq_in_batch INT,
  orig_path VARCHAR(255), crop_path VARCHAR(255), sig_path VARCHAR(255),
  fields LONGTEXT, warnings LONGTEXT, weight_ok INT, weight_msg VARCHAR(500),
  status VARCHAR(20), model VARCHAR(200), error TEXT, seg_model VARCHAR(200),
  reviewed_by VARCHAR(200), reviewed_at VARCHAR(32),
  doc_type VARCHAR(32) NOT NULL DEFAULT 'site_in', customer VARCHAR(200),
  stage VARCHAR(20) NOT NULL DEFAULT 'submitted',
  submitted_by VARCHAR(200), submitted_at VARCHAR(32), approved_by VARCHAR(200), approved_at VARCHAR(32),
  ref_no VARCHAR(40), voided_by VARCHAR(200), voided_at VARCHAR(32), void_reason VARCHAR(500),
  flag_note VARCHAR(500), source VARCHAR(80), version INT NOT NULL DEFAULT 0,
  origin_id VARCHAR(40) NOT NULL DEFAULT 'legacy',
  biz_date VARCHAR(10),
  UNIQUE KEY uk_ref_no (ref_no),
  KEY idx_created (created_at), KEY idx_type_date (doc_type, biz_date), KEY idx_batch (batch_id), KEY idx_source (source)
"""


def _biz_date(r: Record) -> str:
    return normalize_date((r.fields or {}).get("日期")) or (r.created_at or "")[:10]


class OceanBaseRecordStore:
    def __init__(self, host: str, port: int, user: str, password: str, database: str, connect_timeout: int = 5):
        import pymysql                                    # 可选依赖:pip install '.[oceanbase]'
        self._pymysql = pymysql
        self._kw = dict(host=host, port=int(port), user=user, password=password, database=database, charset="utf8mb4",
                        connect_timeout=connect_timeout, read_timeout=30, write_timeout=30, autocommit=False,
                        cursorclass=pymysql.cursors.DictCursor)
        self.database, self.host, self.port = database, host, port
        self._local = threading.local()
        self._init()

    # ------------------------------------------------------------ 连接(每线程一条,断了重连)
    def _conn(self):
        c = getattr(self._local, "conn", None)
        if c is not None:
            try:
                c.ping(reconnect=False)          # 不能让驱动自己重连:它重连出来的会话又回到自动提交
                return c
            except Exception:
                try:
                    c.close()
                except Exception:
                    pass
                self._local.conn = None
        c = self._open()
        self._local.conn = c
        return c

    def _open(self):
        """开一条新连接,保证不在自动提交里(所有连接都走这里,包括跨服务器锁用的那条)。"""
        c = self._pymysql.connect(**self._kw)
        # PyMySQL 只在它「以为」服务器开着自动提交时才发 SET autocommit=0;OceanBase 握手里报的状态和实际不符,
        # 于是会话其实一直是自动提交——每条语句单独提交,FOR UPDATE 的锁当场就放了,并发发号会重号(真库实测踩到)。
        # 所以连上就显式关掉,并核对;关不掉就不用这条连接(不能悄悄失去事务)。
        with c.cursor() as cur:
            cur.execute("SET autocommit=0")
            cur.execute("SELECT @@autocommit AS a")
            if int(cur.fetchone()["a"]) != 0:
                c.close()
                raise RuntimeError("数据库连接关不掉自动提交,事务不可靠,拒绝使用")
        return c

    def _run(self, fn):
        c = self._conn()
        try:
            with c.cursor() as cur:
                out = fn(cur)
            c.commit()
            return out
        except Exception:
            try:
                c.rollback()
            except Exception:
                self._local.conn = None
            raise

    def _init(self):
        def go(cur):
            cur.execute(f"CREATE TABLE IF NOT EXISTS records ({_COLS}) DEFAULT CHARSET=utf8mb4")
            cur.execute("SHOW COLUMNS FROM records LIKE 'origin_id'")
            if cur.fetchone() is None:
                cur.execute("ALTER TABLE records ADD COLUMN origin_id VARCHAR(40) NOT NULL DEFAULT 'legacy'")
                cur.execute("UPDATE records SET origin_id='' WHERE doc_type IN ('site_out','product_out')")
            cur.execute("CREATE TABLE IF NOT EXISTS ref_seq (scope VARCHAR(64) NOT NULL PRIMARY KEY, n BIGINT NOT NULL) "
                        "DEFAULT CHARSET=utf8mb4")
            cur.execute("CREATE TABLE IF NOT EXISTS history (seq BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, "
                        "record_id VARCHAR(64) NOT NULL, at VARCHAR(32) NOT NULL, actor VARCHAR(200), action VARCHAR(40) NOT NULL, "
                        "detail LONGTEXT, KEY idx_history_rec (record_id, seq)) DEFAULT CHARSET=utf8mb4")
            cur.execute("CREATE TABLE IF NOT EXISTS settings (k VARCHAR(64) NOT NULL PRIMARY KEY, value LONGTEXT NOT NULL) "
                        "DEFAULT CHARSET=utf8mb4")
            cur.execute("CREATE TABLE IF NOT EXISTS locks (name VARCHAR(128) NOT NULL PRIMARY KEY) DEFAULT CHARSET=utf8mb4")
            for old, new in LEGACY_DOC_TYPES.items():
                cur.execute("UPDATE records SET doc_type=%s WHERE doc_type=%s", (new, old))
        self._run(go)

    # ------------------------------------------------------------ 端口
    @staticmethod
    def _row(r: Record) -> dict:
        row = SQLiteRecordStore._to_row(r)
        row["biz_date"] = _biz_date(r)
        return row

    def insert(self, record: Record) -> None:
        row = self._row(record)
        cols = ", ".join(row)
        self._run(lambda cur: cur.execute(f"INSERT INTO records ({cols}) VALUES ({', '.join(['%s'] * len(row))})",
                                          list(row.values())))

    def get(self, record_id: str) -> Optional[Record]:
        def go(cur):
            cur.execute("SELECT * FROM records WHERE id=%s", (record_id,))
            return cur.fetchone()
        row = self._run(go)
        return SQLiteRecordStore._from_row(row) if row else None

    def query(self, q: RecordQuery) -> list[Record]:
        sql, args = "SELECT * FROM records WHERE 1=1", []
        if q.date_from: sql += " AND created_at >= %s"; args.append(q.date_from)
        if q.date_to:   sql += " AND created_at <= %s"; args.append(q.date_to + "T23:59:59")
        if q.status:    sql += " AND status = %s"; args.append(q.status)
        if q.q:
            like = "%" + q.q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            sql += " AND (fields LIKE %s OR ref_no LIKE %s)"; args += [like, like]
        if q.origin_id: sql += " AND origin_id = %s"; args.append(q.origin_id)
        if q.doc_type:  sql += " AND doc_type = %s"; args.append(q.doc_type)
        if q.stage:     sql += " AND stage = %s"; args.append(q.stage)
        if q.voided == "only":  sql += " AND voided_at IS NOT NULL"
        elif q.voided != "all": sql += " AND voided_at IS NULL"
        if q.flagged:   sql += " AND flag_note IS NOT NULL"
        if q.source:    sql += " AND source = %s"; args.append(q.source)
        if q.batch_id:  sql += " AND batch_id = %s"; args.append(q.batch_id)
        if q.ticket_from: sql += " AND biz_date >= %s"; args.append(q.ticket_from)
        if q.ticket_to:   sql += " AND biz_date <= %s"; args.append(q.ticket_to)
        sql += " ORDER BY created_at DESC, id DESC"
        if q.limit is not None:
            sql += " LIMIT %s"; args.append(min(q.limit, QUERY_LIMIT_CAP))

        def go(cur):
            cur.execute(sql, args)
            return cur.fetchall()
        return [SQLiteRecordStore._from_row(r) for r in self._run(go)]

    def update(self, record: Record) -> None:
        row = self._row(record)
        sets = ", ".join(f"{c}=%s" for c in (*_MUTABLE, "biz_date"))
        vals = [row[c] for c in (*_MUTABLE, "biz_date")]

        def go(cur):
            n = cur.execute(f"UPDATE records SET {sets}, version = version + 1 WHERE id=%s AND version=%s",
                            vals + [record.id, record.version])
            if n == 0:
                cur.execute("SELECT 1 FROM records WHERE id=%s", (record.id,))
                if cur.fetchone():
                    raise StaleRecord(record.id)
                raise KeyError(record.id)
        self._run(go)
        record.version += 1

    def next_ref(self, scope: str) -> int:
        def go(cur):
            cur.execute("INSERT IGNORE INTO ref_seq (scope, n) VALUES (%s, 0)", (scope,))
            cur.execute("SELECT n FROM ref_seq WHERE scope=%s FOR UPDATE", (scope,))
            n = int(cur.fetchone()["n"]) + 1
            cur.execute("UPDATE ref_seq SET n=%s WHERE scope=%s", (n, scope))
            return n
        return self._run(go)

    def without_ref(self) -> list[Record]:
        def go(cur):
            cur.execute("SELECT * FROM records WHERE ref_no IS NULL ORDER BY created_at, seq_in_batch, id")
            return cur.fetchall()
        return [SQLiteRecordStore._from_row(r) for r in self._run(go)]

    def assign_ref(self, record_id: str, ref_no: str) -> bool:
        return self._run(lambda cur: cur.execute("UPDATE records SET ref_no=%s WHERE id=%s AND ref_no IS NULL",
                                                 (ref_no, record_id))) == 1

    def append_history(self, record_id: str, at: str, actor: str, action: str, detail: dict) -> None:
        self._run(lambda cur: cur.execute("INSERT INTO history (record_id, at, actor, action, detail) VALUES (%s,%s,%s,%s,%s)",
                                          (record_id, at, actor, action, json.dumps(detail, ensure_ascii=False))))

    def history(self, record_id: str) -> list[dict]:
        def go(cur):
            cur.execute("SELECT * FROM history WHERE record_id=%s ORDER BY seq", (record_id,))
            return cur.fetchall()
        return [{"at": r["at"], "actor": r["actor"], "action": r["action"], "detail": json.loads(r["detail"] or "{}")}
                for r in self._run(go)]

    def get_setting(self, key: str):
        def go(cur):
            cur.execute("SELECT value FROM settings WHERE k=%s", (key,))
            return cur.fetchone()
        row = self._run(go)
        return json.loads(row["value"]) if row else None

    def set_setting(self, key: str, value: dict) -> None:
        self._run(lambda cur: cur.execute(
            "INSERT INTO settings (k, value) VALUES (%s, %s) ON DUPLICATE KEY UPDATE value=VALUES(value)",
            (key, json.dumps(value, ensure_ascii=False))))

    def named_lock(self, name: str):
        """跨服务器互斥:单独开一条连接,事务里 SELECT … FOR UPDATE 锁住 locks 表里那一行,用完提交放锁。
        持锁的节点要是死了,连接断开,数据库自动放锁,不会永久卡住。"""
        import contextlib

        @contextlib.contextmanager
        def held():
            c = self._open()
            try:
                with c.cursor() as cur:
                    cur.execute("INSERT IGNORE INTO locks (name) VALUES (%s)", (name,))
                    c.commit()
                    cur.execute("SELECT name FROM locks WHERE name=%s FOR UPDATE", (name,))
                    cur.fetchall()
                yield
            finally:
                try:
                    c.commit()
                finally:
                    c.close()
        return held()

    def ensure_ref_at_least(self, scope: str, n: int) -> None:
        def go(cur):
            cur.execute("INSERT IGNORE INTO ref_seq (scope, n) VALUES (%s, 0)", (scope,))
            cur.execute("SELECT n FROM ref_seq WHERE scope=%s FOR UPDATE", (scope,))
            if int(cur.fetchone()["n"]) < int(n):
                cur.execute("UPDATE ref_seq SET n=%s WHERE scope=%s", (int(n), scope))
        self._run(go)

    def ping(self) -> None:
        def go(cur):
            cur.execute("SELECT 1 AS ok")
            cur.execute("INSERT INTO settings (k, value) VALUES ('_ping', '1') ON DUPLICATE KEY UPDATE value='1'")
        self._run(go)                                      # 真写一次:只读、权限不够在这里就暴露

    def describe(self) -> dict:
        return {"adapter": "oceanbase", "host": self.host, "port": self.port, "database": self.database}
