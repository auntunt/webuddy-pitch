# -*- coding: utf-8 -*-
"""无显卡的识别适配器:RapidOCR(PP-OCR 模型,onnxruntime 跑在 CPU 上)+ ocr_fields 的规则。

- 数据不出服务器,不需要 API key,也没有按次费用。实测每张磅单 1 秒左右(Apple M1 单进程)。
- OCR 是 CPU 密集的同步调用,放到线程里跑,不卡住 Web 服务。
- 引擎可注入(测试用假引擎,不需要装 rapidocr);默认第一次用时才加载。
"""
from __future__ import annotations

import asyncio
import threading
from typing import Callable, Optional

from PIL import Image

from .. import ocr_fields as F

ENGINE_NAME = "rapidocr-ppocr"


def _default_engine():
    from rapidocr import RapidOCR            # 可选依赖:pip install 'weighbill[cpu-ocr]'
    import numpy as np
    eng = RapidOCR()

    def run(im: Image.Image):
        r = eng(np.array(im.convert("RGB")))
        return list(r.boxes) if r.boxes is not None else [], list(r.txts or [])
    return run


class CpuOcrVision:
    def __init__(self, engine: Optional[Callable] = None, anchors=F.DEFAULT_ANCHORS, serial_prefixes=()):
        self._engine, self._lock = engine, threading.Lock()
        self.anchors, self.serial_prefixes = tuple(anchors), tuple(serial_prefixes)

    def _get_engine(self):
        with self._lock:
            if self._engine is None:
                self._engine = _default_engine()
            return self._engine

    async def _items(self, im: Image.Image) -> tuple[list[dict], tuple[int, int]]:
        boxes, texts = await asyncio.to_thread(self._get_engine(), im)
        return F.items_of(boxes, texts), im.size

    @staticmethod
    def _pct(box, size, pad=0.0) -> dict:
        (x0, y0, x1, y1), (w, h) = box, size
        px, py = (x1 - x0) * pad, (y1 - y0) * pad
        x0, y0, x1, y1 = max(0, x0 - px), max(0, y0 - py), min(w, x1 + px), min(h, y1 + py)
        return {"x": x0 / w * 100, "y": y0 / h * 100, "w": (x1 - x0) / w * 100, "h": (y1 - y0) / h * 100}

    async def segment(self, image):
        items, size = await self._items(image)
        return [self._pct(F.bbox(g), size, pad=0.04) for g in F.split_tickets(items, self.anchors)]

    async def recognize(self, receipt):
        items, size = await self._items(receipt)
        fields = F.parse_fields(items, self.serial_prefixes)
        sb = F.signer_box(items)
        fields["签名框"] = self._pct(sb, size) if sb else None
        return fields

    async def locate_signature(self, receipt):
        items, size = await self._items(receipt)
        sb = F.signer_box(items)
        return self._pct(sb, size) if sb else None

    async def reread_weights(self, receipt):
        """首读重量对不上账时:放大一倍再认一遍(小字、拍远了的照片放大后明显好)。"""
        big = receipt.resize((receipt.width * 2, receipt.height * 2), Image.LANCZOS)
        items, _ = await self._items(big)
        f = F.parse_fields(items, self.serial_prefixes)
        return {k: f.get(k) for k in ("总重", "皮重", "净重")}

    def describe(self) -> dict:
        try:
            import rapidocr  # noqa: F401
            ok = True
        except Exception:
            ok = self._engine is not None
        return {"adapter": "cpu_ocr", "seg_model": ENGINE_NAME, "rec_model": ENGINE_NAME + "+rules",
                "configured": ok, "gpu": False}
