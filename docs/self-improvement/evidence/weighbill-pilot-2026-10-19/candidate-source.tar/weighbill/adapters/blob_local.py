# -*- coding: utf-8 -*-
"""本地目录文件存储。键 = 相对 data 目录的路径,URL = /files/<key>(与 0.1 版页面兼容)。"""
from __future__ import annotations

import os, uuid
from pathlib import Path, PurePosixPath


def check_key(key: str) -> str:
    p = PurePosixPath(key)
    if not key or key.startswith("/") or "\\" in key or ".." in p.parts or p.is_absolute():
        raise ValueError(f"非法的存储键: {key!r}")
    return key


class LocalBlobStore:
    def __init__(self, root: Path, url_prefix: str = "/files/"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.url_prefix = url_prefix

    def _path(self, key: str) -> Path:
        return self.root / check_key(key)

    def put(self, key: str, data: bytes, content_type: str) -> str:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + f".{uuid.uuid4().hex}.tmp")
        tmp.write_bytes(data)
        os.replace(tmp, p)                 # 原子落盘:读方要么看不到,要么看到完整文件
        return key

    def open(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).is_file()

    def url(self, key: str) -> str:
        return self.url_prefix + check_key(key)

    def ping(self) -> None:
        probe = self.root / f".ping-{uuid.uuid4().hex}"
        probe.write_bytes(b"ok"); probe.unlink()

    def describe(self) -> dict:
        return {"adapter": "local", "root": str(self.root), "url_prefix": self.url_prefix}
