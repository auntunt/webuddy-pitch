# -*- coding: utf-8 -*-
"""S3 协议的对象存储(私有部署:RustFS、Ceph RGW、各家信创对象存储都走这个协议)。

- 写:带 Content-MD5,存储端校验不过就拒收——网络里坏了一位也不会悄悄存一张坏图。
- 读:本机磁盘做读缓存(按大小封顶,先删最久没用的)。同一张图看第二次不再去对象存储;对象存储短暂抖动时,
  看过的图照样能看。写也顺手放一份进缓存,刚拍完的预览不用再取一次。
- 读缓存的前提:同一个键只写一次内容(重新处理、生成预览写出来的都是同样的字节)。多台节点各有自己的缓存,
  要是哪天允许同一个键写不同内容,就得改成按 ETag 校验缓存,否则别的节点会一直给旧图。
- 写失败直接抛错:上传流程会把照片留在服务器暂存区稍后重试(见 spool.py),不会因此丢图。
- 密钥只在配置里,describe()/健康检查不带。
"""
from __future__ import annotations

import base64
import hashlib
import os
import threading
from pathlib import Path
from typing import Optional

from .blob_local import check_key


class S3BlobStore:
    def __init__(self, endpoint: str, access_key: str, secret_key: str, bucket: str, region: str = "us-east-1",
                 cache_dir: Optional[Path] = None, cache_max_mb: int = 2048, url_prefix: str = "/files/",
                 client=None):
        self.endpoint, self.bucket, self.region = endpoint, bucket, region
        self.url_prefix = url_prefix
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.cache_max = cache_max_mb * 1024 * 1024
        self._lock = threading.Lock()
        if client is None:
            import boto3                                   # 可选依赖:pip install '.[s3]'
            from botocore.config import Config
            client = boto3.client("s3", endpoint_url=endpoint, aws_access_key_id=access_key,
                                  aws_secret_access_key=secret_key, region_name=region,
                                  config=Config(signature_version="s3v4", s3={"addressing_style": "path"},
                                                retries={"max_attempts": 3, "mode": "standard"},
                                                connect_timeout=5, read_timeout=30))
        self.s3 = client
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------ 本机读缓存
    def _cpath(self, key: str) -> Optional[Path]:
        return self.cache_dir / hashlib.sha256(key.encode()).hexdigest() if self.cache_dir else None

    def _cache_put(self, key: str, data: bytes) -> None:
        p = self._cpath(key)
        if p is None:
            return
        try:
            tmp = p.with_name(p.name + ".tmp")
            tmp.write_bytes(data); os.replace(tmp, p)
            self._trim()
        except OSError:
            pass                                          # 缓存写不下不影响正事

    def _trim(self) -> None:
        with self._lock:
            files = [f for f in self.cache_dir.iterdir() if f.is_file() and not f.name.endswith(".tmp")]
            total = sum(f.stat().st_size for f in files)
            if total <= self.cache_max:
                return
            for f in sorted(files, key=lambda f: f.stat().st_atime):
                total -= f.stat().st_size
                f.unlink(missing_ok=True)
                if total <= self.cache_max * 0.8:
                    break

    # ------------------------------------------------------------ 端口
    def put(self, key: str, data: bytes, content_type: str) -> str:
        key = check_key(key)
        md5 = base64.b64encode(hashlib.md5(data).digest()).decode()
        self.s3.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type, ContentMD5=md5)
        self._cache_put(key, data)
        return key

    def open(self, key: str) -> bytes:
        key = check_key(key)
        p = self._cpath(key)
        if p is not None and p.exists():
            try:
                os.utime(p)                               # 记一下最近用过
                return p.read_bytes()
            except OSError:
                pass
        try:
            data = self.s3.get_object(Bucket=self.bucket, Key=key)["Body"].read()
        except self.s3.exceptions.NoSuchKey:
            raise FileNotFoundError(key)
        except Exception as e:                            # 有的实现对不存在的键回 404 而不是 NoSuchKey
            if getattr(e, "response", {}).get("Error", {}).get("Code") in ("404", "NoSuchKey", "NotFound"):
                raise FileNotFoundError(key)
            raise
        self._cache_put(key, data)
        return data

    def exists(self, key: str) -> bool:
        try:
            self.s3.head_object(Bucket=self.bucket, Key=check_key(key))
            return True
        except Exception as e:
            if getattr(e, "response", {}).get("Error", {}).get("Code") in ("404", "NoSuchKey", "NotFound"):
                return False
            raise

    def url(self, key: str) -> str:
        return self.url_prefix + check_key(key)

    def ping(self) -> None:
        """真写、真读、真删一次:只看「连得上」会把只读、桶不对、权限不够当成好的。"""
        k = "health/ping"
        self.s3.put_object(Bucket=self.bucket, Key=k, Body=b"ok")
        assert self.s3.get_object(Bucket=self.bucket, Key=k)["Body"].read() == b"ok"
        self.s3.delete_object(Bucket=self.bucket, Key=k)

    def describe(self) -> dict:
        return {"adapter": "s3", "endpoint": self.endpoint, "bucket": self.bucket,
                "cache_dir": str(self.cache_dir) if self.cache_dir else None}
