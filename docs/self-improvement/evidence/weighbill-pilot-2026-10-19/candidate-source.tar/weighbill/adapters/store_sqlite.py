# -*- coding: utf-8 -*-
"""SQLite 台账存储。表结构与 0.1 版兼容(旧库可直接打开),新增列按需迁移。"""
from __future__ import annotations

import json, sqlite3
from pathlib import Path
from typing import Optional

from ..domain import LEGACY_DOC_TYPES, Record
from ..ports import RecordQuery, StaleRecord

_BASE_COLS = ("id, created_at, uploader, batch_id, seq_in_batch, orig_path, crop_path, sig_path, "
              "fields, warnings, weight_ok, weight_msg, status, model, error")
# 0.2.0 新增列:旧库打开时补齐,旧行取 NULL
_ADDED_COLS = {"seg_model": "TEXT", "reviewed_by": "TEXT", "reviewed_at": "TEXT",
               # 0.3.0:老记录都是进场单、且早已在台账里可见,所以默认「进场/未审核」
               "doc_type": "TEXT NOT NULL DEFAULT 'site_in'", "customer": "TEXT",
               "stage": "TEXT NOT NULL DEFAULT 'submitted'",
               "submitted_by": "TEXT", "submitted_at": "TEXT", "approved_by": "TEXT", "approved_at": "TEXT",
               # 0.4.2 登记编号:插入时带上,之后不在 _MUTABLE 里(改不了);老记录由 assign_ref 补发一次
               "ref_no": "TEXT",
               # 0.5.0 作废、有疑问
               "voided_by": "TEXT", "voided_at": "TEXT", "void_reason": "TEXT", "flag_note": "TEXT", "source": "TEXT",
               # 0.6.0 乐观锁版本号
               "version": "INTEGER NOT NULL DEFAULT 0", "origin_id": "TEXT NOT NULL DEFAULT 'legacy'"}
_MUTABLE = ("fields", "warnings", "weight_ok", "weight_msg", "status", "reviewed_by", "reviewed_at",
            "doc_type", "customer", "stage", "submitted_by", "submitted_at", "approved_by", "approved_at",
            "voided_by", "voided_at", "void_reason", "flag_note", "origin_id")
QUERY_LIMIT_CAP = 2000


class SQLiteRecordStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _conn(self):
        c = sqlite3.connect(self.path)
        c.row_factory = sqlite3.Row
        return c

    def _init(self):
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS records(
                id TEXT PRIMARY KEY,
                created_at TEXT, uploader TEXT, batch_id TEXT, seq_in_batch INTEGER,
                orig_path TEXT, crop_path TEXT, sig_path TEXT,
                fields TEXT, warnings TEXT, weight_ok INTEGER, weight_msg TEXT,
                status TEXT, model TEXT, error TEXT)""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_created ON records(created_at)")
            have = {r["name"] for r in c.execute("PRAGMA table_info(records)")}
            for col, typ in _ADDED_COLS.items():
                if col not in have:
                    c.execute(f"ALTER TABLE records ADD COLUMN {col} {typ}")
            if "origin_id" not in have:
                c.execute("UPDATE records SET origin_id='' WHERE doc_type IN ('site_out','product_out')")
            c.execute("CREATE INDEX IF NOT EXISTS idx_origin_type ON records(origin_id, doc_type)")
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_ref_no ON records(ref_no) WHERE ref_no IS NOT NULL")
            c.execute("CREATE TABLE IF NOT EXISTS ref_seq(scope TEXT PRIMARY KEY, n INTEGER NOT NULL)")
            # 0.5.0 修改记录:只追加,不改不删(结算台账要能查「谁、什么时候、把什么从几改成几」)
            c.execute("CREATE TABLE IF NOT EXISTS history(seq INTEGER PRIMARY KEY AUTOINCREMENT, record_id TEXT NOT NULL, "
                      "at TEXT NOT NULL, actor TEXT, action TEXT NOT NULL, detail TEXT)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_history_rec ON history(record_id, seq)")
            c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            # 0.4.0:单据类型键去掉具体厂商(byd_out → supplier_out 等),老库原地改
            for old, new in LEGACY_DOC_TYPES.items():
                c.execute("UPDATE records SET doc_type=? WHERE doc_type=?", (new, old))

    @staticmethod
    def _to_row(r: Record) -> dict:
        return dict(id=r.id, created_at=r.created_at, uploader=r.uploader, batch_id=r.batch_id,
                    seq_in_batch=r.seq_in_batch, orig_path=r.orig_key, crop_path=r.crop_key,
                    sig_path=r.sig_key, fields=json.dumps(r.fields, ensure_ascii=False),
                    warnings=json.dumps(r.warnings, ensure_ascii=False), weight_ok=r.weight_ok,
                    weight_msg=r.weight_msg, status=r.status, model=r.model, error=r.error,
                    seg_model=r.seg_model, reviewed_by=r.reviewed_by, reviewed_at=r.reviewed_at,
                    doc_type=r.doc_type, customer=r.customer, stage=r.stage,
                    submitted_by=r.submitted_by, submitted_at=r.submitted_at,
                    approved_by=r.approved_by, approved_at=r.approved_at, ref_no=r.ref_no,
                    voided_by=r.voided_by, voided_at=r.voided_at, void_reason=r.void_reason, flag_note=r.flag_note,
                    source=r.source, version=r.version, origin_id=r.origin_id)

    @staticmethod
    def _from_row(row) -> Record:
        d = dict(row)
        return Record(id=d["id"], created_at=d["created_at"], uploader=d["uploader"],
                      batch_id=d["batch_id"], seq_in_batch=d["seq_in_batch"],
                      orig_key=d["orig_path"], crop_key=d["crop_path"], sig_key=d["sig_path"],
                      fields=json.loads(d["fields"] or "{}"), warnings=json.loads(d["warnings"] or "[]"),
                      weight_ok=d["weight_ok"], weight_msg=d["weight_msg"], status=d["status"],
                      model=d["model"], error=d["error"], seg_model=d.get("seg_model"),
                      reviewed_by=d.get("reviewed_by"), reviewed_at=d.get("reviewed_at"),
                      doc_type=d.get("doc_type") or "site_in", customer=d.get("customer"),
                      stage=d.get("stage") or "submitted",
                      submitted_by=d.get("submitted_by"), submitted_at=d.get("submitted_at"),
                      approved_by=d.get("approved_by"), approved_at=d.get("approved_at"), ref_no=d.get("ref_no"),
                      voided_by=d.get("voided_by"), voided_at=d.get("voided_at"), void_reason=d.get("void_reason"),
                      flag_note=d.get("flag_note"), source=d.get("source"), version=d.get("version") or 0, origin_id=d.get("origin_id", "legacy"))

    def insert(self, record: Record) -> None:
        row = self._to_row(record)
        cols = ", ".join(row)
        with self._conn() as c:
            c.execute(f"INSERT INTO records({cols}) VALUES({', '.join(':' + k for k in row)})", row)

    def get(self, record_id: str) -> Optional[Record]:
        with self._conn() as c:
            row = c.execute("SELECT * FROM records WHERE id=?", (record_id,)).fetchone()
        return self._from_row(row) if row else None

    def query(self, q: RecordQuery) -> list[Record]:
        sql = "SELECT * FROM records WHERE 1=1"; args = []
        if q.date_from: sql += " AND created_at >= ?"; args.append(q.date_from)
        if q.date_to:   sql += " AND created_at <= ?"; args.append(q.date_to + "T23:59:59")
        if q.status:    sql += " AND status = ?"; args.append(q.status)
        if q.q:         sql += " AND (fields LIKE ? OR ref_no LIKE ?)"; args += [f"%{q.q}%", f"%{q.q}%"]
        if q.origin_id: sql += " AND origin_id = ?"; args.append(q.origin_id)
        if q.doc_type:  sql += " AND doc_type = ?"; args.append(q.doc_type)
        if q.stage:     sql += " AND stage = ?"; args.append(q.stage)
        if q.voided == "only":  sql += " AND voided_at IS NOT NULL"
        elif q.voided != "all": sql += " AND voided_at IS NULL"
        if q.flagged:   sql += " AND flag_note IS NOT NULL"
        if q.source:    sql += " AND source = ?"; args.append(q.source)
        if q.batch_id:  sql += " AND batch_id = ?"; args.append(q.batch_id)
        # 业务日期 = 磅单「日期」;没认出来的按登记日期算,否则一加日期筛选这张单就看不见了
        biz = "COALESCE(NULLIF(json_extract(fields, '$.\"日期\"'), ''), substr(created_at, 1, 10))"
        if q.ticket_from: sql += f" AND {biz} >= ?"; args.append(q.ticket_from)
        if q.ticket_to:   sql += f" AND {biz} <= ?"; args.append(q.ticket_to)
        sql += " ORDER BY created_at DESC"
        if q.limit is not None:
            sql += " LIMIT ?"; args.append(min(q.limit, QUERY_LIMIT_CAP))
        with self._conn() as c:
            return [self._from_row(r) for r in c.execute(sql, args).fetchall()]

    def update(self, record: Record) -> None:
        row = self._to_row(record)
        with self._conn() as c:
            sets = ", ".join(f"{c_}=:{c_}" for c_ in _MUTABLE)
            cur = c.execute(f"UPDATE records SET {sets}, version = version + 1 WHERE id=:id AND version=:version", row)
            if cur.rowcount == 0:
                if c.execute("SELECT 1 FROM records WHERE id=?", (record.id,)).fetchone():
                    raise StaleRecord(record.id)
                raise KeyError(record.id)
        record.version += 1

    def next_ref(self, scope: str) -> int:
        """登记编号的流水号:同一 scope(前缀+日期)从 1 起,一条语句里加一并取回,不会两次发同一个号。"""
        with self._conn() as c:
            return c.execute("INSERT INTO ref_seq(scope, n) VALUES(?, 1) ON CONFLICT(scope) DO UPDATE SET n = n + 1 "
                             "RETURNING n", (scope,)).fetchone()[0]

    def without_ref(self) -> list[Record]:
        """还没有登记编号的记录(老库),按登记先后。补号用,不封顶。"""
        with self._conn() as c:
            return [self._from_row(r) for r in c.execute(
                "SELECT * FROM records WHERE ref_no IS NULL ORDER BY created_at, seq_in_batch, id").fetchall()]

    def assign_ref(self, record_id: str, ref_no: str) -> bool:
        """只给还没有编号的记录发号;已经有号的绝不改。返回是否真的写了。"""
        with self._conn() as c:
            return c.execute("UPDATE records SET ref_no=? WHERE id=? AND ref_no IS NULL", (ref_no, record_id)).rowcount == 1

    def append_history(self, record_id: str, at: str, actor: str, action: str, detail: dict) -> None:
        with self._conn() as c:
            c.execute("INSERT INTO history(record_id, at, actor, action, detail) VALUES(?,?,?,?,?)",
                      (record_id, at, actor, action, json.dumps(detail, ensure_ascii=False)))

    def history(self, record_id: str) -> list[dict]:
        with self._conn() as c:
            return [{"at": r["at"], "actor": r["actor"], "action": r["action"], "detail": json.loads(r["detail"] or "{}")}
                    for r in c.execute("SELECT * FROM history WHERE record_id=? ORDER BY seq", (record_id,))]

    def get_setting(self, key: str):
        with self._conn() as c:
            row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return json.loads(row["value"]) if row else None

    def set_setting(self, key: str, value: dict) -> None:
        with self._conn() as c:
            c.execute("INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                      (key, json.dumps(value, ensure_ascii=False)))

    def named_lock(self, name: str):
        """文件锁(flock):同一台机器上的多个进程之间也互斥。SQLite 只用于单机,够用。"""
        import contextlib, fcntl, hashlib
        d = self.path.parent / (self.path.name + ".locks")
        d.mkdir(parents=True, exist_ok=True)
        p = d / (hashlib.sha1(name.encode()).hexdigest()[:16] + ".lock")

        @contextlib.contextmanager
        def held():
            with open(p, "a+") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        return held()

    def ensure_ref_at_least(self, scope: str, n: int) -> None:
        with self._conn() as c:
            c.execute("INSERT INTO ref_seq(scope, n) VALUES(?, ?) ON CONFLICT(scope) DO UPDATE SET n = MAX(n, excluded.n)",
                      (scope, int(n)))

    def ping(self) -> None:
        with self._conn() as c:
            c.execute("SELECT 1 FROM records LIMIT 1").fetchall()
            c.execute("CREATE TEMP TABLE IF NOT EXISTS _ping(x)")   # 真写一次,只读挂载会在这里失败

    def describe(self) -> dict:
        return {"adapter": "sqlite", "path": str(self.path)}
