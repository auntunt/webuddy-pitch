# -*- coding: utf-8 -*-
"""命令行入站适配器。version / manifest 不碰数据库、不连网络。"""
from __future__ import annotations

import argparse, asyncio, json, sys
from pathlib import Path

from . import __version__


def _dump(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="weighbill", description="称重单采集与台账子系统")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("version", help="打印版本")
    sub.add_parser("manifest", help="打印子系统清单(不连库不联网)")
    sub.add_parser("health", help="检查各端口可用性;不可用时退出码 1")
    p = sub.add_parser("serve", help="启动 HTTP 服务")
    p.add_argument("--host", default="0.0.0.0"); p.add_argument("--port", type=int, default=8000)
    p = sub.add_parser("ingest", help="登记一张或多张照片")
    p.add_argument("images", nargs="+", type=Path); p.add_argument("--uploader", default="cli")
    p = sub.add_parser("verify", help="核对:图在不在、处理完的上传有没有登记、有没有卡住的;有问题退出码 1")
    p.add_argument("--fix", action="store_true", help="把「处理完却找不到登记」的照片重新排队登记")
    p = sub.add_parser("migrate", help="把台账、图片、修改记录、设置原样搬到另一套部署(如 SQLite+本地盘 → OceanBase+对象存储)")
    p.add_argument("--source-config", type=Path, required=True); p.add_argument("--source-data-dir", default="")
    p.add_argument("--target-config", type=Path, required=True); p.add_argument("--target-data-dir", default="")
    p.add_argument("--dry-run", action="store_true", help="只看要搬多少,不写目标")
    p = sub.add_parser("export", help="导出 CSV 到标准输出")
    for a in ("--date-from", "--date-to", "--q", "--status"):
        p.add_argument(a, default="")
    args = ap.parse_args(argv)

    if args.cmd == "version":
        print(__version__); return 0
    if args.cmd == "manifest":
        from .config import load_settings
        from .manifest import build_manifest
        try:
            s = load_settings()
        except Exception as e:           # 配置坏了清单也要能看,但要说出来
            m = build_manifest(None); m["config_error"] = str(e); _dump(m); return 1
        _dump(build_manifest(s)); return 0

    if args.cmd == "migrate":
        from .config import load_settings
        from .migrate import main as migrate_main
        src = load_settings(env={}, config_path=args.source_config)
        dst = load_settings(env={}, config_path=args.target_config)
        if args.source_data_dir: src.data_dir = args.source_data_dir
        if args.target_data_dir: dst.data_dir = args.target_data_dir
        return migrate_main(src, dst, dry_run=args.dry_run)

    from .bootstrap import build_service      # 以下命令才需要装配服务
    if args.cmd == "serve":
        import uvicorn
        from .http_api import create_app
        uvicorn.run(create_app(build_service()), host=args.host, port=args.port); return 0
    svc = build_service()
    if args.cmd == "health":
        h = svc.health(); _dump(h); return 0 if h["status"] != "down" else 1
    if args.cmd == "ingest":
        rc = 0
        for img in args.images:
            recs = asyncio.run(svc.ingest(img.read_bytes(), args.uploader))
            for r in recs:
                v = svc.record_view(r)
                print(json.dumps({"image": str(img), "id": v["id"], "status": v["status"],
                                  "warnings": v["warnings"], "fields": v["fields"]}, ensure_ascii=False))
                rc |= v["status"] == "failed"
        return int(rc)
    if args.cmd == "verify":
        r = svc.verify(fix=args.fix); _dump(r)
        if not r["ok"]:
            import logging
            logging.getLogger("weighbill.verify").error("核对发现问题:%s", {k: len(v) for k, v in r.items() if isinstance(v, list) and v})
        return 0 if r["ok"] else 1
    if args.cmd == "export":
        from .ports import RecordQuery
        sys.stdout.write(svc.export_csv(RecordQuery(args.date_from, args.date_to, args.q, args.status)))
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
