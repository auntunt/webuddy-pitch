# -*- coding: utf-8 -*-
"""子系统清单:给「要接入它的系统」看的机器可读自描述。

生成清单不连数据库、不连网络、不读密钥——宿主在决定是否启用本子系统之前就要能读它。
"""
from __future__ import annotations

from dataclasses import fields as dc_fields
from typing import Optional

from . import SUBSYSTEM_ID, __version__, adapters
from .config import Settings, SECRET_KEYS
from .domain import FIELDS, KEY_FIELDS, STATUSES
from .ports import EVENT_TYPES

PORTS = {
    "vision": "VisionModel —— 图片 -> 单据框 / 字段 / 签名框",
    "record_store": "RecordStore —— 台账记录持久化",
    "blob_store": "BlobStore —— 原图、单据图、签名图留存",
    "event_sink": "EventSink —— 台账变化通知下游(CloudEvents 1.0)",
    "identity": "IdentityResolver —— 从网关注入的请求头认出操作人",
}
_SELECTOR = {"vision": "vision_adapter", "record_store": "record_store",
             "blob_store": "blob_store", "event_sink": "event_sink"}

API_V1 = [
    {"method": "GET",   "path": "/api/v1/manifest",           "desc": "本清单"},
    {"method": "GET",   "path": "/api/v1/health",             "desc": "各端口可用性;down 时 503"},
    {"method": "POST",  "path": "/api/v1/records",            "desc": "multipart 字段 photo;201 返回登记的记录"},
    {"method": "GET",   "path": "/api/v1/records",            "desc": "参数 date_from/date_to/q/status/limit"},
    {"method": "GET",   "path": "/api/v1/records/{id}",       "desc": "单条"},
    {"method": "PATCH", "path": "/api/v1/records/{id}",       "desc": 'body {"fields":{...}};重跑校验,标记 reviewed'},
    {"method": "GET",   "path": "/api/v1/records/export.csv", "desc": "同筛选参数,带 BOM"},
]
API_LEGACY = ["POST /api/upload", "GET /api/records", "GET /api/records/{id}",
              "PATCH /api/records/{id}", "GET /api/export.csv", "GET /api/config"]


def build_manifest(settings: Optional[Settings] = None) -> dict:
    selected = {}
    if settings is not None:
        selected = {p: getattr(settings, a) for p, a in _SELECTOR.items()}
        selected["identity"] = "header"
    return {
        "subsystem": SUBSYSTEM_ID,
        "name": "称重单采集与台账",
        "version": __version__,
        "manifest_version": 1,
        "interfaces": {
            "http": {"v1": API_V1, "legacy": API_LEGACY, "openapi": "/openapi.json"},
            "cli": ["weighbill version", "weighbill manifest", "weighbill health",
                    "weighbill serve", "weighbill ingest <图片>...", "weighbill export"],
            "python": "weighbill.bootstrap.build_service() -> WeighbillService",
            "pages": {"capture": "/", "report": "/report"},
        },
        "ports": {p: {"contract": desc, "available": adapters.available()[p],
                      "selected": selected.get(p)} for p, desc in PORTS.items()},
        "events": {"format": "CloudEvents 1.0 structured JSON", "source": f"/{SUBSYSTEM_ID}",
                   "types": list(EVENT_TYPES)},
        "record": {"fields": FIELDS, "key_fields": list(KEY_FIELDS), "statuses": list(STATUSES)},
        "identity": {"header": settings.identity_header if settings else "X-Portal-User",
                     "note": "系统不做登录;身份由门户/网关注入。UTF-8 原文会被正确还原。"},
        "config_keys": [f.name for f in dc_fields(Settings) if f.name != "config_file"],
        "secret_config_keys": list(SECRET_KEYS),
    }
