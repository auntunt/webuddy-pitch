# -*- coding: utf-8 -*-
"""文件存储键的形状约定。对外只允许取单据影像,不允许取库文件、事件出箱等。"""
import re

_IMAGE_KEY = re.compile(r"^images/\d{8}/[0-9a-f]{12}_(orig\.(?:jpg|png|webp|gif|tiff|bmp|heic|avif|bin)|orig_[tm]\.jpg|orig\.(?:png|webp|gif|tiff|bmp|heic|avif|bin)_[tm]\.jpg|r\d+\.jpg|r\d+_[tm]\.jpg|r\d+_sig\.png)$")
# 预览尺寸:_t 列表缩略图,_m 详情里看的中图;原图不动。第一次有人看时从原图生成并存下(老数据自动补上)
_VARIANT = re.compile(r"^(?P<base>images/\d{8}/[0-9a-f]{12}_(?:orig(?:\.(?:png|webp|gif|tiff|bmp|heic|avif|bin))?|r\d+))_(?P<size>[tm])\.jpg$")


def is_image_key(key: str) -> bool:
    return bool(_IMAGE_KEY.match(key or ""))


def variant_of(key: str):
    """预览图的键 → (原图的键, "t"|"m");不是预览图返回 None。"""
    m = _VARIANT.match(key or "")
    return (m["base"] if "." in m["base"].rsplit("/", 1)[-1] else m["base"] + ".jpg", m["size"]) if m else None


def variant_key(key, size: str):
    """原图键 → 预览图键；非 JPEG 原图保留格式后缀以便准确定位来源。"""
    if not key or not is_image_key(key) or "_sig." in key or variant_of(key):
        return None
    return (key[:-4] if key.endswith(".jpg") else key) + f"_{size}.jpg"
