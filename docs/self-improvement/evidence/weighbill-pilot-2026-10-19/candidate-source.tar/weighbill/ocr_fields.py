# -*- coding: utf-8 -*-
"""传统 OCR 结果 → 磅单字段。纯函数,不依赖任何 OCR 引擎,方便测试。

输入是 OCR 引擎给出的文字框 [(四个角点, 文字), ...]。做三件事:
1. 切单:一张照片里几张磅单,按标题(默认含「称重单 / 过磅单 / 磅单」)切开——每个标题管它正下方那一列。
2. 配值:磅单是「标签格 | 数值格」的表,同一行(竖直方向重叠过半)标签右边的文字就是值。
3. 纠错:针式打印的固定错样——1 认成 i/l,6 认成 ó,0 认成 O/D;繁体标签(時間)照认。

2026-10-14 实测(客户 102 张台账裁图):车号+三项重量全对 88 张,其余 14 张都会被「重量对不上账 /
车号不像车号」拦下来提示人看,没有一张是错了却没提示的。规则不认任何具体厂商。
"""
from __future__ import annotations

import re
from typing import Iterable, Optional

# 票面标签 → 内部字段。别名按长度优先匹配(「客户名称」先于「客户名」)
LABELS = {"序号": "序号", "单号": "序号", "磅单号": "序号", "日期": "日期", "入站时间": "入站时间", "进站时间": "入站时间",
          "入厂时间": "入站时间", "出站时间": "出站时间", "出厂时间": "出站时间", "车号": "车号", "车牌号": "车号",
          "货名": "货名", "货物名称": "货名", "品名": "货名", "收费": "收费", "总重": "总重", "毛重": "总重",
          "空重": "皮重", "皮重": "皮重", "净重": "净重", "客户名称": "客户名", "客户名": "客户名", "收货单位": "客户名",
          "供货单位": "供应商", "发货单位": "供应商", "司秤员": "监磅员", "监磅员": "监磅员", "过磅员": "监磅员",
          "称重员": "监磅员"}
SIGNER = ("司秤员", "监磅员", "过磅员", "称重员")
TRAD = str.maketrans({"時": "时", "間": "间", "號": "号", "淨": "净", "總": "总", "稱": "称", "貨": "货", "車": "车",
                      "費": "费", "單": "单", "員": "员", "進": "进", "廠": "厂"})
DIGIT = str.maketrans({"i": "1", "l": "1", "I": "1", "|": "1", "!": "1", "ó": "6", "ò": "6", "b": "6", "O": "0",
                       "o": "0", "D": "0", "Q": "0", "S": "5", "B": "8", "Z": "2", "z": "2", "g": "9"})
# 点阵打印里长得像的字归成一类,比对单号前缀时按类比
CONFUSE = str.maketrans({"G": "C", "6": "C", "c": "C", "g": "C", "D": "0", "O": "0", "U": "0", "Q": "0", "o": "0",
                         "i": "1", "l": "1", "I": "1"})
PLATE_TAIL = str.maketrans({"o": "0", "i": "1", "l": "1", "I": "1", "ó": "6", "/": "7"})
from .domain import PROVINCES                # noqa: E402  省份简称只在 domain 定义一份
UNITS = {"kg", "kgl", "公斤", "元", "吨", "t"}
DEFAULT_ANCHORS = ("称重单", "过磅单", "磅单", "称量单")


def items_of(boxes: Iterable, texts: Iterable[str]) -> list[dict]:
    out = []
    for b, t in zip(boxes, texts):
        xs = [float(p[0]) for p in b]; ys = [float(p[1]) for p in b]
        out.append({"t": str(t), "x0": min(xs), "x1": max(xs), "y0": min(ys), "y1": max(ys),
                    "h": max(ys) - min(ys)})
    return out


def label_of(text: str):
    s = re.sub(r"[\s:：（）()KGkg]", "", text.translate(TRAD))
    for k in sorted(LABELS, key=len, reverse=True):
        if s.startswith(k):
            return LABELS[k], k, s[len(k):]
    return None, None, None


# ---------------------------------------------------------------- 切单
def split_tickets(items: list[dict], anchors=DEFAULT_ANCHORS) -> list[list[dict]]:
    """每个标题框管:横向在标题两侧各外扩 0.75 个标题宽的一列,纵向从标题往下到同列下一个标题为止。
    没有标题时整张图当一张单据(如果上面有磅单标签的话)。"""
    heads = [it for it in items if any(a in it["t"].translate(TRAD) for a in anchors) and label_of(it["t"])[0] is None]
    # 同一张单上「称重单」与「第一联:称重站留存」之类都可能命中,只留每列最上面那个
    heads.sort(key=lambda it: it["y0"])
    kept = []
    for h in heads:
        if not any(_same_col(h, k) and h["y0"] - k["y1"] < 6 * max(k["h"], 1) for k in kept):
            kept.append(h)
    if not kept:
        return [items] if sum(label_of(it["t"])[0] is not None for it in items) >= 3 else []
    groups = []
    for h in kept:
        w = h["x1"] - h["x0"]
        gx0, gx1 = h["x0"] - 0.75 * w, h["x1"] + 0.75 * w
        lower = [k for k in kept if k is not h and k["y0"] > h["y0"] and gx0 <= (k["x0"] + k["x1"]) / 2 <= gx1]
        y_end = min((k["y0"] for k in lower), default=float("inf"))
        g = [it for it in items if gx0 <= (it["x0"] + it["x1"]) / 2 <= gx1 and h["y0"] - 5 <= (it["y0"] + it["y1"]) / 2 < y_end]
        if sum(label_of(it["t"])[0] is not None for it in g) >= 3:
            groups.append(g)
    return groups


def _same_col(a, b):
    return not (a["x1"] < b["x0"] or b["x1"] < a["x0"])


def bbox(items: list[dict]):
    return (min(i["x0"] for i in items), min(i["y0"] for i in items),
            max(i["x1"] for i in items), max(i["y1"] for i in items))


# ---------------------------------------------------------------- 配值
def _row_right_of(lab: dict, items: list[dict]) -> list[dict]:
    def ov(o):
        return min(o["y1"], lab["y1"]) - max(o["y0"], lab["y0"])
    row = [o for o in items if o is not lab and o["x0"] > lab["x1"] - 5 and ov(o) > 0.5 * min(lab["h"], o["h"])
           and o["h"] < 2.2 * max(lab["h"], 1) and label_of(o["t"])[0] is None
           and o["t"].strip().lower() not in UNITS]
    return sorted(row, key=lambda o: o["x0"])


def parse_fields(items: list[dict], serial_prefixes: Iterable[str] = ()) -> dict:
    out: dict = {}
    for it in sorted(items, key=lambda o: (o["y0"], o["x0"])):
        k, _, rest = label_of(it["t"])
        if not k or k in out:
            continue
        val = (rest or "") + "".join(o["t"] for o in _row_right_of(it, items))
        out[k] = val.strip() or None
    return clean(out, serial_prefixes)


def signer_box(items: list[dict]) -> Optional[tuple]:
    """签名一般手写在「司秤员/监磅员」那一格右边:返回那一格的大致范围(像素)。"""
    for it in items:
        if any(s in it["t"].translate(TRAD).replace(" ", "") for s in SIGNER):
            right = [o for o in items if o["x0"] > it["x1"] and min(o["y1"], it["y1"]) - max(o["y0"], it["y0"]) > 0]
            x1 = max([o["x1"] for o in right], default=it["x1"] + 6 * (it["x1"] - it["x0"]))
            pad = it["h"] * 0.8
            return (it["x1"], it["y0"] - pad, x1, it["y1"] + pad)
    return None


# ---------------------------------------------------------------- 纠错
def _lev(a: str, b: str) -> int:
    d = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        p, d[0] = d[0], i
        for j, cb in enumerate(b, 1):
            p, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, p + (ca != cb))
    return d[-1]


def weight_kg(v) -> Optional[str]:
    """一格重量 → kg 整数字符串。先去单位再纠字形(否则「kg」的 g 会被当成 9),小数点要认:
    「17200.0」是 17200 不是 172000;「35.40」这种两位整数带小数的是吨,换成 35400。认不出返回 None。
    (审计复现:原来的写法把小数点直接丢掉,重量放大 10 倍、100 倍还能通过「总重-皮重=净重」校验。)"""
    if not v:
        return None
    s = re.sub(r"(?i)(k\s*g[l1I|]?|公斤|千克)", "", str(v))      # 「kgl」:kg 后面常跟一个笔画噪声
    tons = bool(re.search(r"(吨|(?<![a-z])t\b)", s, re.I))
    s = re.sub(r"(吨|(?i:(?<![a-z])t\b))", "", s).translate(DIGIT).replace(",", "").replace("，", "")
    m = re.search(r"\d+(?:[.。]\d+)?", s)
    if not m:
        return None
    x = float(m.group().replace("。", "."))
    if tons or ("." in m.group() and x < 100):
        x *= 1000
    return str(int(round(x)))


def clean(f: dict, serial_prefixes: Iterable[str] = ()) -> dict:
    for k in ("总重", "皮重", "净重"):
        f[k] = weight_kg(f.get(k))
    for k in ("入站时间", "出站时间"):
        v = f.get(k)
        if not v:
            continue
        v = v.translate(DIGIT)
        m = re.search(r"(\d{4})-?(\d{2})-?(\d{2})\s*(\d{2}):?(\d{2}):?(\d{2})?", v)
        if m:
            f[k] = f"{m[1]}-{m[2]}-{m[3]} {m[4]}:{m[5]}" + (f":{m[6]}" if m[6] else "")
        else:
            m = re.search(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", v) or re.search(r"^(\d{2})(\d{2})(\d{2})?$", re.sub(r"\D", "", v))
            f[k] = (f"{int(m[1]):02d}:{m[2]}" + (f":{m[3]}" if m[3] else "")) if m else v
    if f.get("日期"):
        m = re.search(r"(\d{4})\D?(\d{1,2})\D?(\d{1,2})", f["日期"].translate(DIGIT))
        f["日期"] = f"{m[1]}-{int(m[2]):02d}-{int(m[3]):02d}" if m else f["日期"]
    v = f.get("序号")
    if v:
        v = re.sub(r"\s", "", v)
        head = re.match(r"[A-Za-z]+", v)
        head = head.group() if head else ""
        tail = v[len(head):].translate(DIGIT)
        # 每台磅的单号前缀固定(配在 serial_prefixes);点阵的 C/G、D/0 常混,同类字比得上或只差一个字就按配置
        for p in serial_prefixes:
            cand = v[:len(p)]
            if cand != p and (cand.translate(CONFUSE).upper() == p.translate(CONFUSE).upper()
                              or _lev(cand.upper(), p.upper()) <= 1):
                head, tail = p, v[len(p):].translate(DIGIT)
                break
        f["序号"] = head + tail
    v = f.get("车号")
    if v:
        from .domain import norm_plate       # 省份繁体(粵→粤)是 OCR 字库的问题,不是人录错,这里就改掉
        v = norm_plate(re.sub(r"[\s·.\-]", "", v.translate(TRAD)))
        f["车号"] = v[:2] + v[2:].translate(PLATE_TAIL).upper() if v else None
    return f


def plate_looks_valid(p: Optional[str]) -> bool:
    return bool(p) and p[0] in PROVINCES and bool(re.fullmatch(r"[A-Z][A-Z0-9]{4,6}", p[1:] or ""))


def weights_consistent(f: dict) -> bool:
    try:
        g, t, n = (int(f.get(k)) for k in ("总重", "皮重", "净重"))
    except (TypeError, ValueError):
        return False
    return g - t == n
