# -*- coding: utf-8 -*-
"""服务器端暂存区:照片先落本机磁盘、刷盘,再回「已收到」;识别、写库、存图都从这里取,失败就过一会儿再来。

为什么要有它(2026-10-14 用户:「不能网卡一下就不能上传了……服务器也要有缓存」):
数据库、对象存储、识别任何一个一时连不上,原来的上传就整个失败,现场只能重拍。现在只要照片到了这台服务器的磁盘,
就算收下了;后面的事由后台自动补完,永不放弃(积压会在健康检查里亮出来,让人知道)。

每次上传两个文件:<id>.bin(照片原样)、<id>.json(谁传的、什么类型、状态)。都是先写临时名、fsync、再改名,
断电也不会留下「看着完整其实半截」的文件。处理完挪到 done/ 再留几天(对象存储里已有一份,这里是第二份保险)。
"""
from __future__ import annotations

import datetime as dt
import fcntl
import uuid
import json
import os
import re
import threading
from pathlib import Path
from typing import Optional

_ID = re.compile(r"^[A-Za-z0-9_-]{8,64}$")

RECEIVED, PROCESSING, DONE, RETRY, REJECTED = "received", "processing", "done", "retry", "rejected"
# 失败后多久再试:30 秒起翻倍,最多 30 分钟一次;不设上限次数——照片是数据,不能因为重试次数用完就丢
BACKOFF = [30, 60, 120, 300, 600, 1800]


def valid_id(upload_id: str) -> bool:
    return bool(upload_id) and bool(_ID.match(upload_id))


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def _write_atomic(path: Path, data: bytes) -> None:
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)                     # 改名本身也要落盘
    finally:
        os.close(fd)


class _ProcessLock:
    """Serialize local spool mutations across threads and worker processes."""
    def __init__(self, path):
        self.path = path
        self.thread_lock = threading.RLock()
        self.depth = 0
        self.file = None

    def __enter__(self):
        self.thread_lock.acquire()
        try:
            if self.depth == 0:
                self.file = open(self.path, "a+b")
                try:
                    fcntl.flock(self.file.fileno(), fcntl.LOCK_EX)
                except BaseException:
                    self.file.close()
                    raise
            self.depth += 1
            return self
        except BaseException:
            self.thread_lock.release()
            raise

    def __exit__(self, *args):
        self.depth -= 1
        try:
            if self.depth == 0:
                self.file.close()  # releases flock, including on process exit
                self.file = None
        finally:
            self.thread_lock.release()


def _sync_dir(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class Spool:
    def __init__(self, root: Path, keep_days: int = 7):
        self.root = Path(root)
        self.inbox, self.done = self.root / "inbox", self.root / "done"
        for d in (self.inbox, self.done):
            d.mkdir(parents=True, exist_ok=True)
        self.keep_days = keep_days
        self._lock = _ProcessLock(self.root / ".spool.lock")

    # ------------------------------------------------------------ 收
    def put(self, upload_id: str, raw: bytes, meta: dict) -> tuple[dict, bool]:
        """收下一次上传。同一个 upload_id 再来(手机重试)不重复收,返回已有的那份。返回 (meta, 是否新收)。"""
        if not valid_id(upload_id):
            raise ValueError("upload_id 不合法")
        with self._lock:
            old = self.get(upload_id)
            if old is not None:
                return old, False
            m = {**meta, "upload_id": upload_id, "status": RECEIVED, "received_at": meta.get("received_at") or _now(),
                 "attempts": 0, "size": len(raw)}
            _write_atomic(self.inbox / f"{upload_id}.bin", raw)
            _write_atomic(self.inbox / f"{upload_id}.json", json.dumps(m, ensure_ascii=False).encode("utf-8"))
            return m, True

    # ------------------------------------------------------------ 查
    def _paths(self, upload_id: str):
        for d in (self.inbox, self.done):
            j = d / f"{upload_id}.json"
            if j.exists():
                return j, d / f"{upload_id}.bin"
        return None, None

    def get(self, upload_id: str) -> Optional[dict]:
        if not valid_id(upload_id):
            return None
        with self._lock:
            j, _ = self._paths(upload_id)
            return json.loads(j.read_text("utf-8")) if j else None

    def raw(self, upload_id: str) -> bytes:
        if not valid_id(upload_id):
            raise FileNotFoundError(upload_id)
        with self._lock:
            # A crash between the two renames may leave metadata and bytes in different dirs.
            _, b = self._paths(upload_id)
            candidates = [b, self.inbox / f"{upload_id}.bin", self.done / f"{upload_id}.bin"]
            for path in candidates:
                if path is not None and path.exists():
                    return path.read_bytes()
            raise FileNotFoundError(upload_id)

    def update(self, upload_id: str, **changes) -> dict:
        with self._lock:
            j, _ = self._paths(upload_id)
            if j is None:
                raise FileNotFoundError(upload_id)
            m = {**json.loads(j.read_text("utf-8")), **changes}
            _write_atomic(j, json.dumps(m, ensure_ascii=False).encode("utf-8"))
            return m

    def due(self, now: Optional[str] = None, stale_minutes: int = 15) -> list[dict]:
        """该处理的:新收的、到点重试的、标着「处理中」却很久没动静的(进程中途死了)。按收到先后。"""
        now = now or _now()
        stale = (dt.datetime.fromisoformat(now) - dt.timedelta(minutes=stale_minutes)).isoformat(timespec="seconds")
        out = []
        for j in self.inbox.glob("*.json"):
            try:
                m = json.loads(j.read_text("utf-8"))
            except (OSError, ValueError):
                continue
            st = m.get("status")
            if st == RECEIVED or (st == RETRY and m.get("next_at", "") <= now) or \
                    (st == PROCESSING and m.get("started_at", "") <= stale):
                out.append(m)
        return sorted(out, key=lambda m: m.get("received_at", ""))

    # ------------------------------------------------------------ 结
    def finish(self, upload_id: str, record_ids: list, duplicates: Optional[dict] = None) -> dict:
        with self._lock:
            m = self.update(upload_id, status=DONE, finished_at=_now(), record_ids=record_ids,
                            duplicates=duplicates or {}, last_error=None)
            for ext in ("bin", "json"):
                src = self.inbox / f"{upload_id}.{ext}"
                if src.exists():
                    os.replace(src, self.done / src.name)
            _sync_dir(self.inbox)
            _sync_dir(self.done)
            return m

    def fail(self, upload_id: str, error: str, permanent: bool = False) -> dict:
        m = self.get(upload_id) or {}
        n = int(m.get("attempts") or 0) + 1
        if permanent:
            return self.update(upload_id, status=REJECTED, attempts=n, last_error=error[:500], finished_at=_now())
        wait = BACKOFF[min(n - 1, len(BACKOFF) - 1)]
        nxt = (dt.datetime.now() + dt.timedelta(seconds=wait)).isoformat(timespec="seconds")
        return self.update(upload_id, status=RETRY, attempts=n, last_error=error[:500], next_at=nxt)

    def done_items(self) -> list[dict]:
        out = []
        for j in self.done.glob("*.json"):
            try:
                out.append(json.loads(j.read_text("utf-8")))
            except (OSError, ValueError):
                continue
        return out

    def requeue(self, upload_id: str, why: str) -> dict:
        """处理完了却在库里找不到登记 → 照片还在暂存区,挪回待处理,重新登记(记录 ID 由 upload_id 定,不会多登)。"""
        with self._lock:
            for ext in ("bin", "json"):
                src = self.done / f"{upload_id}.{ext}"
                if src.exists():
                    os.replace(src, self.inbox / src.name)
            _sync_dir(self.inbox)
            _sync_dir(self.done)
            return self.update(upload_id, status=RECEIVED, last_error=why, record_ids=[])

    def purge(self) -> int:
        """done/ 里超过保留天数的删掉(对象存储与数据库里早已各有一份)。"""
        cut = (dt.datetime.now() - dt.timedelta(days=self.keep_days)).isoformat(timespec="seconds")
        n = 0
        for j in list(self.done.glob("*.json")):
            try:
                m = json.loads(j.read_text("utf-8"))
            except (OSError, ValueError):
                continue
            if m.get("finished_at", "9") < cut:
                for p in (j, j.with_suffix(".bin")):
                    p.unlink(missing_ok=True)
                n += 1
        return n

    def pending_items(self) -> list[dict]:
        """还没处理完的(含被拒的),按收到先后。"""
        out = []
        for j in self.inbox.glob("*.json"):
            try:
                out.append(json.loads(j.read_text("utf-8")))
            except (OSError, ValueError):
                continue
        return sorted(out, key=lambda m: m.get("received_at", ""))

    def stats(self) -> dict:
        pending = self.pending_items()
        waiting = [m for m in pending if m.get("status") != REJECTED]
        oldest = min((m.get("received_at", "") for m in waiting), default=None)
        return {"pending": len(waiting), "rejected": sum(m.get("status") == REJECTED for m in pending),
                "oldest_received_at": oldest,
                "last_error": next((m.get("last_error") for m in sorted(waiting, key=lambda m: m.get("received_at", ""))
                                    if m.get("last_error")), None)}
