# -*- coding: utf-8 -*-
"""端口:子系统对外部依赖的全部抽象。

业务编排(service.py)只依赖这里的协议,不依赖任何具体实现。要接入新系统,
就是为某个端口写一个适配器,并让它通过 weighbill.testing.contracts 里对应的契约测试。

五个端口,按方向分:
  出站(子系统去调别人)  VisionModel  RecordStore  BlobStore  EventSink
  入站辅助              IdentityResolver(从调用方请求里认出"谁在操作")
入站调用本身(HTTP / CLI / 进程内)不是端口,它们直接调 WeighbillService。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional, Protocol, runtime_checkable

from PIL import Image

from .domain import Record


# ---------------------------------------------------------------- 视觉模型
@runtime_checkable
class VisionModel(Protocol):
    """把图片变成结构化结果。可以是大模型,也可以是传统 OCR。

    约定:
    - 三个方法都可能抛异常(网络、鉴权、限流、输出无法解析);抛出即视为本次调用失败,
      由业务层记成 failed 记录,适配器不要吞掉错误返回空结果——空结果会被当成
      「模型看了但什么都没认出」,两者在台账上必须可区分。
    - 框的坐标:推荐百分比(0-100)。业务层会用 imaging.norm_box 兜底 0-1000 归一化
      及同一框内混用两种单位的情况,但适配器不应依赖这层兜底。
    """

    async def segment(self, image: Image.Image) -> list[dict]:
        """返回照片里每张单据的外接框 [{"x","y","w","h"}, ...]。"""
        ...

    async def recognize(self, receipt: Image.Image) -> dict:
        """返回一张单据的字段:domain.FIELDS 中的键,外加可选 "签名框"。"""
        ...

    async def locate_signature(self, receipt: Image.Image) -> Optional[dict]:
        """专项定位签名框;识别时附带的签名框不可用才会被调用。没有签名返回 None。"""
        ...

    # 可选:async def reread_weights(receipt) -> dict  只读总重/皮重/净重三行。
    # 首读的重量对不上账时业务层才调用;没有实现这个方法的适配器会被跳过,行为与 0.2.0 一致。

    def describe(self) -> dict:
        """用于留痕与健康检查,如 {"adapter": "...", "seg_model": "...", "rec_model": "..."}。
        不得包含密钥。"""
        ...


# ---------------------------------------------------------------- 台账存储
class StaleRecord(Exception):
    """要写的记录在读出来以后被别人(可能是另一台服务器)改过了。"""


@dataclass(frozen=True)
class RecordQuery:
    date_from: str = ""      # YYYY-MM-DD,含当天
    date_to: str = ""        # YYYY-MM-DD,含当天
    q: str = ""              # 在字段值里做子串匹配
    status: str = ""
    limit: Optional[int] = 500    # None = 不封顶(只给服务内部的汇总/对账/导出用,HTTP 传不进 None)
    doc_type: str = ""       # supplier_out / site_in / site_out
    stage: str = ""          # draft / submitted / approved
    ticket_from: str = ""    # 磅单上的「日期」(YYYY-MM-DD),含当天;补录的历史单据上传时间是今天,业务日期另算
    ticket_to: str = ""
    voided: str = ""         # "" = 不含作废的(默认);"only" = 只要作废的;"all" = 都要
    flagged: bool = False    # True = 只要「有疑问」的
    source: str = ""         # 只要这个来源的(现场链接各自只看自己的)
    batch_id: str = ""       # 只要这一次上传(一张照片)的
    origin_id: str = ""      # 业务来源单位；空=全部


@runtime_checkable
class RecordStore(Protocol):
    """台账记录的持久化。默认实现是 SQLite;换 MySQL/PostgreSQL/对方系统的库就换这里。

    约定:
    - insert 对重复 id 必须失败(抛异常),不得静默覆盖。
    - get 查不到返回 None,不抛。
    - query 按 created_at 倒序;limit 由实现方再封顶(默认实现封顶 2000);limit=None 表示全部,不许封顶——
      汇总、磅差、导出靠它,封顶会悄悄少算(审计复现:一个半月数据,磅差凭空多出 ±500 吨)。
      ticket_from/ticket_to 按 fields["日期"] 过滤(字符串 YYYY-MM-DD 比较)。
    - update 只改可变列(fields/warnings/weight_ok/weight_msg/status/reviewed_by/reviewed_at),
      记录不存在时抛 KeyError。
    - ping 用于健康检查:能读写返回 None,否则抛异常。
    - next_ref(scope) 登记编号流水号:同一 scope 从 1 起严格递增、并发下不重复;不同 scope 互不影响。
    - ref_no 插入时随记录写入,之后 update 不得改它;库里唯一。assign_ref 只给 ref_no 为空的记录补号。
    - query 的 q 也要匹配 ref_no。
    - append_history / history:每条记录的修改记录,只追加,按写入先后返回。
    - update 必须核对版本:只有库里的 version 等于传入记录的 version 才写,写成后 version 加一(并回填到传入的记录上);
      不相等抛 StaleRecord。多台服务器共用一个库时,防止「读-改-写」互相覆盖全靠这一条。
    - get_setting / set_setting:页面上可改的设置(如磅差阈值)存在库里,所有服务器看到同一份。
    - named_lock(name):跨进程、跨服务器的互斥锁(上下文管理器)。同名的锁同一时刻只有一个持有者,
      其余等待。查重 + 登记要包在里面:否则两台节点同一秒识别到同一张单,都查不到对方,会登记两条。
    - ensure_ref_at_least(scope, n):把发号计数器抬到不小于 n(数据迁移后接着发号,不撞已有编号)。
    - query 默认不返回作废的记录(voided_at 非空);voided="only"/"all" 才返回。flagged=True 只要 flag_note 非空的。
    """

    def insert(self, record: Record) -> None: ...
    def get(self, record_id: str) -> Optional[Record]: ...
    def query(self, q: RecordQuery) -> list[Record]: ...
    def update(self, record: Record) -> None: ...
    def ping(self) -> None: ...
    def next_ref(self, scope: str) -> int: ...
    def without_ref(self) -> list[Record]: ...
    def assign_ref(self, record_id: str, ref_no: str) -> bool: ...
    def append_history(self, record_id: str, at: str, actor: str, action: str, detail: dict) -> None: ...
    def history(self, record_id: str) -> list[dict]: ...
    def get_setting(self, key: str) -> Optional[dict]: ...
    def named_lock(self, name: str): ...
    def ensure_ref_at_least(self, scope: str, n: int) -> None: ...
    def set_setting(self, key: str, value: dict) -> None: ...


# ---------------------------------------------------------------- 文件存储
@runtime_checkable
class BlobStore(Protocol):
    """原图、单据裁剪图、签名图的留存。默认实现是本地目录;换对象存储(S3/MinIO/OSS)就换这里。

    约定:
    - key 是正斜杠分隔的相对路径(如 "images/20260922/abc_r1.jpg"),不得以 / 开头、不得含 ..;
      put 对非法 key 必须抛 ValueError。
    - put 之后 open 必须能读回同样的字节。
    - url 返回调用方可直接访问的地址;本地实现返回 "/files/<key>"(与 0.1 版页面兼容)。
    """

    def put(self, key: str, data: bytes, content_type: str) -> str: ...
    def open(self, key: str) -> bytes: ...
    def url(self, key: str) -> str: ...
    def ping(self) -> None: ...


# ---------------------------------------------------------------- 身份
@runtime_checkable
class IdentityResolver(Protocol):
    """从入站请求的头里认出操作人。系统自身不做登录,身份由门户/网关注入。

    约定:认不出时返回一个固定的匿名标识,不抛。
    """

    def resolve(self, headers: Mapping[str, str]) -> str: ...


# ---------------------------------------------------------------- 事件
@runtime_checkable
class EventSink(Protocol):
    """领域事件出口:让其他系统(ERP、结算、消息总线)在台账变化时得到通知。

    事件信封遵循 CloudEvents 1.0 结构化 JSON(specversion/id/source/type/time/data)。
    约定:
    - publish 失败就抛异常。业务层会捕获、计数并在健康检查里如实报出,
      但不会因为下游通知失败而回滚已入账的记录。
    - 投递语义由适配器声明(describe()["delivery"]):at-most-once / at-least-once。
    """

    def publish(self, event: dict) -> None: ...
    def describe(self) -> dict: ...


EVENT_RECORD_CREATED = "com.weighbill.record.created"
EVENT_RECORD_REVIEWED = "com.weighbill.record.reviewed"
EVENT_RECORD_SUBMITTED = "com.weighbill.record.submitted"
EVENT_RECORD_APPROVED = "com.weighbill.record.approved"
EVENT_TYPES = (EVENT_RECORD_CREATED, EVENT_RECORD_REVIEWED, EVENT_RECORD_SUBMITTED, EVENT_RECORD_APPROVED)


def describe_or_empty(obj: Any) -> dict:
    fn = getattr(obj, "describe", None)
    try:
        return dict(fn()) if callable(fn) else {}
    except Exception as e:  # describe 失败不该拖垮健康检查,但要看得见
        return {"describe_error": f"{type(e).__name__}: {e}"}
