# -*- coding: utf-8 -*-
"""唯一装配点。HTTP、CLI、进程内调用方都必须从 build_service 拿服务。

不要在别处自己 new 适配器再拼一个 WeighbillService——两条装配路径迟早会分叉,
一边改了配置/限制,另一边悄悄沿用旧的。测试需要替身时通过 overrides 注入。
"""
from __future__ import annotations

from typing import Optional

from . import adapters
from .config import Settings, load_settings
from .service import WeighbillService


def build_service(settings: Optional[Settings] = None, **overrides) -> WeighbillService:
    s = settings or load_settings()
    s.origin_catalog  # validate before opening storage
    unknown = set(overrides) - set(adapters.REGISTRY)
    if unknown:
        raise TypeError(f"未知的端口替身: {sorted(unknown)};可用: {sorted(adapters.REGISTRY)}")
    parts = {port: overrides[port] if port in overrides else adapters.build(port, s)
             for port in adapters.REGISTRY}
    svc = WeighbillService(
        vision=parts["vision"], store=parts["record_store"], blobs=parts["blob_store"],
        events=parts["event_sink"], identity=parts["identity"], settings=s)
    svc.ensure_ref_numbers()          # 老库补发登记编号(幂等,已有号的不动)
    return svc
