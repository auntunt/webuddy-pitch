# -*- coding: utf-8 -*-
"""统计看板。纯函数,不碰 IO;输入是三类磅单 + 磅差配对结果,输出给页面和数字大脑拉取。

口径(都来自 2026-10-12 会议):
- 业务日期一律按磅单「日期」,不按上传时间(补录的历史单据上传时间是今天)。
- 吨位按净重;识别失败的单据不进吨位,但计入张数和数据完整度。
- 「每天、每周都要能看」:按天出数,按周由页面合并(比例要用合并后的合计重算,不能平均)。
- 磅差只看厂商 ↔ 本场;出场单只采集,不算磅差。
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Iterable

from .domain import DOC_TYPES, STAGES, Record, norm_plate
from .reconcile import _num, _time, ticket_moment

# 单车磅差分布的分档(kg,按 本场 − 厂商)。正 = 本场称得多,负 = 本场少了。
DIFF_BINS = [(-10**9, -200), (-200, -100), (-100, -50), (-50, 0), (0, 1), (1, 50), (50, 100), (100, 200), (200, 10**9)]
_PREFER = {"supplier_out": "出站时间", "site_in": "入站时间", "site_out": "出站时间"}


def _bin_label(lo, hi):
    if lo <= -10**9:
        return f"< {hi}"
    if hi >= 10**9:
        return f"≥ {lo}"
    if (lo, hi) == (0, 1):
        return "0"
    return f"{lo} ~ {hi}"


def _live(recs):
    return [r for r in recs if r.status != "failed"]


def _net(r):
    return _num((r.fields or {}).get("净重"))


def summarize(records: dict[str, Iterable[Record]], recon: dict, top_n: int = 10) -> dict:
    by_type = {k: list(records.get(k, [])) for k in DOC_TYPES}

    # ---------------------------------------------------------------- 每类单据的合计
    kinds = {}
    for k, recs in by_type.items():
        live = _live(recs)
        nets = [n for n in map(_net, live) if n is not None]
        plates = {norm_plate((r.fields or {}).get("车号")) for r in live} - {""}
        stages = Counter(r.stage for r in recs)
        kinds[k] = {
            "label": DOC_TYPES[k], "tickets": len(recs), "net": sum(nets), "trucks": len(plates),
            "avg_net": (sum(nets) / len(nets)) if nets else None,
            "stages": {s: stages.get(s, 0) for s in STAGES},
            "failed": sum(r.status == "failed" for r in recs),
            "no_net": sum(_net(r) is None for r in live),
        }

    # ---------------------------------------------------------------- 按天
    daily = defaultdict(lambda: {f"{k}_{m}": 0 for k in DOC_TYPES for m in ("tickets", "net")})
    for k, recs in by_type.items():
        for r in _live(recs):
            d, _ = ticket_moment(r, _PREFER[k])
            if d is None:
                continue
            row = daily[d.isoformat()]
            row[f"{k}_tickets"] += 1
            row[f"{k}_net"] += _net(r) or 0
    for d in recon.get("days", []):
        if d["date"]:
            row = daily[d["date"]]
            row.update({"pairs": d["trucks"], "diff": d["diff"], "diff_pct": d["diff_pct"],
                        "alerts": d["alerts"], "unmatched": d["unmatched"]})
    days = [{"date": d, "pairs": 0, "diff": None, "diff_pct": None, "alerts": 0, "unmatched": 0, **v}
            for d, v in sorted(daily.items())]

    # ---------------------------------------------------------------- 磅差:合计、单车分布、排行
    rdays = recon.get("days", [])
    pairs = [x for d in rdays for x in d["pairs"]]
    supplier_net = sum(d["supplier_net"] for d in rdays)
    site_net = sum(d["site_net"] for d in rdays)
    diffs = [x["diff"] for x in pairs if x["diff"] is not None]
    bins = [{"label": _bin_label(lo, hi), "lo": lo, "hi": hi,
             "n": sum(lo <= v < hi for v in diffs)} for lo, hi in DIFF_BINS]

    def brief(x):
        return {"date": x["date"].isoformat() if hasattr(x["date"], "isoformat") else x["date"],
                "plate": x["plate"], "supplier_net": x["supplier_net"], "site_net": x["site_net"],
                "diff": x["diff"], "diff_pct": x["diff_pct"], "alert": x["diff_alert"],
                "supplier_id": x["supplier"].id, "site_id": x["site"].id}
    worst = sorted((x for x in pairs if x["diff"] is not None), key=lambda x: -abs(x["diff"]))[:top_n]

    recon_out = {
        "days": len(rdays), "supplier_net": supplier_net, "site_net": site_net, "diff": site_net - supplier_net,
        "diff_pct": ((site_net - supplier_net) / supplier_net * 100) if supplier_net else None,
        "pairs": len(pairs), "alerts": sum(d["alerts"] for d in rdays),
        "unmatched_supplier": sum(len(d["unmatched_supplier"]) for d in rdays),
        "unmatched_site": sum(len(d["unmatched_site"]) for d in rdays),
        "pair_sum": sum(diffs), "within_alert": sum(not x["diff_alert"] for x in pairs),
        "bins": bins, "worst": [brief(x) for x in worst],
        "points": [_point(x) for x in pairs if x["diff"] is not None],
        "gap_min": _quantiles([x["gap_min"] for x in pairs if x["gap_min"] is not None]),
        "params": recon.get("params", {}),
    }

    # ---------------------------------------------------------------- 车辆:趟数与吨位
    trips = defaultdict(lambda: {"supplier_out": 0, "site_in": 0, "net": 0.0, "diff": 0.0, "pairs": 0})
    for k in ("supplier_out", "site_in"):
        for r in _live(by_type[k]):
            p = norm_plate((r.fields or {}).get("车号"))
            if p:
                trips[p][k] += 1
                if k == "supplier_out":
                    trips[p]["net"] += _net(r) or 0
    for x in pairs:
        if x["plate"] and x["diff"] is not None:
            trips[x["plate"]]["diff"] += x["diff"]
            trips[x["plate"]]["pairs"] += 1
    vehicles = sorted(({"plate": p, **v} for p, v in trips.items()),
                      key=lambda v: (-v["supplier_out"], -v["net"], v["plate"]))

    # ---------------------------------------------------------------- 到站时段(每小时车次)
    hours = {k: [0] * 24 for k in DOC_TYPES}
    for k, recs in by_type.items():
        for r in _live(recs):
            t = _time((r.fields or {}).get(_PREFER[k]))
            if t is not None:
                hours[k][t.hour] += 1

    # ---------------------------------------------------------------- 构成:货名、装点、客户
    def mix(recs, key):
        acc = defaultdict(lambda: {"tickets": 0, "net": 0.0})
        for r in _live(recs):
            name = str((r.fields or {}).get(key) or "").strip() if key != "customer" else (r.customer or "")
            name = name or "未填"
            acc[name]["tickets"] += 1
            acc[name]["net"] += _net(r) or 0
        return sorted(({"name": n, **v} for n, v in acc.items()), key=lambda v: (-v["net"], v["name"]))

    mixes = {
        "supplier_goods": mix(by_type["supplier_out"], "货名"),
        "supplier_points": mix(by_type["supplier_out"], "装点"),
        "site_goods": mix(by_type["site_in"], "货名"),
        "out_customers": mix(by_type["site_out"], "customer"),
        "out_goods": mix(by_type["site_out"], "货名"),
    }

    # ---------------------------------------------------------------- 识别质量(只算拍照识别进来的,台账导入的不算)
    shot = [r for recs in by_type.values() for r in recs if r.model]
    quality = {
        "tickets": len(shot),
        "auto_ok": sum(r.status == "auto_ok" for r in shot),
        "needs_review": sum(r.status == "needs_review" for r in shot),
        "failed": sum(r.status == "failed" for r in shot),
        "edited": sum(bool(r.reviewed_by) for r in shot),
        "weight_ok": sum(bool(r.weight_ok) for r in shot),
    }

    return {"kinds": kinds, "days": days, "recon": recon_out, "vehicles": vehicles, "hours": hours,
            "mix": mixes, "quality": quality}


def _point(x) -> dict:
    """单车磅差散点:横轴厂商出站时刻,纵轴磅差。入站和出站不在同一天的 = 隔夜装车,单独着色。"""
    f = x["supplier"].fields or {}
    d, out_at = ticket_moment(x["supplier"], "出站时间")
    _, in_at = ticket_moment(x["supplier"], "入站时间")
    return {"plate": x["plate"], "diff": x["diff"], "diff_pct": x["diff_pct"], "alert": x["diff_alert"],
            "minute": out_at.hour * 60 + out_at.minute if out_at else None,
            "gap_min": x["gap_min"],
            "overnight": bool(out_at and in_at and in_at.date() < out_at.date()),
            "date": d.isoformat() if d else None, "supplier_id": x["supplier"].id}


def _quantiles(xs):
    if not xs:
        return None
    s = sorted(xs)

    def q(p):
        return s[min(len(s) - 1, int(round(p * (len(s) - 1))))]
    return {"n": len(s), "min": s[0], "p50": q(.5), "p90": q(.9), "max": s[-1]}
