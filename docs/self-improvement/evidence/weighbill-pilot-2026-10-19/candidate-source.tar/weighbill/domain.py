# -*- coding: utf-8 -*-
"""领域模型与校验规则。纯函数,不碰 IO。"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

FIELDS = ["客户名", "序号", "日期", "入站时间", "出站时间", "车号", "货名", "收费", "总重", "皮重", "净重",
          # 0.3.1:对齐客户线下台账(2026-10-12 收到)新增的列
          "装点", "监磅员", "供应商", "备注"]
# 内部键沿用 0.1 版(老数据、老接口都按它存),显示名按客户台账的叫法
FIELD_LABELS = {"序号": "磅单号", "车号": "车牌号", "皮重": "空重"}


def label(k: str) -> str:
    return FIELD_LABELS.get(k, k)
KEY_FIELDS = ("序号", "车号", "净重")

STATUS_AUTO_OK = "auto_ok"
STATUS_NEEDS_REVIEW = "needs_review"
STATUS_REVIEWED = "reviewed"
STATUS_FAILED = "failed"
STATUSES = (STATUS_AUTO_OK, STATUS_NEEDS_REVIEW, STATUS_REVIEWED, STATUS_FAILED)

# 单据类型只分三种角色(2026-10-14 用户定):厂商出厂单 → 进我们场的单(两者之间算磅差)→ 离开我们场的单(只采集,客户记在 customer)。
# 厂商叫什么、场叫什么、页签和 Excel 表头怎么写,全在配置里(见 Naming),代码里不写具体厂商。
DOC_SUPPLIER_OUT = "supplier_out"
DOC_SITE_IN = "site_in"
DOC_SITE_OUT = "site_out"
DOC_TYPES = {DOC_SUPPLIER_OUT: "厂商出厂", DOC_SITE_IN: "进场", DOC_SITE_OUT: "出场"}     # 中性默认名
# 0.3.3 及以前的键:老库迁移、老接口参数、老配置里的现场链接都认
LEGACY_DOC_TYPES = {"byd_out": DOC_SUPPLIER_OUT, "plant_in": DOC_SITE_IN, "product_out": DOC_SITE_OUT}


def canon_doc_type(v):
    return LEGACY_DOC_TYPES.get(v, v)
DOC_COLUMNS = {
    DOC_SUPPLIER_OUT: ["序号", "入站时间", "出站时间", "车号", "货名", "装点", "总重", "皮重", "净重", "监磅员", "备注"],
    DOC_SITE_IN: ["序号", "入站时间", "出站时间", "车号", "货名", "总重", "皮重", "净重", "监磅员", "供应商", "备注"],
    DOC_SITE_OUT: ["序号", "出站时间", "车号", "货名", "总重", "皮重", "净重", "监磅员", "供应商", "备注"],
}
# 出场单只有一个时间,台账叫「出库时间」,内部存在 出站时间
DOC_LABEL_OVERRIDES = {DOC_SITE_OUT: {"出站时间": "出库时间"}}


def col_label(doc_type: str, k: str) -> str:
    return DOC_LABEL_OVERRIDES.get(doc_type, {}).get(k) or label(k)


@dataclass
class Naming:
    """所有显示用的名字。默认是中性叫法;具体客户在 config.json 里配(supplier_name、site_name、doc_labels…)。"""
    supplier: str = "厂商"
    site: str = "本场"
    labels: dict = field(default_factory=dict)          # 页签/单据类型名
    titles: dict = field(default_factory=dict)          # Excel 每天一张表的大标题
    summary_titles: dict = field(default_factory=dict)  # Excel 月度汇总表标题,{m} = 月份
    summary_sheets: dict = field(default_factory=dict)  # Excel 月度汇总表的工作表名
    customers: list = field(default_factory=list)       # 出场单客户的快捷选项
    notes: dict = field(default_factory=dict)           # Excel 每天一张表末尾的填表说明
    out_sheet_suffix: str = "（{customer}）"             # 出场单按天分表时,当天只有一个客户就加在表名后
    ref_prefixes: dict = field(default_factory=dict)    # 登记编号前缀

    # 拼音首字母:厂商出厂 CC、进场 JC、出场(出库)CK
    DEFAULT_REF_PREFIXES = {DOC_SUPPLIER_OUT: "CC", DOC_SITE_IN: "JC", DOC_SITE_OUT: "CK"}
    DEFAULT_NOTE = "说明：1、如实记录，信息准确清晰，一车一磅单一记录，不得涂改；2、如遇异常情况，及时上报并在备注栏记录。"

    @classmethod
    def build(cls, supplier="厂商", site="本场", labels=None, titles=None, summary_titles=None, customers=None,
              notes=None, out_sheet_suffix=None, summary_sheets=None, ref_prefixes=None):
        n = cls(supplier=supplier, site=site, customers=list(customers or []))
        n.notes = {k: (notes or {}).get(k) or cls.DEFAULT_NOTE for k in DOC_TYPES}
        n.ref_prefixes = {**cls.DEFAULT_REF_PREFIXES, **{k: v for k, v in (ref_prefixes or {}).items() if v}}
        if out_sheet_suffix is not None:
            n.out_sheet_suffix = out_sheet_suffix
        default_labels = {DOC_SUPPLIER_OUT: f"{supplier}出厂", DOC_SITE_IN: f"{site}进场", DOC_SITE_OUT: f"{site}出场"}
        n.labels = {k: (labels or {}).get(k) or v for k, v in default_labels.items()}
        n.titles = {k: (titles or {}).get(k) or f"{n.labels[k]}过磅记录表" for k in DOC_TYPES}
        n.summary_titles = {k: (summary_titles or {}).get(k) or f"{n.labels[k]}{{m}}月份汇总表" for k in DOC_TYPES}
        n.summary_sheets = {k: (summary_sheets or {}).get(k) or f"月度{n.labels[k]}汇总表" for k in DOC_TYPES}
        return n

    def summary_sheet(self, doc_type: str) -> str:
        return self.summary_sheets[doc_type]

    def public(self) -> dict:
        return {"supplier": self.supplier, "site": self.site, "labels": self.labels, "titles": self.titles,
                "customers": self.customers}

# 流程阶段:现场拍完待监磅员确认 → 监磅员提交(实时可见,未审核)→ 审核员对照纸质磅单确认(已审核)
STAGE_DRAFT = "draft"
STAGE_SUBMITTED = "submitted"
STAGE_APPROVED = "approved"
STAGES = {STAGE_DRAFT: "待现场确认", STAGE_SUBMITTED: "未审核", STAGE_APPROVED: "已审核"}


@dataclass
class Record:
    """一张单据的一条台账记录。*_key 是文件存储里的键,不是 URL。"""
    id: str
    created_at: str
    uploader: str
    batch_id: str
    seq_in_batch: int
    orig_key: Optional[str]
    crop_key: Optional[str]
    sig_key: Optional[str]
    fields: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    weight_ok: int = 0
    weight_msg: str = ""
    status: str = STATUS_FAILED
    model: Optional[str] = None          # 识别模型(与旧版同名同义)
    seg_model: Optional[str] = None      # 分割模型(旧版不留痕,0.2.0 起记录)
    error: Optional[str] = None
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[str] = None
    # 0.3.0
    doc_type: str = DOC_SITE_IN
    customer: Optional[str] = None       # 成品出库的客户;其他类型可空
    stage: str = STAGE_DRAFT
    submitted_by: Optional[str] = None
    submitted_at: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    # 0.4.2 登记编号:系统自己发的号(如 RK-20261014-0007),登记时定下,之后改字段、改类型都不变,也不复用。
    # 磅单号是对方地磅打的、可能被认错,不能当我们的编号。
    ref_no: Optional[str] = None
    # 0.5.0 作废:错传、试拍、认不出又重拍了的单据不删,标作废(谁、何时、为什么),不进汇总、磅差、导出、查重
    voided_by: Optional[str] = None
    voided_at: Optional[str] = None
    void_reason: Optional[str] = None
    # 0.5.0 有疑问:审核员核对时发现对不上、又没法当场定的,挂个说明,单独一个页签
    flag_note: Optional[str] = None
    # 0.5.0 来源:现场链接上传的记 "link:<令牌的单向摘要>"(不是令牌本身),链接只能看、改自己这类记录
    source: Optional[str] = None
    # 0.6.0 版本号:每次写入加一。写的时候核对「我读到的还是不是最新的」,多台服务器同时改同一张单也不会互相覆盖
    version: int = 0
    origin_id: str = "legacy"  # 业务来源单位，独立于上传渠道 source 和票面供应商

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------- 校验规则 ----------------
def _half(s):
    return "".join(chr(ord(c) - 0xFEE0) if 0xFF01 <= ord(c) <= 0xFF5E else (" " if c == "　" else c)
                   for c in str(s))


def norm(s):
    return "" if s is None else re.sub(r"\s", "", _half(str(s)).upper())


# 车牌上的分隔点:票据普遍印成「鲁A·5K862」,不同打印机/字体用的点不一样
_PLATE_SEP = re.compile(r"[·•・‧∙.\-]")
# 普通牌:省+字母+5位(新能源6位);挂车牌:省+字母+4位+挂
# 首字必须是省份简称:OCR 把模糊的「粤」认成「号」这类,形状对但不是车牌(2026-10-14 实测漏过一次)
PROVINCES = "京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼"
_PLATE_OK = re.compile(rf"^[{PROVINCES}][A-Z](?:[A-HJ-NP-Z0-9]{{5,6}}|[A-HJ-NP-Z0-9]{{4}}挂)$")


# 省份简称的繁体/异体写法:客户台账里真实出现过「粵BEX561」,不归一就会和「粤BEX561」配不上
_PLATE_TRAD = str.maketrans({"粵": "粤", "魯": "鲁", "蘇": "苏", "滬": "沪", "閩": "闽", "贛": "赣", "遼": "辽",
                             "陝": "陕", "晉": "晋", "雲": "云", "貴": "贵", "瓊": "琼", "寧": "宁", "黒": "黑"})


def norm_plate(v) -> str:
    return _PLATE_SEP.sub("", norm(v)).translate(_PLATE_TRAD)


def validate_fields(d: dict):
    warns = []
    plate = norm_plate(d.get("车号"))
    raw = norm(d.get("车号"))
    if raw and raw[0] != raw[:1].translate(_PLATE_TRAD):
        warns.append(f"车牌用了繁体字「{raw[0]}」,已按「{raw[0].translate(_PLATE_TRAD)}」配对,建议改正")
    if plate:
        if re.search(r"[IO]", plate[1:]):
            warns.append("车号含I/O:民用车牌不使用字母I、O,疑为数字1/0误识")
        elif not _PLATE_OK.match(plate):
            warns.append("车号格式异常:" + plate)
    sn = norm(d.get("序号"))
    if sn:
        if not re.match(r"^[A-Z]{0,5}\d{8,}$", sn):
            warns.append("序号字符集异常(注意O/0、I/1、S/5、B/8混淆)")
        mdt = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", norm(d.get("日期")))
        if mdt:
            code = mdt.group(1)[2:] + mdt.group(2) + mdt.group(3)
            codes = {code}
            for k in ("入站时间", "出站时间"):            # 有的厂商单号编的是入站那天(前一天傍晚入站)
                m2 = _moment(norm(d.get(k)))
                if m2 and m2[0]:
                    y = m2[0][0] or int(mdt.group(1))
                    codes.add(f"{y % 100:02d}{m2[0][1]:02d}{m2[0][2]:02d}")
            if not any(c in sn for c in codes):
                warns.append(f"序号中未找到日期码{code}:序号或日期二者之一识别有误")
    dv = norm(d.get("日期"))
    if dv and not re.match(r"^\d{4}-\d{2}-\d{2}$", dv):
        warns.append("日期格式异常")
    t1, t2 = norm(d.get("入站时间")), norm(d.get("出站时间"))
    p1, p2 = _moment(t1), _moment(t2)
    if t1 and p1 is None: warns.append("入站时间格式异常")
    if t2 and p2 is None: warns.append("出站时间格式异常")
    if p1 and p2 and (p1[0] is None) == (p2[0] is None) and p1 > p2:
        warns.append("入站时间晚于出站时间")
    return warns


# 「08:30」「08:30:20」或带日期的「2026-10-11 08:30:20」「10-11 8:30」(去空白后形如 2026-10-1108:30)
_TIME = re.compile(r"^(?:(\d{4})-)?(?:(\d{1,2})-(\d{1,2}))?(\d{1,2}):(\d{2})(?::(\d{2}))?$")


def _moment(t: str):
    """解析成可比较的 (日期元组或 None, 秒数);格式不对返回 None。"""
    m = _TIME.match(t or "")
    if not m:
        return None
    y, mo, dd, hh, mi, ss = m.groups()
    if int(hh) > 23 or int(mi) > 59:
        return None
    day = (int(y or 0), int(mo), int(dd)) if mo else None
    return (day, int(hh) * 3600 + int(mi) * 60 + int(ss or 0))


def weight_check(d: dict):
    def num(v):
        if v is None: return None
        m = re.search(r"-?\d+(\.\d+)?", str(v).replace(",", ""))
        return float(m.group()) if m else None
    g, t, n = num(d.get("总重")), num(d.get("皮重")), num(d.get("净重"))
    if None in (g, t, n):
        return 0, "重量数据不全"
    if abs(g - t - n) <= 1:
        return 1, f"通过 {g:g}-{t:g}={n:g}"
    return 0, f"不符 {g:g}-{t:g}≠{n:g}"


def key_missing(fields: dict) -> bool:
    return any(not norm(fields.get(k)) for k in KEY_FIELDS)


def auto_status(warns: list, weight_ok: int, fields: dict) -> str:
    return STATUS_AUTO_OK if (not warns and weight_ok and not key_missing(fields)) else STATUS_NEEDS_REVIEW


def normalize_fields(f: dict) -> dict:
    """识别出来的、人改的,存之前都过一遍:日期统一成 YYYY-MM-DD(认不出的原样留着,校验会提示)。"""
    d = normalize_date(f.get("日期"))
    if d:
        f["日期"] = d
    return f


def pick_fields(raw: Any) -> dict:
    """从识别结果里只取约定字段;非 dict 视为空。"""
    raw = raw if isinstance(raw, dict) else {}
    return {k: raw.get(k) for k in FIELDS}


# ---------------------------------------------------------------- 同一张磅单(防重复登记)
def _edit1(a: str, b: str) -> bool:
    """两串最多差一个字(替换/多/少一个)。"""
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    s, l = (a, b) if len(a) < len(b) else (b, a)
    return any(l[:i] + l[i + 1:] == s for i in range(len(l)))


def _wt(v):
    """重量按数比:「17,200」「17200」「17200kg」是同一个数。"""
    m = re.search(r"\d+(?:\.\d+)?", str(v or "").replace(",", ""))
    return float(m.group()) if m else None


def normalize_date(v) -> Optional[str]:
    """「2026/10/6」「2026-10-5」「2026年10月6日」→ 2026-10-06;认不出返回 None。
    日期筛选是按字符串比的,不归一会让这类记录从筛选里消失(审计复现过)。"""
    m = re.search(r"(\d{4})\D{1,3}(\d{1,2})\D{1,3}(\d{1,2})", str(v or ""))
    if not m:
        return None
    try:
        import datetime as _d
        return _d.date(int(m[1]), int(m[2]), int(m[3])).isoformat()
    except ValueError:
        return None


def _hhmm(v) -> str:
    m = re.findall(r"(\d{1,2})[:：](\d{2})", str(v or ""))
    return f"{int(m[-1][0]):02d}:{m[-1][1]}" if m else ""


def same_ticket(a: dict, b: dict) -> Optional[str]:
    """a、b 是不是同一张磅单(同一单据类型内比)。是就返回理由,不是返回 None。

    磅单号是地磅打出来的,一张单一个号:号一样就是同一张(除非车号、净重都对不上——那是读错了别处,不合并)。
    识别可能读错一个字,但相邻两张单的号本来就只差一个字(同一辆车连跑两趟就是这样),
    所以号只差一个字时,车号、净重、时间(到分钟)里读得出的都得一样、且至少两样对得上才算。
    没有可用的号时,车号 + 净重 + 时间三样都一样才算——同一辆车两次过磅,净重和时刻不可能都一样。"""
    sa, sb = norm(a.get("序号")), norm(b.get("序号"))
    pa, pb = norm_plate(a.get("车号")), norm_plate(b.get("车号"))
    na, nb = _wt(a.get("净重")), _wt(b.get("净重"))
    da, db = normalize_date(a.get("日期")), normalize_date(b.get("日期"))
    same_day = not (da and db and da != db)
    ta = _hhmm(a.get("出站时间")) or _hhmm(a.get("入站时间"))
    tb = _hhmm(b.get("出站时间")) or _hhmm(b.get("入站时间"))
    pairs = [(x, y) for x, y in ((pa, pb), (na, nb), (ta, tb)) if x and y]
    agree = sum(x == y for x, y in pairs)
    if len(sa) >= 6 and len(sb) >= 6:
        if sa == sb and not (pa and pb and na and nb and pa != pb and na != nb):
            return f"磅单号相同({sa})"
        if sa != sb and _edit1(sa, sb) and agree == len(pairs) and agree >= 2 and same_day:
            return f"磅单号只差一个字({sa} / {sb}),车号、净重、时间也都一样"
        if sa != sb:
            return None           # 两个号都读出来了、又明显不同:就是两张单(同一辆车按班次跑,车号净重时刻可能都一样)
    if not same_day:
        return None
    if pa and na and ta and (pa, na, ta) == (pb, nb, tb):
        return f"车号、净重、时间都一样({pa} {na}kg {ta})"
    # 号和车号都没读出来时的兜底:总重、皮重、净重三个数都一样(皮重随车,三个都对上等于同一车同一磅),时间读得出就也得一样
    w_a, w_b = tuple(_wt(a.get(k)) for k in ("总重", "皮重", "净重")), tuple(_wt(b.get(k)) for k in ("总重", "皮重", "净重"))
    if all(w_a) and w_a == w_b and not (ta and tb and ta != tb) and not (pa and pb and pa != pb):
        return f"总重、皮重、净重都一样({'/'.join(map(str, w_a))})"
    return None
