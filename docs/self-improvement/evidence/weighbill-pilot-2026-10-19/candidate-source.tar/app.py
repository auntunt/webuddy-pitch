# -*- coding: utf-8 -*-
"""兼容入口。0.2.0 起实现位于 weighbill/ 包内;保留此文件让既有启动方式不变:
    python app.py
    uvicorn app:app --host 0.0.0.0 --port 8000
"""
from weighbill.http_api import create_app

app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
