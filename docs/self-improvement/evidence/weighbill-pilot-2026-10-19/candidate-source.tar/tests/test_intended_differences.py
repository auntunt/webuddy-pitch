# -*- coding: utf-8 -*-
"""0.2 与 0.1 有意不同的地方。每条先断言旧版确实如此,再断言新版行为——
否则「修复」可能修的是一个不存在的问题。"""
from __future__ import annotations

import asyncio, json

import pytest

from tests.fixtures import photo
from tests.test_equivalence import ModelScript, rec_text, run_legacy, run_new, BOX1, FIELDS_OK


def test_all_boxes_uncroppable_is_recorded_not_silently_dropped(tmp_path):
    seg = [json.dumps([{"x": 1200, "y": 0, "w": 10, "h": 10}])]       # 既非百分比也非 0-1000
    old, _ = run_legacy(tmp_path, photo(1), ModelScript(seg, [], []))
    assert old == [], "前提:0.1 版在这里返回 0 条记录(照片已落盘,台账无痕)"
    new, _ = run_new(tmp_path, photo(1), ModelScript(seg, [], []))
    assert len(new) == 1 and new[0].status == "failed"
    assert new[0].orig_key and "无法裁出有效区域" in new[0].warnings[0]


def test_recognition_returning_array_fails_one_record_not_whole_batch(tmp_path):
    seg = [json.dumps([{"x": 2, "y": 7, "w": 44, "h": 85}, {"x": 52, "y": 7, "w": 44, "h": 85}])]
    rec = ['["不是", "对象"]', rec_text()]
    with pytest.raises(AttributeError):
        run_legacy(tmp_path, photo(2), ModelScript(seg, list(rec), ["null"]))
    new, _ = run_new(tmp_path, photo(2), ModelScript(seg, list(rec), ["null"]))
    assert [r.status for r in new][0] == "failed" and "识别结果不是对象" in new[0].error
    assert new[1].fields["序号"] == "20260922031", "同批的另一张单据必须照常入账"


def test_signature_box_as_array_does_not_crash(tmp_path):
    rec = [rec_text(sig=[35, 80, 30, 10])]
    with pytest.raises(AttributeError):
        run_legacy(tmp_path, photo(1), ModelScript([json.dumps(BOX1)], list(rec), ["null"]))
    new, _ = run_new(tmp_path, photo(1), ModelScript([json.dumps(BOX1)], list(rec), ["null"]))
    assert new[0].status == "needs_review" and "签名定位失败,需人工框选" in new[0].warnings


def test_seg_model_is_recorded(tmp_path):
    old, _ = run_legacy(tmp_path, photo(1), ModelScript([json.dumps(BOX1)], [rec_text()], ["null"]))
    assert "seg_model" not in old[0], "前提:0.1 版不记录分割模型"
    new, svc = run_new(tmp_path, photo(1), ModelScript([json.dumps(BOX1)], [rec_text()], ["null"]))
    assert new[0].seg_model == svc.settings.seg_model and new[0].model == svc.settings.rec_model


# ------------------------------------------------------------ 车号:分隔点与挂车牌
def _legacy_validate(tmp_path):
    import importlib.util, shutil
    from tests.test_equivalence import LEGACY_SRC
    d = tmp_path / "legacy_v"; d.mkdir(parents=True); shutil.copy(LEGACY_SRC, d / "app.py"); (d / "static").mkdir()
    spec = importlib.util.spec_from_file_location("legacy_validate", d / "app.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod.validate_fields


# 票据上的写法:取自 bench/truth_gen.json。其中「苏E·A5839挂」是出图模型编的(挂车牌只有 4 位),
# 规则拦下它是对的,放在下面「必须拦住」一组里。
REAL_PLATES = ["鲁A·5K892", "鲁B·5K827", "冀A·5837挂", "苏A·5K827", "鲁B·9M462", "苏A·5K823",
               "鲁B·9M672", "豫C·3T415", "冀A·5K823", "鲁A·5K862", "冀A·5K827"]


def plate_warns(validate, plate):
    return [w for w in validate({"车号": plate}) if w.startswith("车号")]


def test_real_ticket_plates_no_longer_flagged(tmp_path):
    from weighbill.domain import validate_fields
    old = _legacy_validate(tmp_path)
    assert all(plate_warns(old, p) for p in REAL_PLATES), "前提:0.1 版把这些真实写法全判为格式异常"
    bad = {p: plate_warns(validate_fields, p) for p in REAL_PLATES if plate_warns(validate_fields, p)}
    assert not bad, bad


@pytest.mark.parametrize("plate", ["鲁A•5K862", "鲁A・5K862", "鲁A.5K862", "鲁A-5K862", "鲁Ａ·５Ｋ８６２", "鲁A 5K862"])
def test_separator_variants_accepted(plate):
    from weighbill.domain import validate_fields
    assert not plate_warns(validate_fields, plate)


@pytest.mark.parametrize("plate,why", [
    ("鲁A·5K86", "位数不够"), ("鲁A·5K86234", "位数太多"), ("鲁·5K862", "缺发证机关字母"),
    ("AA·5K862", "缺省份简称"), ("冀A·583挂", "挂车牌只有 3 位"), ("苏E·A5839挂", "挂车牌是 4 位,这里 5 位"), ("冀A·5837挂挂", "挂字重复"),
    ("鲁A·5O862", "含字母 O"), ("鲁A·5I862", "含字母 I"),
])
def test_still_rejects_malformed_plates(plate, why):
    from weighbill.domain import validate_fields
    assert plate_warns(validate_fields, plate), f"不该放过:{why}"



# ------------------------------------------------------------ 失败归因:服务出错 vs 没找到单据
# 真实事故(2026-09-24):模型输出坏 JSON,页面却连续 4 次让现场的人「摆平单据再拍」。
SERVICE_FAULT_CASES = {
    "分割输出坏JSON": (1, ['[ {"x": 45, 69, 475, 910] }'], [], []),
    "分割调用抛错": (1, [RuntimeError("timeout")], [], []),
    "双张_第二张识别抛错": (2, [json.dumps([{"x": 2, "y": 7, "w": 44, "h": 85}, {"x": 52, "y": 7, "w": 44, "h": 85}])],
                         [rec_text(), RuntimeError("rate limited")], ["null"]),
}


@pytest.mark.parametrize("name", list(SERVICE_FAULT_CASES))
def test_service_faults_are_not_blamed_on_the_photo(tmp_path, name):
    n, seg, rec, sig = SERVICE_FAULT_CASES[name]
    old, _ = run_legacy(tmp_path, photo(n), ModelScript(list(seg), list(rec), list(sig)))
    old_failed = [r for r in old if r["status"] == "failed"]
    assert old_failed and not any(json.loads(r["warnings"])[0].startswith("识别服务出错") for r in old_failed), \
        "前提:0.1 版把这类失败记成「分割失败/识别失败」,页面据此让人重拍"
    new, _ = run_new(tmp_path, photo(n), ModelScript(list(seg), list(rec), list(sig)))
    failed = [r for r in new if r.status == "failed"]
    assert failed and all(r.warnings[0].startswith("识别服务出错:") for r in failed)
    assert [r.status for r in new if r.status != "failed"] == [r["status"] for r in old if r["status"] != "failed"], \
        "同批其余单据的结果不得受影响"


def test_no_ticket_still_says_segmentation_failed(tmp_path):
    new, _ = run_new(tmp_path, photo(1), ModelScript(["[]"], [], []))
    assert new[0].warnings[0].startswith("分割失败:")


def test_capture_page_and_service_agree_on_the_fault_prefix():
    """页面靠前缀决定「重拍」还是「原样重传」;两边各写一份字面量,改一边另一边就静默失效。"""
    from pathlib import Path
    from weighbill.service import FAULT_SERVICE
    html = (Path(__file__).resolve().parent.parent / "weighbill/static/capture.html").read_text("utf-8")
    assert f'startsWith("{FAULT_SERVICE.rstrip(":")}")' in html



# ------------------------------------------------------------ 重量复读
# 真实票据(中冶宝钢)「收费」一格常只印「元」,首读把下面的数字整行上移。
SHIFTED = dict(FIELDS_OK, 收费="38560", 总重="12340", 皮重="26220", 净重="4500")
SIG_OK = {"x": 35, "y": 80, "w": 30, "h": 10}


def _run(tmp_path, rec, weights):
    s = ModelScript([json.dumps(BOX1)], [rec_text(rec, sig=SIG_OK)], ["null"], weights)
    new, _ = run_new(tmp_path, photo(1), s)
    return new[0], [c[1] for c in s.calls]


def test_reread_fixes_row_shift_and_leaves_a_trail(tmp_path):
    old, _ = run_legacy(tmp_path, photo(1), ModelScript([json.dumps(BOX1)], [rec_text(SHIFTED, sig=SIG_OK)], ["null"]))
    assert old[0]["status"] == "needs_review" and old[0]["weight_ok"] == 0, "前提:0.1 版整行错位只能进待复核"
    r, kinds = _run(tmp_path, SHIFTED, ['{"总重": "38560", "皮重": "12340", "净重": "26220"}'])
    assert kinds.count("weights") == 1
    assert (r.fields["总重"], r.fields["皮重"], r.fields["净重"]) == ("38560", "12340", "26220")
    assert r.weight_ok == 1 and "复读更正:原 12340/26220/4500" in r.weight_msg
    assert r.fields["收费"] == "38560", "只更正三行重量,其余字段不动"


@pytest.mark.parametrize("reply", ['{"总重": "38560", "皮重": "12340", "净重": "9"}', RuntimeError("502"), "null"])
def test_reread_that_does_not_balance_changes_nothing(tmp_path, reply):
    r, _ = _run(tmp_path, SHIFTED, [reply])
    assert (r.fields["总重"], r.fields["皮重"], r.fields["净重"]) == ("12340", "26220", "4500")
    assert r.weight_ok == 0 and r.status == "needs_review" and "复读" not in r.weight_msg


def test_reread_only_when_first_read_does_not_balance(tmp_path):
    r, kinds = _run(tmp_path, FIELDS_OK, [])
    assert "weights" not in kinds and r.status == "auto_ok"
