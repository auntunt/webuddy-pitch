# -*- coding: utf-8 -*-
"""开发工具 tools/load_ledgers.py(产品只导出不导入)。用程序生成与客户表格同版式的工作簿,客户真实数据不进仓库。"""
from __future__ import annotations

import datetime as dt
import io
import json

from openpyxl import Workbook, load_workbook
from openpyxl.drawing.image import Image as XLImage
from PIL import Image

from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from tools.load_ledgers import main as load_main, read_ledger
from tests.fixtures import receipt


def _img():
    b = io.BytesIO(); receipt().save(b, "JPEG"); b.seek(0); return XLImage(b)


def ledger(path, title, date_text, header, rows, sheet="10月11日", extra_sheet=True):
    wb = Workbook(); ws = wb.active; ws.title = sheet
    ws.append([title]); ws.append([date_text]); ws.append(header)
    for i, r in enumerate(rows, start=1):
        ws.append([i] + r)
        ws.add_image(_img(), f"{chr(64 + len(header))}{ws.max_row}")
    ws.append([len(rows) + 1, "合计"]); ws.append(["说明：1、如实记录……"])
    if extra_sheet:
        s2 = wb.create_sheet("月度出厂汇总表"); s2.append(["比亚迪循环废钢10月份出厂汇总表"]); s2.append(["序号", "日期", "货名"])
    wb.save(path)


BYD_H = ["序号", "磅单号", "入站时间", "出站时间", "车牌号", "货名", "装点", "总重", "空重", "净重", "监磅员", "备注", "磅单图片"]
PLANT_H = ["序号", "磅单号", "入站时间", "出站时间", "车牌号", "货名", "总重", "空重", "净重", "监磅员", "供应商", "备注", "磅单图片"]
BYD_ROWS = [["xm1202610100068", "10-10 17:21", "10-11 8:30", "湘ED4989", "冲压片", "2#", 27200, 16580, 10620, "邢喜", None],
            ["xm1202610100074", "10-10 19:38", "10-11 8:32", "湘EC5529", "冲压片", "2#", 26220, 16440, 9780, "邢喜", None]]
PLANT_ROWS = [["CZD26101110064142889", dt.time(9, 36), dt.time(9, 42), "湘EC5529", "汽车废钢料", 26390, 16460, 9930, "欧阳泽豪", "阙朝瑞", None],
              ["CZD26101110084552222", dt.time(9, 36), dt.time(9, 47), "湘ED4989", "汽车废钢料", 27390, 16580, 10810, "欧阳泽豪", "阙朝瑞", None]]


def test_read_ledger_maps_columns_by_header_name(tmp_path):
    f = tmp_path / "supplier.xlsx"
    ledger(f, "比亚迪循环废钢出厂过磅信息记录表", "日期：10月11日", BYD_H, BYD_ROWS)
    rows = list(read_ledger(f, 2026))
    assert len(rows) == 2, "合计行、说明行、汇总表都不算"
    r = rows[0]
    assert r["doc_type"] == "supplier_out" and r["date"] == dt.date(2026, 10, 11) and r["image"]
    assert r["fields"] | {} == {"序号": "xm1202610100068", "入站时间": "2026-10-10 17:21", "出站时间": "2026-10-11 8:30",
                                "车号": "湘ED4989", "货名": "冲压片", "装点": "2#", "总重": "27200", "皮重": "16580",
                                "净重": "10620", "监磅员": "邢喜", "备注": None, "日期": "2026-10-11"}


def test_columns_found_by_name_not_position(tmp_path):
    f = tmp_path / "site.xlsx"
    h = PLANT_H[:]; h[2], h[3] = h[3], h[2]                    # 客户把入站/出站两列对调
    rows = [[r[0], r[2], r[1]] + r[3:] for r in PLANT_ROWS]
    ledger(f, "循环废钢原材料入库过磅信息记录表", "日期：10月11日", h, rows)
    r = next(read_ledger(f, 2026))
    assert (r["fields"]["入站时间"], r["fields"]["出站时间"], r["fields"]["供应商"]) == ("09:36", "09:42", "阙朝瑞")


def test_import_is_idempotent_and_pairs_against_supplier(tmp_path, monkeypatch, capsys):
    a, b = tmp_path / "supplier.xlsx", tmp_path / "site.xlsx"
    ledger(a, "比亚迪循环废钢出厂过磅信息记录表", "日期：10月11日", BYD_H, BYD_ROWS)
    ledger(b, "循环废钢原材料入库过磅信息记录表", "日期：10月11日", PLANT_H, PLANT_ROWS)
    data = str(tmp_path / "d")
    monkeypatch.setenv("WEIGHBILL_CONFIG", str(tmp_path / "无配置.json"))   # 不读开发机上的 config.json
    assert load_main([data, str(a), str(b), "--year", "2026"]) == 0
    first = [json.loads(l) for l in capsys.readouterr().out.splitlines()]
    assert [(x["类型"], x["新增"], x["有图"], x["净重"]) for x in first] == [("厂商出厂", 2, 2, 20400), ("本场进场", 2, 2, 20740)], "没配名字时用中性叫法"
    assert load_main([data, str(a), str(b), "--year", "2026"]) == 0
    again = [json.loads(l) for l in capsys.readouterr().out.splitlines()]
    assert [(x["新增"], x["已存在"]) for x in again] == [(0, 2), (0, 2)], "重复导入不产生重复记录"

    svc = build_service(Settings(api_key="k", data_dir=data), vision=ScriptedVision())
    recs = svc.query(__import__("weighbill.ports", fromlist=["RecordQuery"]).RecordQuery(limit=50))
    assert len(recs) == 4 and {r.stage for r in recs} == {"approved"} and {r.approved_by for r in recs} == {"线下台账"}
    supplier = next(r for r in recs if r.fields["车号"] == "湘ED4989" and r.doc_type == "supplier_out")
    assert supplier.warnings == [], f"真实比亚迪行不应有校验警告(隔夜时间、单号编入站日): {supplier.warnings}"
    assert svc.blobs.open(supplier.crop_key)[:2] == b"\xff\xd8", "磅单图片原样留存"
    d = svc.reconciliation("2026-10-11", "2026-10-11")["days"][0]
    assert (d["trucks"], d["supplier_net"], d["site_net"], d["diff"]) == (2, 20400, 20740, 340)
    assert sorted((x["plate"], x["diff"]) for x in d["pairs"]) == [("湘EC5529", 150), ("湘ED4989", 190)]


def test_dry_run_writes_nothing(tmp_path, monkeypatch, capsys):
    a = tmp_path / "supplier.xlsx"
    ledger(a, "比亚迪循环废钢出厂过磅信息记录表", "日期：10月11日", BYD_H, BYD_ROWS)
    load_main([str(tmp_path / "d"), str(a), "--dry-run"])
    assert not (tmp_path / "d").exists(), "--dry-run 不建库、不写图"


def test_product_has_no_import_entry(tmp_path):
    """产品只导出、不导入:命令行与 HTTP 都没有导入入口。"""
    import subprocess, sys
    from fastapi.testclient import TestClient
    from weighbill.http_api import create_app
    out = subprocess.run([sys.executable, "-m", "weighbill", "--help"], capture_output=True, text=True).stdout
    assert "import" not in out and "导入" not in out
    app = create_app(build_service(Settings(api_key="k", data_dir=str(tmp_path)), vision=ScriptedVision()))
    assert not [r.path for r in app.routes if "import" in getattr(r, "path", "")]
    import weighbill.service as S
    assert not hasattr(S.WeighbillService, "import_record")
