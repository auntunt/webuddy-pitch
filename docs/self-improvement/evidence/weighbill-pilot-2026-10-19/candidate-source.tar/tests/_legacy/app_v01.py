# -*- coding: utf-8 -*-
"""
称重单采集与台账系统(最小可用版)
采集(手机H5拍照上传) -> 归一化 -> LLM分割 -> LLM识别 -> 规则校验 -> 签名墨迹吸附裁剪
-> SQLite台账 + 原图/单据图/签名图落盘留存 -> 报表查询/人工复核/CSV导出
"""
import os, io, json, uuid, sqlite3, base64, re, asyncio, datetime
from pathlib import Path

import httpx
import numpy as np
from PIL import Image, ImageOps
from fastapi import FastAPI, UploadFile, File, Request, HTTPException, Body
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles

try:  # HEIC 支持(iPhone/微信伪装jpg),未安装时自动跳过
    from pillow_heif import register_heif_opener
    register_heif_opener()
except Exception:
    pass

BASE = Path(__file__).parent
DATA = BASE / "data"
IMAGES = DATA / "images"
IMAGES.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA / "ledger.db"

# ---------------- 配置:环境变量 < config.json ----------------
CFG = {
    "base_url": os.getenv("LLM_BASE_URL", "https://openrouter.ai/api/v1"),
    "api_key": os.getenv("LLM_API_KEY", ""),
    "seg_model": os.getenv("SEG_MODEL", "google/gemini-3.8-flash"),
    "rec_model": os.getenv("REC_MODEL", "qwen/qwen3-vl-30b-a3b-instruct"),
    "enhance": True,          # 送模型前灰度+对比度拉伸
    "max_side": 2000,         # 原图归一化最长边
}
_cfg_file = BASE / "config.json"
if _cfg_file.exists():
    CFG.update(json.loads(_cfg_file.read_text("utf-8")))

FIELDS = ["客户名", "序号", "日期", "入站时间", "出站时间", "车号", "货名", "收费", "总重", "皮重", "净重"]

SEG_PROMPT = (
    '这张照片中有若干张纸质称重单据(可能是1张或多张)。请找出每一张单据,返回JSON数组,'
    '每个元素形如 {"x":10,"y":5,"w":40,"h":85},含义是该单据外接框相对整张图片宽高的百分比(0-100),'
    'x,y为左上角。框应完整包住整张单据,宁可略大留出边距,允许包含少量背景。只返回JSON数组,不要任何其他文字。'
)
REC_PROMPT = (
    '这是一张"称重单"照片。请提取以下字段,返回JSON对象:\n'
    '{"客户名":"","序号":"","日期":"","入站时间":"","出站时间":"","车号":"","货名":"","收费":"",'
    '"总重":"","皮重":"","净重":"","签名框":{"x":0,"y":0,"w":0,"h":0}}\n'
    '要求:所有字段值为字符串,重量只保留数字(单位kg,不要写单位),日期格式YYYY-MM-DD,'
    '看不清或不存在的字段填null;"签名框"是图中手写签名区域相对这张图宽高的百分比外接框,没有签名则为null;'
    '只返回JSON,不要任何其他文字。'
)
SIG_PROMPT = (
    '这张称重单照片中有手写签名(通常在"可称重员"一栏)。请返回签名区域的外接框JSON,'
    '格式 {"x":0,"y":0,"w":0,"h":0},数值为相对这张图宽高的百分比(0-100),框可略大。只返回JSON。'
)

# ---------------- 数据库 ----------------
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS records(
            id TEXT PRIMARY KEY,
            created_at TEXT, uploader TEXT, batch_id TEXT, seq_in_batch INTEGER,
            orig_path TEXT, crop_path TEXT, sig_path TEXT,
            fields TEXT, warnings TEXT, weight_ok INTEGER, weight_msg TEXT,
            status TEXT, model TEXT, error TEXT)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_created ON records(created_at)")

# ---------------- 图像处理 ----------------
def normalize(raw: bytes) -> Image.Image:
    """解码(含HEIC)->按EXIF转正->RGB->限制最长边"""
    im = Image.open(io.BytesIO(raw))
    im = ImageOps.exif_transpose(im).convert("RGB")
    m = max(im.size)
    if m > CFG["max_side"]:
        s = CFG["max_side"] / m
        im = im.resize((int(im.width * s), int(im.height * s)))
    return im

def enhance(im: Image.Image) -> Image.Image:
    g = np.asarray(im.convert("L"), dtype=np.float32)
    lo, hi = np.percentile(g, [2, 98])
    g = np.clip((g - lo) * 255.0 / max(1.0, hi - lo), 0, 255).astype(np.uint8)
    return Image.fromarray(g).convert("RGB")

def data_url(im: Image.Image, max_side=1400) -> str:
    m = max(im.size)
    if m > max_side:
        s = max_side / m
        im = im.resize((int(im.width * s), int(im.height * s)))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=90)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

def norm_box(box):
    """把模型返回的框统一成百分比(0-100)框;无法解释则 None。

    模型不但可能不按"百分比"作答(Qwen-VL 常给 0-1000 归一化坐标),
    实测还会在同一个框里混用两套单位,例如 {x:40,y:81,w:45,h:90}
    ——x,y 是 0-1000 而 w,h 是百分比。所以位置(x,y)和尺寸(w,h)
    各自独立判定缩放,枚举 4 种组合,取"落在画面内"的解;
    并列时先取缩放次数少的(更贴近模型原意),再取面积大的。
    """
    if not box or not all(isinstance(box.get(k), (int, float)) for k in ("x", "y", "w", "h")):
        return None
    x0, y0, w0, h0 = (float(box[k]) for k in ("x", "y", "w", "h"))
    if min(x0, y0, w0, h0) < 0 or max(x0, y0, w0, h0) > 1000.0 * 1.05:
        return None

    cands = []
    for ds, (x, y) in ((0, (x0, y0)), (1, (x0 / 10.0, y0 / 10.0))):
        for dd, (w, h) in ((0, (w0, h0)), (1, (w0 / 10.0, h0 / 10.0))):
            if w <= 0 or h <= 0:
                continue
            if x > 100.0 or y > 100.0 or x + w > 100.5 or y + h > 100.5:
                continue
            cands.append((ds + dd, -(w * h), {"x": x, "y": y,
                                              "w": min(w, 100.0 - x), "h": min(h, 100.0 - y)}))
    if not cands:
        return None
    return min(cands, key=lambda c: (c[0], c[1]))[2]


def crop_percent(im: Image.Image, box: dict, pad=2.0):
    box = norm_box(box)
    if box is None:
        return None
    W, H = im.size
    x = max(0.0, box["x"] - pad); y = max(0.0, box["y"] - pad)
    w = min(100 - x, box["w"] + 2 * pad); h = min(100 - y, box["h"] + 2 * pad)
    px = (int(x*W/100), int(y*H/100), int((x+w)*W/100), int((y+h)*H/100))
    if px[2] - px[0] < 8 or px[3] - px[1] < 8:
        return None
    return im.crop(px)

def _remove_runs(m: np.ndarray, axis: int, frac: float) -> np.ndarray:
    """抹掉沿axis方向长度超过frac*边长的连续暗段(表格线/边框)"""
    view = m if axis == 1 else m.T
    L = view.shape[1]; th = int(L * frac)
    for r in view:
        edges = np.flatnonzero(np.diff(np.concatenate(([0], r.astype(np.int8), [0]))))
        for s, e in zip(edges[::2], edges[1::2]):
            if e - s > th:
                r[s:e] = False
    return m

def ink_snap(im: Image.Image, box: dict):
    """以LLM粗框为中心,按实际墨迹重新收紧定位;返回百分比框或None"""
    box = norm_box(box)
    if box is None:
        return None
    pad = 10.0
    rx = max(0.0, box["x"] - pad); ry = max(0.0, box["y"] - pad)
    rw = min(100 - rx, box["w"] + 2 * pad); rh = min(100 - ry, box["h"] + 2 * pad)
    W, H = im.size
    region = im.crop((int(rx*W/100), int(ry*H/100), int((rx+rw)*W/100), int((ry+rh)*H/100)))
    if region.width < 8 or region.height < 8:
        return None
    s = min(1.0, 400 / region.width)
    rs = region.resize((max(1, int(region.width*s)), max(1, int(region.height*s))))
    g = np.asarray(rs.convert("L"))
    m = g < 110
    m = _remove_runs(m, 1, 0.2)
    m = _remove_runs(m, 0, 0.2)
    ys, xs = np.nonzero(m)
    if xs.size < m.size * 0.002:
        return None
    x1, x2 = np.percentile(xs, [2, 98]); y1, y2 = np.percentile(ys, [2, 98])
    w, h = m.shape[1], m.shape[0]
    return {"x": rx + x1/w*rw, "y": ry + y1/h*rh,
            "w": max(1.0, (x2-x1)/w*rw), "h": max(1.0, (y2-y1)/h*rh)}

def sig_valid(receipt: Image.Image, sig: Image.Image):
    g = np.asarray(sig.convert("L"))
    r = float((g < 110).mean())
    area = (sig.width * sig.height) / (receipt.width * receipt.height)
    if 0.004 <= r <= 0.35 and 0.004 <= area <= 0.4:
        return r
    return None

# ---------------- 校验规则 ----------------
def _half(s): return "".join(chr(ord(c)-0xFEE0) if 0xFF01 <= ord(c) <= 0xFF5E else (" " if c == "\u3000" else c) for c in str(s))
def norm(s): return "" if s is None else re.sub(r"\s", "", _half(str(s)).upper())

def validate_fields(d: dict):
    warns = []
    plate = norm(d.get("车号"))
    if plate:
        if re.search(r"[IO]", plate[1:]):
            warns.append("车号含I/O:民用车牌不使用字母I、O,疑为数字1/0误识")
        elif not re.match(r"^[\u4e00-\u9fa5][A-Z][A-HJ-NP-Z0-9]{5,6}$", plate):
            warns.append("车号格式异常:" + plate)
    sn = norm(d.get("序号"))
    if sn:
        if not re.match(r"^[A-Z]{0,5}\d{8,}$", sn):
            warns.append("序号字符集异常(注意O/0、I/1、S/5、B/8混淆)")
        mdt = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", norm(d.get("日期")))
        if mdt:
            code = mdt.group(1)[2:] + mdt.group(2) + mdt.group(3)
            if code not in sn:
                warns.append(f"序号中未找到日期码{code}:序号或日期二者之一识别有误")
    dv = norm(d.get("日期"))
    if dv and not re.match(r"^\d{4}-\d{2}-\d{2}$", dv):
        warns.append("日期格式异常")
    tre = r"^\d{1,2}:\d{2}(:\d{2})?$"
    t1, t2 = norm(d.get("入站时间")), norm(d.get("出站时间"))
    if t1 and not re.match(tre, t1): warns.append("入站时间格式异常")
    if t2 and not re.match(tre, t2): warns.append("出站时间格式异常")
    if re.match(tre, t1 or "") and re.match(tre, t2 or "") and t1 > t2:
        warns.append("入站时间晚于出站时间")
    return warns

def weight_check(d: dict):
    def num(v):
        if v is None: return None
        m = re.search(r"-?\d+(\.\d+)?", str(v).replace(",", ""))
        return float(m.group()) if m else None
    g, t, n = num(d.get("总重")), num(d.get("皮重")), num(d.get("净重"))
    if None in (g, t, n):
        return 0, "重量数据不全"
    if abs(g - t - n) <= 1:
        return 1, f"通过 {g:g}-{t:g}={n:g}"
    return 0, f"不符 {g:g}-{t:g}≠{n:g}"

# ---------------- LLM 调用 ----------------
def extract_json(text: str):
    t = re.sub(r"```json|```", "", text).strip()
    a = re.search(r"[\[{]", t)
    if a: t = t[a.start():]
    b = max(t.rfind("]"), t.rfind("}"))
    if b >= 0: t = t[:b+1]
    return json.loads(t)

async def llm(client: httpx.AsyncClient, model: str, prompt: str, im: Image.Image) -> str:
    r = await client.post(
        CFG["base_url"].rstrip("/") + "/chat/completions",
        headers={"Authorization": "Bearer " + CFG["api_key"], "X-Title": "weighbill-system"},
        json={"model": model, "temperature": 0, "max_tokens": 2000, "messages": [
            {"role": "user", "content": [
                {"type": "image_url", "image_url": {"url": data_url(im)}},
                {"type": "text", "text": prompt}]}]},
        timeout=180)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]

# ---------------- 处理流水线 ----------------
def _day_dir():
    d = IMAGES / datetime.date.today().strftime("%Y%m%d")
    d.mkdir(parents=True, exist_ok=True)
    return d

def _rel(p: Path) -> str:
    return str(p.relative_to(DATA)).replace("\\", "/")

async def process_upload(raw: bytes, uploader: str):
    im = normalize(raw)
    batch = uuid.uuid4().hex[:12]
    day = _day_dir()
    orig_path = day / f"{batch}_orig.jpg"
    im.save(orig_path, "JPEG", quality=92)

    now = datetime.datetime.now().isoformat(timespec="seconds")
    records = []
    async with httpx.AsyncClient() as client:
        # 1) 分割
        try:
            seg = extract_json(await llm(client, CFG["seg_model"], SEG_PROMPT,
                                         enhance(im) if CFG["enhance"] else im))
            if isinstance(seg, dict): seg = [seg]
            boxes = [b for b in seg if all(isinstance(b.get(k), (int, float)) for k in ("x","y","w","h"))]
            if not boxes:
                raise ValueError("分割模型未返回有效框")
        except Exception as e:
            rid = uuid.uuid4().hex
            rec = dict(id=rid, created_at=now, uploader=uploader, batch_id=batch, seq_in_batch=0,
                       orig_path=_rel(orig_path), crop_path=None, sig_path=None,
                       fields=json.dumps({}, ensure_ascii=False), warnings=json.dumps([f"分割失败:{e}"], ensure_ascii=False),
                       weight_ok=0, weight_msg="", status="failed", model=CFG["rec_model"], error=str(e))
            _insert(rec); return [rec]

        crops = [c for c in (crop_percent(im, b, pad=2) for b in boxes) if c is not None]

        # 2) 识别(并行)
        async def recog(crop):
            return extract_json(await llm(client, CFG["rec_model"], REC_PROMPT,
                                          enhance(crop) if CFG["enhance"] else crop))
        results = await asyncio.gather(*[recog(c) for c in crops], return_exceptions=True)

        # 3) 逐单据落库
        for i, (crop, res) in enumerate(zip(crops, results), start=1):
            rid = uuid.uuid4().hex
            crop_path = day / f"{batch}_r{i}.jpg"
            crop.save(crop_path, "JPEG", quality=92)
            if isinstance(res, Exception):
                rec = dict(id=rid, created_at=now, uploader=uploader, batch_id=batch, seq_in_batch=i,
                           orig_path=_rel(orig_path), crop_path=_rel(crop_path), sig_path=None,
                           fields=json.dumps({}, ensure_ascii=False),
                           warnings=json.dumps([f"识别失败:{res}"], ensure_ascii=False),
                           weight_ok=0, weight_msg="", status="failed", model=CFG["rec_model"], error=str(res))
                _insert(rec); records.append(rec); continue

            fields = {k: res.get(k) for k in FIELDS}
            warns = validate_fields(fields)
            wok, wmsg = weight_check(fields)

            # 签名:识别附带框 -> 墨迹吸附 -> 校验;失败则专项定位一次
            sig_path = None
            sig_box = res.get("签名框")
            for attempt in range(2):
                if attempt == 1:
                    try:
                        sig_box = extract_json(await llm(client, CFG["seg_model"], SIG_PROMPT, crop))
                    except Exception:
                        break
                snapped = ink_snap(crop, sig_box) or sig_box
                sig = crop_percent(crop, snapped, pad=2) if snapped else None
                if sig is not None and sig_valid(crop, sig) is not None:
                    p = day / f"{batch}_r{i}_sig.png"
                    sig.save(p, "PNG")
                    sig_path = _rel(p)
                    break
            if sig_path is None:
                warns.append("签名定位失败,需人工框选")

            key_missing = any(not norm(fields.get(k)) for k in ("序号", "车号", "净重"))
            status = "auto_ok" if (not warns and wok and not key_missing) else "needs_review"
            rec = dict(id=rid, created_at=now, uploader=uploader, batch_id=batch, seq_in_batch=i,
                       orig_path=_rel(orig_path), crop_path=_rel(crop_path), sig_path=sig_path,
                       fields=json.dumps(fields, ensure_ascii=False),
                       warnings=json.dumps(warns, ensure_ascii=False),
                       weight_ok=wok, weight_msg=wmsg, status=status, model=CFG["rec_model"], error=None)
            _insert(rec); records.append(rec)
    return records

def _insert(rec: dict):
    with db() as c:
        c.execute("""INSERT INTO records(id,created_at,uploader,batch_id,seq_in_batch,orig_path,crop_path,
                     sig_path,fields,warnings,weight_ok,weight_msg,status,model,error)
                     VALUES(:id,:created_at,:uploader,:batch_id,:seq_in_batch,:orig_path,:crop_path,
                     :sig_path,:fields,:warnings,:weight_ok,:weight_msg,:status,:model,:error)""", rec)

def _row_out(r) -> dict:
    d = dict(r)
    d["fields"] = json.loads(d["fields"] or "{}")
    d["warnings"] = json.loads(d["warnings"] or "[]")
    for k in ("orig_path", "crop_path", "sig_path"):
        d[k] = ("/files/" + d[k]) if d[k] else None
    return d

# ---------------- Web ----------------
app = FastAPI(title="称重单采集与台账系统")
init_db()
app.mount("/files", StaticFiles(directory=DATA), name="files")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

def uploader_of(req: Request) -> str:
    # 门户网关接入点:由内部门户/网关注入用户标识头
    return req.headers.get("X-Portal-User", "匿名")

@app.get("/")
def page_capture():
    return FileResponse(BASE / "static" / "capture.html")

@app.get("/report")
def page_report():
    return FileResponse(BASE / "static" / "report.html")

@app.post("/api/upload")
async def api_upload(request: Request, photo: UploadFile = File(...)):
    if not CFG["api_key"]:
        raise HTTPException(500, "服务端未配置 LLM_API_KEY(config.json 或环境变量)")
    raw = await photo.read()
    if len(raw) > 30 * 1024 * 1024:
        raise HTTPException(413, "图片超过30MB")
    try:
        recs = await process_upload(raw, uploader_of(request))
    except Exception as e:
        raise HTTPException(500, f"处理失败:{e}")
    return {"records": [_row_out_from_dict(r) for r in recs]}

def _row_out_from_dict(rec: dict) -> dict:
    d = dict(rec)
    d["fields"] = json.loads(d["fields"] or "{}")
    d["warnings"] = json.loads(d["warnings"] or "[]")
    for k in ("orig_path", "crop_path", "sig_path"):
        d[k] = ("/files/" + d[k]) if d[k] else None
    return d

@app.get("/api/records")
def api_records(date_from: str = "", date_to: str = "", q: str = "", status: str = "", limit: int = 500):
    sql = "SELECT * FROM records WHERE 1=1"; args = []
    if date_from: sql += " AND created_at >= ?"; args.append(date_from)
    if date_to:   sql += " AND created_at <= ?"; args.append(date_to + "T23:59:59")
    if status:    sql += " AND status = ?"; args.append(status)
    if q:
        sql += " AND fields LIKE ?"; args.append(f"%{q}%")
    sql += " ORDER BY created_at DESC LIMIT ?"; args.append(min(limit, 2000))
    with db() as c:
        rows = c.execute(sql, args).fetchall()
    return {"records": [_row_out(r) for r in rows]}

@app.get("/api/records/{rid}")
def api_record(rid: str):
    with db() as c:
        r = c.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
    if not r: raise HTTPException(404, "记录不存在")
    return _row_out(r)

@app.patch("/api/records/{rid}")
def api_update(rid: str, body: dict = Body(...)):
    with db() as c:
        r = c.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
        if not r: raise HTTPException(404, "记录不存在")
        fields = json.loads(r["fields"] or "{}")
        fields.update({k: v for k, v in (body.get("fields") or {}).items() if k in FIELDS})
        warns = validate_fields(fields)
        wok, wmsg = weight_check(fields)
        c.execute("UPDATE records SET fields=?, warnings=?, weight_ok=?, weight_msg=?, status=? WHERE id=?",
                  (json.dumps(fields, ensure_ascii=False), json.dumps(warns, ensure_ascii=False),
                   wok, wmsg, "reviewed", rid))
    return api_record(rid)

@app.get("/api/export.csv")
def api_export(date_from: str = "", date_to: str = "", q: str = "", status: str = ""):
    data = api_records(date_from, date_to, q, status, limit=2000)["records"]
    cols = ["created_at", "uploader", "status", "weight_msg"] + FIELDS + ["warnings", "orig_path", "crop_path", "sig_path", "id"]
    head = ["登记时间", "上传人", "状态", "重量校验"] + FIELDS + ["校验警告", "原图", "单据图", "签名图", "记录ID"]
    def esc(v):
        v = "" if v is None else str(v)
        return '"' + v.replace('"', '""') + '"'
    lines = [",".join(head)]
    for r in data:
        row = []
        for cnam in cols:
            if cnam in FIELDS: row.append(esc(r["fields"].get(cnam)))
            elif cnam == "warnings": row.append(esc(";".join(r["warnings"])))
            else: row.append(esc(r.get(cnam)))
        lines.append(",".join(row))
    csv = "\ufeff" + "\r\n".join(lines)
    return Response(csv, media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=weighbill_ledger.csv"})

@app.get("/api/config")
def api_config():
    return {"seg_model": CFG["seg_model"], "rec_model": CFG["rec_model"],
            "base_url": CFG["base_url"], "key_set": bool(CFG["api_key"])}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
