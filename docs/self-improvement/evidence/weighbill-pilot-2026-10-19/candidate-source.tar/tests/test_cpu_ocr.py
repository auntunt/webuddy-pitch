# -*- coding: utf-8 -*-
"""无显卡识别:OCR 文字框 → 字段。输入照 2026-10-14 RapidOCR 在真实磅单上的实际输出构造(含点阵错字)。"""
from __future__ import annotations

import asyncio

from PIL import Image

from weighbill import ocr_fields as F
from weighbill.adapters.vision_cpu_ocr import CpuOcrVision
from weighbill.testing import contracts
from tests.test_workflow import F as FIELDS_OF, make, up


def box(x, y, t, w=None, h=40):
    w = w or 30 * len(t)
    return ([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], t)


def ticket(dx=0, dy=0, plate="湘EC5529", serial="GZ026101ii0064142889", tare="1ó460", trad=False):
    """一张进场单(蓝色针式打印),版式与真实单据一致:标签在左,数值在右,重量后面有 kg。"""
    t_in, t_out = ("入站時間", "出站時間") if trad else ("入站时间", "出站时间")
    rows = [box(100, 0, "中冶宝钢称重单", 420, 60), box(20, 160, "客户名"), box(230, 165, "某公司"),
            box(20, 230, "司秤员"), box(230, 220, "欧阳某", 160, 70),           # 手写签名:框高
            box(20, 300, "序号"), box(230, 305, serial, 500),
            box(20, 360, "日期"), box(230, 365, "202ó-i0-ii"),
            box(20, 420, t_in), box(230, 420, "09:36:27"), box(20, 480, t_out), box(230, 480, "09:42:34"),
            box(20, 540, "车号"), box(230, 540, plate), box(20, 600, "货名"), box(230, 605, "汽车废钢料"),
            box(20, 660, "收费"), box(600, 662, "元"),
            box(20, 720, "总重"), box(230, 722, "26390"), box(600, 725, "kg"),
            box(20, 780, "空重"), box(230, 780, tare), box(600, 785, "kg"),
            box(20, 840, "净重"), box(230, 842, "9930"), box(600, 845, "kgl")]
    return [([(x + dx, y + dy) for x, y in b], t) for b, t in rows]


def parse(rows, prefixes=("CZD",)):
    return F.parse_fields(F.items_of(*zip(*rows)), prefixes)


def test_label_value_pairs_and_dot_matrix_fixes():
    f = parse(ticket())
    assert (f["车号"], f["总重"], f["皮重"], f["净重"]) == ("湘EC5529", "26390", "16460", "9930"), "ó→6"
    assert f["序号"] == "CZD26101110064142889", "C/G、0/D 混的前缀按配置纠正,i→1"
    assert (f["日期"], f["入站时间"], f["出站时间"]) == ("2026-10-11", "09:36:27", "09:42:34")
    assert f["收费"] is None, "只印了「元」的收费格是空的,不能把下一行的总重挪上来"
    assert F.weights_consistent(f) and F.plate_looks_valid(f["车号"])


def test_prefix_fix_only_when_configured():
    assert parse(ticket(), prefixes=())["序号"] == "GZ026101110064142889", "没配前缀就不猜"


def test_traditional_labels_and_slash_for_seven():
    f = parse(ticket(trad=True, plate="湘EJ/635"))
    assert f["入站时间"] == "09:36:27" and f["车号"] == "湘EJ7635"


def test_tall_handwriting_does_not_leak_into_other_rows():
    f = parse(ticket())
    assert f["监磅员"] == "欧阳某" and f["客户名"] == "某公司"


def test_two_tickets_side_by_side_are_split():
    rows = ticket() + ticket(dx=900, plate="粤WU8593")
    groups = F.split_tickets(F.items_of(*zip(*rows)))
    assert len(groups) == 2
    plates = sorted(F.parse_fields(g)["车号"] for g in groups)
    assert plates == ["湘EC5529", "粤WU8593"]


def test_no_title_falls_back_to_whole_image_only_if_it_looks_like_a_ticket():
    body = [r for r in ticket() if "称重单" not in r[1]]
    assert len(F.split_tickets(F.items_of(*zip(*body)))) == 1
    assert F.split_tickets(F.items_of(*zip(*[box(0, 0, "随便一张照片")]))) == []


def fake_engine(rows):
    def run(im):
        return [b for b, _ in rows], [t for _, t in rows]
    return run


def test_adapter_contract_and_shapes():
    rows = ticket() + ticket(dx=900, plate="粤WU8593")
    v = CpuOcrVision(engine=fake_engine(rows), serial_prefixes=["CZD"])
    contracts.check_vision(v, Image.new("RGB", (1800, 1000), "white"))
    im = Image.new("RGB", (1800, 1000), "white")
    seg = asyncio.run(v.segment(im))
    assert len(seg) == 2 and all(0 <= b["x"] <= 100 and 0 < b["w"] <= 100 for b in seg)
    assert seg[0]["x"] + seg[0]["w"] <= seg[1]["x"] + 1, "左右两张不重叠"
    d = v.describe()
    assert d["adapter"] == "cpu_ocr" and d["gpu"] is False and d["configured"] is True


def test_signature_box_is_right_of_signer_label():
    v = CpuOcrVision(engine=fake_engine(ticket()))
    r = asyncio.run(v.recognize(Image.new("RGB", (900, 1000), "white")))
    s = r["签名框"]
    assert s and s["x"] > 10 and 15 < s["y"] < 28, "司秤员那一行、标签右边"


def test_site_in_plate_snaps_to_supplier_fleet_with_a_visible_warning(tmp_path):
    recs = [FIELDS_OF("湘EJ7635", "2026-10-11", "08:10", "08:30", "18000", "10000", "8000"),
            FIELDS_OF("湘EJ/635", "2026-10-11", "09:42", "09:50", "18100", "10000", "8100"),
            FIELDS_OF("湘EJ/635", "2026-10-11", "09:42", "09:50", "18100", "10000", "8100")]
    svc, c = make(tmp_path, recs)
    up(c, "supplier_out")
    r = up(c, "site_in").json()["records"][0]
    assert r["fields"]["车号"] == "湘EJ7635"
    assert any("按比亚迪出厂单纠正" in w and "湘EJ/635" in w for w in r["warnings"]), "改了要留痕,不能悄悄改"
    r2 = up(c, "supplier_out").json()["records"][0]
    assert r2["fields"]["车号"] == "湘EJ/635", "厂商出厂单自己不纠"


def test_ambiguous_fleet_match_is_left_alone(tmp_path):
    recs = [FIELDS_OF("湘EJ7635", "2026-10-11", "08:10", "08:30", "18000", "10000", "8000"),
            FIELDS_OF("湘EJ7636", "2026-10-11", "08:20", "08:40", "18000", "10000", "8000"),
            FIELDS_OF("湘EJ763X", "2026-10-11", "09:42", "09:50", "18100", "10000", "8100")]
    svc, c = make(tmp_path, recs)
    up(c, "supplier_out"); up(c, "supplier_out")
    r = up(c, "site_in").json()["records"][0]
    assert r["fields"]["车号"] == "湘EJ763X" and not any("纠正" in w for w in r["warnings"])


def test_ocr_traditional_province_is_normalized_not_flagged():
    f = parse(ticket(plate="粵BHQ218"))
    assert f["车号"] == "粤BHQ218"


def test_plate_must_start_with_a_province():
    """「号WU8593」形状像车牌,但首字不是省份——必须提示,不能 auto_ok(真实手机照片上漏过一次)。"""
    from weighbill.domain import validate_fields
    assert any("车号格式异常" in w for w in validate_fields({"车号": "号WU8593"}))
    assert not any("车号" in w for w in validate_fields({"车号": "粤WU8593"}))


def test_weights_keep_their_scale():
    """数据审计复现:小数点被丢掉后重量放大 10/100 倍,还能通过「总重-皮重=净重」自洽校验 → 静默错。"""
    assert [F.weight_kg(v) for v in ("17200.0", "35.40", "17200kg", "9930kgl", "26,390", "12.5吨", "1ó460")] == \
        ["17200", "35400", "17200", "9930", "26390", "12500", "16460"]
