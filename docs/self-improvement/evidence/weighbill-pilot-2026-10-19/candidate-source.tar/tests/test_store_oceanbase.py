# -*- coding: utf-8 -*-
"""OceanBase(MySQL 模式)台账存储:对真实的库跑。默认跳过;本机起一个再跑:
    docker run -d -p 12881:2881 -e MODE=MINI -e OB_TENANT_PASSWORD=… -e OB_DATABASE=weighbill oceanbase/oceanbase-ce
    WB_OB=127.0.0.1:12881:root@test:<密码> pytest tests/test_store_oceanbase.py
"""
from __future__ import annotations

import asyncio, itertools, os, threading, uuid

import pytest

from weighbill.testing import contracts

pytestmark = pytest.mark.skipif(not os.environ.get("WB_OB"), reason="没配 WB_OB(真实 OceanBase)")


def cfg():
    host, port, user, pw = os.environ["WB_OB"].split(":", 3)
    return host, int(port), user, pw


@pytest.fixture
def db():
    """每个用例一个新库,用完删掉。"""
    import pymysql
    host, port, user, pw = cfg()
    name = "wbt_" + uuid.uuid4().hex[:10]
    c = pymysql.connect(host=host, port=port, user=user, password=pw); c.cursor().execute(f"CREATE DATABASE {name}"); c.close()
    yield name
    c = pymysql.connect(host=host, port=port, user=user, password=pw); c.cursor().execute(f"DROP DATABASE {name}"); c.close()


def store(name):
    from weighbill.adapters.store_oceanbase import OceanBaseRecordStore
    host, port, user, pw = cfg()
    return OceanBaseRecordStore(host, port, user, pw, name)


def test_store_contract(db):
    n = itertools.count()
    names = []
    def fresh():
        import pymysql
        host, port, user, pw = cfg()
        nm = f"{db}_{next(n)}"; names.append(nm)
        c = pymysql.connect(host=host, port=port, user=user, password=pw); c.cursor().execute(f"CREATE DATABASE {nm}"); c.close()
        return store(nm)
    try:
        contracts.check_record_store(fresh)
    finally:
        import pymysql
        host, port, user, pw = cfg()
        c = pymysql.connect(host=host, port=port, user=user, password=pw)
        for nm in names:
            c.cursor().execute(f"DROP DATABASE {nm}")
        c.close()


def test_ref_numbers_under_concurrency(db):
    """多台节点、多线程同时发号:不重、不跳。"""
    stores = [store(db) for _ in range(4)]
    got, lock = [], threading.Lock()
    def work(s):
        for _ in range(25):
            n = s.next_ref("RK-20261014")
            with lock:
                got.append(n)
    ts = [threading.Thread(target=work, args=(s,)) for s in stores]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert sorted(got) == list(range(1, 101))


def _settings(db, tmp_path, **kw):
    from weighbill.config import Settings
    from tests.fixtures import CUSTOMER_NAMING
    host, port, user, pw = cfg()
    return Settings(api_key="k", data_dir=str(tmp_path), record_store="oceanbase", db_host=host, db_port=port,
                    db_user=user, db_password=pw, db_name=db, **{**CUSTOMER_NAMING, **kw})


def test_two_servers_on_one_oceanbase(db, tmp_path):
    """两台应用节点共用一个 OceanBase:修改不覆盖、编号不重、阈值一致、日期筛选走 biz_date。"""
    from weighbill.adapters.vision_scripted import ScriptedVision
    from weighbill.bootstrap import build_service
    from weighbill.ports import RecordQuery
    from weighbill.service import Conflict
    from tests.fixtures import photo
    from tests.test_workflow import BOX, F
    recs = [F(f"粤B{i}", "2026-10-10", "08:00", "08:10", str(11000 + i), "10000", str(1000 + i), sn=f"GZD2610100000{i:04d}")
            for i in range(4)]
    a = build_service(_settings(db, tmp_path / "a"), vision=ScriptedVision(seg=[BOX] * 2, rec=recs[0::2], sig=[None] * 2))
    b = build_service(_settings(db, tmp_path / "b"), vision=ScriptedVision(seg=[BOX] * 2, rec=recs[1::2], sig=[None] * 2))
    refs = []
    for s in (a, b, a, b):
        refs.append(asyncio.run(s.ingest(photo(1), "现场", doc_type="site_in"))[0].ref_no)
    assert len(set(refs)) == 4
    rid = a.query(RecordQuery(limit=None))[0].id
    stale = a.store.get(rid)
    b.review(rid, {"备注": "B 改的"}, "审核员乙")
    from weighbill.ports import StaleRecord
    stale.fields = dict(stale.fields, 备注="A 拿旧的改")
    with pytest.raises(StaleRecord):
        a.store.update(stale)
    assert a.get(rid).fields["备注"] == "B 改的"
    a.set_thresholds({"diff_alert_kg": 77}, "审核员甲", True)
    assert b.thresholds()["diff_alert_kg"] == 77
    assert len(b.query(RecordQuery(ticket_from="2026-10-10", ticket_to="2026-10-10", limit=None))) == 4
    assert len(b.query(RecordQuery(ticket_from="2026-10-11", limit=None))) == 0
    assert [h["action"] for h in b.history(rid)][-1] == "修改"


def test_upload_survives_database_outage(db, tmp_path):
    """库挂了照样收照片,恢复后补登记一条。"""
    from fastapi.testclient import TestClient
    from weighbill.adapters.vision_scripted import ScriptedVision
    from weighbill.bootstrap import build_service
    from weighbill.http_api import create_app
    from tests.fixtures import photo
    from tests.test_workflow import BOX, F
    t = F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")
    svc = build_service(_settings(db, tmp_path), vision=ScriptedVision(seg=[BOX] * 2, rec=[t, t], sig=[None] * 2))
    c = TestClient(create_app(svc))
    real = svc.store._kw["port"]
    svc.store._kw["port"] = 1; svc.store._local.conn = None        # 指到连不上的地方 = 库挂了
    r = c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
               data={"doc_type": "site_in", "upload_id": "ob-outage-1"}, headers={"X-Portal-User": "zs"})
    assert r.status_code == 202
    svc.store._kw["port"] = real; svc.store._local.conn = None
    svc.spool.update("ob-outage-1", next_at="2000-01-01T00:00:00")
    assert asyncio.run(svc.drain_spool()) == 1
    from weighbill.ports import RecordQuery
    assert len(svc.query(RecordQuery(limit=None))) == 1


def test_reconnect_keeps_transactions(db):
    """断线重连后的会话也必须关着自动提交(驱动自己重连会悄悄打开,并发发号就重号)。"""
    s = store(db)
    s.next_ref("X")
    s._local.conn.close()                        # 模拟连接被网络掐断
    s.next_ref("X")
    with s._conn().cursor() as cur:
        cur.execute("SELECT @@autocommit AS a")
        assert int(cur.fetchone()["a"]) == 0


def test_named_lock_excludes_across_servers(db):
    a, b = store(db), store(db)
    order, held = [], threading.Event()
    def first():
        with a.named_lock("dedupe:site_in"):
            held.set(); order.append("a-in"); import time; time.sleep(0.6); order.append("a-out")
    t = threading.Thread(target=first); t.start(); held.wait()
    with b.named_lock("dedupe:site_in"):
        order.append("b-in")
    t.join()
    assert order == ["a-in", "a-out", "b-in"], order
    with b.named_lock("dedupe:supplier_out"):            # 不同名的锁互不影响
        pass


def test_cross_server_dedupe_on_oceanbase(db, tmp_path):
    import tests.test_cross_node_dedupe as X
    mk = lambda sub: X.build_service(_settings(db, tmp_path / sub), vision=X.ScriptedVision(seg=[X.BOX], rec=[dict(X.TICKET)], sig=[None]))
    a, b = mk("a"), mk("b")
    real = a.store.insert
    import time
    a.store.insert = lambda rec: (time.sleep(0.8), real(rec))[1]
    out = {}
    ta = threading.Thread(target=lambda: out.setdefault("a", asyncio.run(a.ingest_detailed(X.photo(1), "现场甲", "site_in"))))
    tb = threading.Thread(target=lambda: out.setdefault("b", asyncio.run(b.ingest_detailed(X.photo(1), "现场甲", "site_in"))))
    ta.start(); time.sleep(0.3); tb.start(); ta.join(); tb.join()
    from weighbill.ports import RecordQuery
    assert len(a.store.query(RecordQuery(limit=None))) == 1 and out["b"][0][1]
