# -*- coding: utf-8 -*-
"""每日核对:主动找「悄悄丢了」的——图不在了、处理完却没登记、卡在暂存区、缺编号。"""
from __future__ import annotations

import asyncio, datetime as dt

from weighbill import cli
from tests.test_spool import H, T, count, make, send


def lose_image(svc, key):
    """模拟存储里的图没了(本地盘或对象存储都行)。"""
    if hasattr(svc.blobs, "s3"):
        svc.blobs.s3.delete_object(Bucket=svc.blobs.bucket, Key=key)
        if svc.blobs.cache_dir:                                  # 本机读缓存也清掉,否则会从缓存读到
            for f in svc.blobs.cache_dir.iterdir():
                f.unlink()
    else:
        (svc.settings.data_path / key).unlink()


def lose_record(svc, rid):
    """模拟库里丢了一条(比如按备份回退了)。"""
    if hasattr(svc.store, "_run"):
        svc.store._run(lambda cur: cur.execute("DELETE FROM records WHERE id=%s", (rid,)))
    else:
        import sqlite3
        with sqlite3.connect(svc.settings.data_path / "ledger.db") as con:
            con.execute("DELETE FROM records WHERE id=?", (rid,))


def test_clean_system_verifies_ok(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    send(c, "verify-0001")
    r = svc.verify()
    assert r["ok"] and r["records"] == 1


def test_missing_image_is_reported(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    rec = send(c, "verify-0002").json()["records"][0]
    lose_image(svc, rec["crop_path"][len("/files/"):])                         # 存储里的图没了
    r = svc.verify()
    assert not r["ok"] and r["missing_images"][0]["ref_no"] == rec["ref_no"]


def test_lost_registration_is_found_and_reregistered(tmp_path):
    """暂存区说处理完了,库里却没有(比如库按备份回退了):核对发现,--fix 用暂存区里的照片重新登记。"""
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")] * 2)
    rec = send(c, "verify-0003").json()["records"][0]
    lose_record(svc, rec["id"])                                                   # 模拟库丢了这条
    r = svc.verify(fix=True)
    assert r["lost_registrations"][0]["upload_id"] == "verify-0003"
    assert svc.spool.get("verify-0003")["status"] == "received"
    asyncio.run(svc.drain_spool())
    assert count(svc) == 1 and svc.verify()["ok"], "重新登记回来了"


def test_stuck_upload_is_reported(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    svc.store.insert = lambda rec: (_ for _ in ()).throw(ConnectionError("库连不上"))
    send(c, "verify-0004")
    svc.clock = lambda: dt.datetime.now() + dt.timedelta(hours=2)
    r = svc.verify()
    assert r["stuck_uploads"][0]["upload_id"] == "verify-0004" and "库连不上" in r["stuck_uploads"][0]["last_error"]


def test_cli_exit_code(tmp_path, monkeypatch, capsys):
    import weighbill.bootstrap as bootstrap
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    rec = send(c, "verify-0005").json()["records"][0]
    monkeypatch.setattr(bootstrap, "build_service", lambda *a, **k: svc)
    monkeypatch.setattr(cli, "build_service", lambda *a, **k: svc, raising=False)
    assert cli.main(["verify"]) == 0
    lose_image(svc, rec["crop_path"][len("/files/"):])
    assert cli.main(["verify"]) == 1
