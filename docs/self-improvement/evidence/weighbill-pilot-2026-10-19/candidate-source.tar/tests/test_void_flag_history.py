# -*- coding: utf-8 -*-
"""作废、有疑问、修改记录、现场找回没提交的单(业务审计 2026-10-14)。"""
from __future__ import annotations

from tests.fixtures import photo
from tests.test_workflow import F, make, up, up_confirmed

H = {"X-Portal-User": "rong"}


def T(plate, net, sn):
    return F(plate, "2026-10-10", "08:00", "08:10", str(10000 + net), "10000", str(net), sn=sn)


def test_void_removes_from_totals_and_lists_but_keeps_number(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001"), T("粤B1", 1000, "GZD26101000000002")])
    a = up_confirmed(c, "supplier_out"); b = up_confirmed(c, "site_in")
    assert c.get("/api/v1/stats").json()["kinds"]["site_in"]["net"] == 1000
    assert c.post(f"/api/v1/records/{b['id']}/void", json={}, headers=H).status_code == 422, "要写原因"
    v = c.post(f"/api/v1/records/{b['id']}/void", json={"reason": "拍错了"}, headers=H).json()
    assert v["voided_by"] == "rong" and v["ref_no"] == b["ref_no"]
    assert c.get("/api/v1/stats").json()["kinds"]["site_in"]["net"] == 0, "作废的不进汇总"
    assert c.get("/api/v1/reconciliation").json()["days"][0]["site_net"] == 0, "不进磅差"
    assert [r["id"] for r in c.get("/api/v1/records?doc_type=site_in").json()["records"]] == []
    assert [r["id"] for r in c.get("/api/v1/records?doc_type=site_in&voided=only").json()["records"]] == [b["id"]]
    assert c.post("/api/v1/records/approve", json={"ids": [b["id"]]}, headers=H).json()["skipped"][0]["reason"] == "已作废"
    c.post(f"/api/v1/records/{b['id']}/restore", headers=H)
    assert c.get("/api/v1/stats").json()["kinds"]["site_in"]["net"] == 1000
    acts = [h["action"] for h in c.get(f"/api/v1/records/{b['id']}/history").json()["history"]]
    assert acts[-2:] == ["作废", "恢复"]


def test_only_reviewers_void_submitted_records(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")], reviewers=["rong"])
    r = up_confirmed(c, "site_in", user="zhangsan")
    assert c.post(f"/api/v1/records/{r['id']}/void", json={"reason": "x"}, headers={"X-Portal-User": "zhangsan"}).status_code == 403


def test_history_records_old_and_new_values(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    r = up(c, "site_in").json()["records"][0]
    c.patch(f"/api/v1/records/{r['id']}", json={"fields": {"车号": "粤B7"}}, headers=H)
    h = c.get(f"/api/v1/records/{r['id']}/history").json()["history"]
    assert h[-1]["actor"] == "rong" and h[-1]["detail"]["changes"] == {"车号": ["粤B1", "粤B7"]}


def test_flag_is_a_separate_tab(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    r = up_confirmed(c, "site_in")
    c.post(f"/api/v1/records/{r['id']}/flag", json={"note": "纸单找不到"}, headers=H)
    got = c.get("/api/v1/records?flagged=true").json()["records"]
    assert [x["flag_note"] for x in got] == ["纸单找不到"] and got[0]["stage"] == "submitted", "不改审核状态"


def test_capture_link_finds_its_unsubmitted_and_can_fix_type_or_discard(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001"), T("粤B2", 2000, "GZD26101000000002")],
                  capture_links={"tok": {"label": "现场"}, "other": {"label": "别处"}})
    send = lambda: c.post("/api/v1/capture/tok/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
                          data={"name": "张三", "doc_type": "site_in"}).json()["records"][0]
    a, b = send(), send()
    lst = c.get("/api/v1/capture/tok/records").json()["records"]
    assert {x["id"] for x in lst} == {a["id"], b["id"]} and all(x["stage"] == "draft" for x in lst)
    assert c.get("/api/v1/capture/other/records").json()["records"] == [], "别的链接看不到"
    s = c.post(f"/api/v1/capture/tok/records/{a['id']}/submit", json={"doc_type": "supplier_out"}).json()
    assert (s["doc_type"], s["stage"]) == ("supplier_out", "submitted"), "现场能当场改单据类型"
    d = c.post(f"/api/v1/capture/tok/records/{b['id']}/void", json={}).json()
    assert d["voided_at"] and d["void_reason"] == "现场丢弃"
    assert c.post(f"/api/v1/capture/tok/records/{a['id']}/void", json={}).status_code == 403, "提交了的现场不能丢"


def test_reshoot_of_own_draft_comes_back_editable(tmp_path):
    t = T("粤B1", 1000, "GZD26101000000001")
    svc, c = make(tmp_path, [t, dict(t)], capture_links={"tok": {"label": "现场"}})
    send = lambda: c.post("/api/v1/capture/tok/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
                          data={"name": "张三"}).json()["records"][0]
    first, again = send(), send()
    assert again["duplicate"] and again["id"] == first["id"] and "crop_path" in again and again["stage"] == "draft"
