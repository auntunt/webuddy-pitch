from bench.cpu_ocr_acceptance import equivalent

def test_ledger_minute_precision_does_not_mark_recognized_seconds_wrong():
    assert equivalent('入站时间','2026-10-11 08:30:20','2026-10-11 8:30')
    assert not equivalent('入站时间','2026-10-10 08:30:20','2026-10-11 8:30')
    assert not equivalent('入站时间','2026-10-11 08:31:20','2026-10-11 8:30')
    assert not equivalent('入站时间','2026-10-11 08:30:21','2026-10-11 8:30:20')
    assert not equivalent('入站时间',None,'2026-10-11 8:30')

def test_identifier_and_numeric_comparison():
    assert equivalent('净重','17,200','17200')
    assert not equivalent('净重','1720','17200')
    assert equivalent('车号','粵B·12345','粤B12345')
    assert not equivalent('序号','CZD00001234','CZD00001235')

def test_cpu_missing_business_date_requires_review(tmp_path):
    from tests.test_workflow import make, F, up
    svc,c=make(tmp_path,[F('湘A12345',None,'08:00','08:10','18000','10000','8000')])
    svc.vision.describe=lambda:{'adapter':'cpu_ocr','configured':True}
    result=up(c).json()['records'][0]
    assert result['status']=='needs_review'
    assert result['fields'].get('日期') is None
    assert any('磅单日期未识别' in w for w in result['warnings'])
