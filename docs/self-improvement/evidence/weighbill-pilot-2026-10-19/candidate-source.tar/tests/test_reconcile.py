# -*- coding: utf-8 -*-
"""磅差配对。场景取自 2026-10-12 会议原话。"""
from __future__ import annotations

import itertools

from weighbill.domain import FIELDS, Record
from weighbill.reconcile import reconcile

_ids = itertools.count(1)


def rec(plate, date, tin, tout, net, status="auto_ok", **kw):
    f = {k: None for k in FIELDS} | {"车号": plate, "日期": date, "入站时间": tin, "出站时间": tout, "净重": net}
    i = next(_ids)
    return Record(id=f"r{i}", created_at=f"2026-10-12T00:00:{i:02d}", uploader="t", batch_id="b", seq_in_batch=1,
                  orig_key=None, crop_key=None, sig_key=None, fields=f, status=status, **kw)


def pairs(res):
    return [(x["supplier"].id, x["site"].id) for d in res["days"] for x in d["pairs"]]


def test_three_trips_same_day_pair_in_order():
    """「他今天过了三车磅,加工厂里面也对应三车……第一趟对第一趟,第二趟对第二趟」"""
    b1, b2, b3 = rec("粤B12345", "2026-10-10", "08:20", "08:30", "20000"), \
        rec("粤B12345", "2026-10-10", "12:50", "13:00", "19000"), rec("粤B12345", "2026-10-10", "16:40", "16:50", "21000")
    p3, p1, p2 = rec("粤B12345", "2026-10-10", "17:45", "17:55", "20800"), \
        rec("粤B12345", "2026-10-10", "09:42", "09:50", "19900"), rec("粤B12345", "2026-10-10", "14:52", "15:00", "18950")
    r = reconcile([b3, b1, b2], [p3, p1, p2])          # 输入顺序打乱
    assert pairs(r) == [(b1.id, p1.id), (b2.id, p2.id), (b3.id, p3.id)]
    d = r["days"][0]
    assert (d["trucks"], d["supplier_net"], d["site_net"], d["diff"]) == (3, 60000, 59650, -350)


def test_two_hour_gap_is_still_a_pair():
    """「01:09 过了磅……到加工厂中间差了快两个小时,要等出门审批」"""
    b, p = rec("湘L48284", "2026-10-10", "01:00", "01:09", "30160"), rec("湘L48284", "2026-10-10", "03:05", "03:20", "30100")
    r = reconcile([b], [p])
    x = r["days"][0]["pairs"][0]
    assert x["gap_min"] == 116 and not x["gap_alert"], "时间差只作信息列,默认不标红"
    assert reconcile([b], [p], transit_alert_minutes=30)["days"][0]["pairs"][0]["gap_alert"]


def test_crosses_midnight():
    b, p = rec("粤B1", "2026-10-10", "23:20", "23:30", "10000"), rec("粤B1", "2026-10-11", "01:10", "01:20", "9990")
    r = reconcile([b], [p])
    by = {d["date"]: d for d in r["days"]}
    assert pairs(r) == [(b.id, p.id)] and len(by["2026-10-10"]["pairs"]) == 1, "配对按比亚迪出厂那天归档"
    assert (by["2026-10-10"]["supplier_net"], by["2026-10-11"]["site_net"]) == (10000, 9990), \
        "日合计按各自磅单日期(客户台账口径),所以跨零点的车在两天的合计里各占一边"


def test_unmatched_on_both_sides_are_listed():
    b_ok, b_lost = rec("粤B1", "2026-10-10", "08:00", "08:10", "10000"), rec("粤B2", "2026-10-10", "09:00", "09:10", "12000")
    p_ok, p_extra = rec("粤B1", "2026-10-10", "08:40", "08:50", "9990"), rec("粤B9", "2026-10-10", "10:00", "10:10", "8000")
    d = reconcile([b_ok, b_lost], [p_ok, p_extra])["days"][0]
    assert [x.id for x in d["unmatched_supplier"]] == [b_lost.id] and [x.id for x in d["unmatched_site"]] == [p_extra.id]
    assert d["unmatched"] == 2 and d["trucks"] == 1
    assert (d["supplier_count"], d["supplier_net"], d["site_count"], d["site_net"]) == (2, 22000, 2, 17990), \
        "日合计 = 当天该侧全部车(与客户《磅差对比表》同口径),没配上的另外单列"


def test_plant_arrival_before_byd_departure_is_not_a_pair():
    b, p = rec("粤B1", "2026-10-10", "10:00", "10:10", "10000"), rec("粤B1", "2026-10-10", "08:00", "08:10", "9990")
    d = reconcile([b], [p])["days"]
    assert not any(x["pairs"] for x in d), "到达早于出厂不能配(容差 15 分钟)"


def test_plate_separator_and_case_do_not_block_pairing():
    b, p = rec("粤B·12345", "2026-10-10", "08:00", "08:10", "10000"), rec("粤b12345", "2026-10-10", "08:40", "08:50", "9990")
    assert pairs(reconcile([b], [p])) == [(b.id, p.id)]


def test_different_plates_never_cross():
    b, p = rec("粤B1", "2026-10-10", "08:00", "08:10", "10000"), rec("粤B2", "2026-10-10", "08:40", "08:50", "9990")
    assert pairs(reconcile([b], [p])) == []


def test_failed_records_are_ignored():
    b = rec("粤B1", "2026-10-10", "08:00", "08:10", "10000")
    p_bad, p_ok = rec("粤B1", "2026-10-10", "08:30", "08:35", "1", status="failed"), rec("粤B1", "2026-10-10", "08:40", "08:50", "9990")
    assert pairs(reconcile([b], [p_bad, p_ok])) == [(b.id, p_ok.id)]


def test_diff_alert_threshold():
    """「比亚迪出来 15 吨,到了我们加工厂 12 吨,差了 3 吨」"""
    b, p = rec("粤B1", "2026-10-10", "08:00", "08:10", "15000"), rec("粤B1", "2026-10-10", "08:40", "08:50", "12000")
    x = reconcile([b], [p])["days"][0]["pairs"][0]
    assert (x["diff"], round(x["diff_pct"], 1), x["diff_alert"]) == (-3000, -20.0, True), "磅差 = 加工厂 − 比亚迪,少了为负"
    b2, p2 = rec("粤B2", "2026-10-10", "08:00", "08:10", "15000"), rec("粤B2", "2026-10-10", "08:40", "08:50", "14900")
    assert not reconcile([b2], [p2])["days"][0]["pairs"][0]["diff_alert"], "0.67% 未超 1%"


def test_missing_times_fall_back_to_same_day_order():
    b = rec("粤B1", "2026-10-10", None, None, "10000")
    p = rec("粤B1", "2026-10-10", None, None, "9990")
    assert pairs(reconcile([b], [p])) == [(b.id, p.id)]


def test_byd_overnight_times_carry_their_own_dates():
    """比亚迪真实磅单:前一天傍晚入站、当天早上出站;时间字段自带日期,配对用它自己的日期。"""
    b = rec("湘ED4989", "2026-10-11", "2026-10-10 17:21", "2026-10-11 08:30", "10620")
    p = rec("湘ED4989", "2026-10-11", "09:36", "09:42", "10810")
    r = reconcile([b], [p])
    x = r["days"][0]["pairs"][0]
    assert (x["gap_min"], x["diff"]) == (66, 190), "08:30 出站 → 09:36 入站;加工厂更重则磅差为正"


def test_daily_totals_compare_gross_tare_and_net():
    """客户的磅差对比表三项都比:总重、空重、净重。"""
    def r2(plate, date, tin, tout, g, t, n, **kw):
        x = rec(plate, date, tin, tout, n, **kw); x.fields.update({"总重": g, "皮重": t}); return x
    b = r2("粤B1", "2026-10-11", "07:00", "08:00", "27200", "16580", "10620")
    p = r2("粤B1", "2026-10-11", "09:00", "09:10", "27390", "16580", "10810")
    d = reconcile([b], [p])["days"][0]
    assert (d["diff_gross"], d["diff_tare"], d["diff"]) == (190, 0, 190)
    assert round(d["diff_pct"], 4) == round(190 / 10620 * 100, 4), "比例以比亚迪净重为基准"


def test_traditional_province_character_still_pairs():
    """客户台账真实情况:入库表里录成了繁体「粵BEX561」。"""
    b = rec("粤BEX561", "2026-10-11", "2026-10-10 17:09", "2026-10-11 10:03", "22610")
    p = rec("粵BEX561", "2026-10-11", "11:32", "11:41", "22570")
    assert pairs(reconcile([b], [p])) == [(b.id, p.id)]


def test_a_missing_ticket_leaves_a_gap_instead_of_shifting_the_pairs():
    """少传一张入库单时,不能把第 1 趟出厂配到第 2 趟的入库上(真实数据里出现过 +14650 kg 的假磅差)。
    物理约束:第 k 趟到达加工厂,不可能晚于同一辆车第 k+1 趟从比亚迪出厂。"""
    b1 = rec("粤BEX561", "2026-10-11", "2026-10-10 17:09", "2026-10-11 10:03", "22610")
    b2 = rec("粤BEX561", "2026-10-11", "2026-10-11 13:20", "2026-10-11 15:16", "7990")
    p2 = rec("粤BEX561", "2026-10-11", "16:24", "16:31", "7960")          # 第 1 趟的入库单没传
    d = reconcile([b1, b2], [p2])["days"][0]
    assert pairs({"days": [d]}) == [(b2.id, p2.id)], "第 2 趟配第 2 趟"
    assert [r.id for r in d["unmatched_supplier"]] == [b1.id], "第 1 趟标成没配上,而不是配错"


def test_kg_floor_mutes_small_truck_noise():
    """8 吨小车差 90 kg 就过 1%;设了 kg 下限后,两个条件都超才标红。"""
    b, p = rec("粤B1", "2026-10-10", "08:00", "08:10", "8000"), rec("粤B1", "2026-10-10", "08:40", "08:50", "8090")
    assert reconcile([b], [p])["days"][0]["pairs"][0]["diff_alert"], "只看百分比:1.125% 超 1%"
    assert not reconcile([b], [p], diff_alert_kg=100)["days"][0]["pairs"][0]["diff_alert"], "90 kg 没超 100 kg 下限"
    b2, p2 = rec("粤B2", "2026-10-10", "08:00", "08:10", "8000"), rec("粤B2", "2026-10-10", "08:40", "08:50", "7850")
    assert reconcile([b2], [p2], diff_alert_kg=100)["days"][0]["pairs"][0]["diff_alert"], "−150 kg、−1.9% 两项都超"
