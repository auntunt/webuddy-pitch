# -*- coding: utf-8 -*-
"""单据只分三种角色,名字全在配置里(2026-10-14 用户定:「厂商:比亚迪什么的,我们不要写死」)。"""
from __future__ import annotations

import io, json, re, sqlite3
from pathlib import Path

from fastapi.testclient import TestClient
from openpyxl import load_workbook

from weighbill.adapters.store_sqlite import SQLiteRecordStore
from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.http_api import create_app
from tests.fixtures import CUSTOMER_NAMING
from tests.test_workflow import F, make, up

PKG = Path(__file__).resolve().parent.parent / "weighbill"


def test_product_code_names_no_customer():
    """客户的厂商名、场名、客户名、单据叫法只能出现在配置里,产品代码(含页面)一个都不许有。"""
    c = CUSTOMER_NAMING
    words = {c["supplier_name"], c["site_name"], *c["customers"], *c["doc_labels"].values(), "加工厂", "原材料", "产成品"}
    hits = [(p.relative_to(PKG.parent), w) for p in PKG.rglob("*") if p.suffix in (".py", ".html", ".js")
            for w in words if w in p.read_text("utf-8")]
    assert hits == []


def test_neutral_defaults_without_config(tmp_path):
    svc, c = make(tmp_path, [], **{k: Settings.__dataclass_fields__[k].default_factory()
                                   if callable(getattr(Settings.__dataclass_fields__[k], "default_factory", None))
                                   else Settings.__dataclass_fields__[k].default for k in CUSTOMER_NAMING})
    j = c.get("/api/v1/schema").json()
    assert (j["supplier_name"], j["site_name"], j["customers"]) == ("厂商", "本场", [])
    assert [v["label"] for v in j["doc_types"].values()] == ["厂商出厂", "本场进场", "本场出场"]


def test_names_come_from_config(tmp_path):
    svc, c = make(tmp_path, [], supplier_name="甲钢厂", site_name="乙基地", doc_labels={}, doc_titles={},
                  summary_titles={}, summary_sheets={}, customers=["丙公司"])
    j = c.get("/api/v1/schema").json()
    assert [v["label"] for v in j["doc_types"].values()] == ["甲钢厂出厂", "乙基地进场", "乙基地出场"]
    assert j["customers"] == ["丙公司"]
    wb = load_workbook(io.BytesIO(c.get("/api/v1/export.xlsx?kind=reconciliation").content))
    assert wb["月度磅差汇总表"]["A1"].value == "甲钢厂&乙基地月度磅差汇总表"


def test_capture_link_page_gets_names_without_login(tmp_path):
    svc, c = make(tmp_path, [], capture_links={"tok": {"label": "现场", "doc_type": "byd_out"}})
    j = c.get("/api/v1/capture/tok").json()
    assert j["doc_type"] == "supplier_out", "老配置里的旧键照认"
    assert j["doc_labels"]["supplier_out"] == CUSTOMER_NAMING["doc_labels"]["supplier_out"] and j["customers"]


def test_legacy_doc_type_keys_still_accepted(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:10", "08:30", "18000", "10000", "8000")])
    r = up(c, "byd_out").json()["records"][0]
    assert r["doc_type"] == "supplier_out"
    assert [x["id"] for x in c.get("/api/v1/records?doc_type=byd_out").json()["records"]] == [r["id"]]
    assert c.get("/api/v1/export.xlsx?kind=byd_out").status_code == 200


def test_old_database_is_migrated_in_place(tmp_path):
    db = tmp_path / "ledger.db"
    SQLiteRecordStore(db)                                   # 建好表
    with sqlite3.connect(db) as con:
        for i, old in enumerate(("byd_out", "plant_in", "product_out")):
            con.execute("INSERT INTO records(id, created_at, uploader, batch_id, seq_in_batch, fields, warnings, "
                        "weight_ok, weight_msg, status, doc_type) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (f"r{i}", "2026-10-11T08:00:00", "t", "b", 1, "{}", "[]", 0, "", "auto_ok", old))
    store = SQLiteRecordStore(db)                           # 再打开 = 升级
    with sqlite3.connect(db) as con:
        assert sorted(r[0] for r in con.execute("select doc_type from records")) == ["site_in", "site_out", "supplier_out"]
