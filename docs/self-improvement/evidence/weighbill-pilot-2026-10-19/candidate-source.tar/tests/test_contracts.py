# -*- coding: utf-8 -*-
"""内置适配器过契约套件。未来的新适配器照抄这里的写法接入。"""
from __future__ import annotations

import asyncio, hashlib, hmac, json, threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import httpx
import pytest

from weighbill import ports
from weighbill.adapters.blob_local import LocalBlobStore
from weighbill.adapters.events import JsonlEventSink, NullEventSink, WebhookEventSink
from weighbill.adapters.identity import HeaderIdentity
from weighbill.adapters.store_sqlite import SQLiteRecordStore
from weighbill.adapters.vision_openai import OpenAICompatibleVision
from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.prompts import REC_PROMPT, SEG_PROMPT, SIG_PROMPT
from weighbill.testing import contracts
from tests.fixtures import receipt


def test_sqlite_store(tmp_path):
    n = iter(range(100))
    contracts.check_record_store(lambda: SQLiteRecordStore(tmp_path / f"{next(n)}.db"))


def test_sqlite_store_opens_v01_database(tmp_path):
    """0.1 版的库直接能用:缺的列被补上,旧行照常读出。"""
    import sqlite3
    db = tmp_path / "ledger.db"
    with sqlite3.connect(db) as c:
        c.execute("""CREATE TABLE records(id TEXT PRIMARY KEY, created_at TEXT, uploader TEXT, batch_id TEXT,
            seq_in_batch INTEGER, orig_path TEXT, crop_path TEXT, sig_path TEXT, fields TEXT, warnings TEXT,
            weight_ok INTEGER, weight_msg TEXT, status TEXT, model TEXT, error TEXT)""")
        c.execute("INSERT INTO records VALUES('old1','2026-09-22T16:25:01','匿名','b',1,'images/a_orig.jpg',"
                  "'images/a_r1.jpg',NULL,'{\"序号\":\"1\"}','[]',1,'ok','auto_ok','qwen',NULL)")
    s = SQLiteRecordStore(db)
    r = s.get("old1")
    assert r.fields == {"序号": "1"} and r.seg_model is None and r.reviewed_by is None


def test_local_blob_store(tmp_path):
    n = iter(range(100))
    contracts.check_blob_store(lambda: LocalBlobStore(tmp_path / str(next(n))))


def test_header_identity():
    contracts.check_identity(lambda: HeaderIdentity())


def test_identity_leaves_real_latin1_alone():
    assert HeaderIdentity().resolve({"X-Portal-User": "José"}) == "José"


def test_null_sink():
    contracts.check_event_sink(NullEventSink)


def test_jsonl_sink(tmp_path):
    path = tmp_path / "ev.jsonl"
    contracts.check_event_sink(lambda: JsonlEventSink(path),
                               read_back=lambda s: [json.loads(l) for l in path.read_text("utf-8").splitlines()])


class _Hook(BaseHTTPRequestHandler):
    got: list = []
    def do_POST(self):
        body = self.rfile.read(int(self.headers["Content-Length"]))
        _Hook.got.append((dict(self.headers), body))
        self.send_response(204); self.end_headers()
    def log_message(self, *a): pass


def test_webhook_sink_delivers_signed_cloudevent(monkeypatch):
    monkeypatch.setenv("NO_PROXY", "127.0.0.1,localhost")
    monkeypatch.setenv("no_proxy", "127.0.0.1,localhost")
    srv = HTTPServer(("127.0.0.1", 0), _Hook); _Hook.got = []
    t = threading.Thread(target=srv.serve_forever, daemon=True); t.start()
    try:
        url = f"http://127.0.0.1:{srv.server_port}/hook"
        contracts.check_event_sink(lambda: WebhookEventSink(url, secret="s3cret"),
                                   read_back=lambda s: [json.loads(b) for _, b in _Hook.got])
        headers, body = _Hook.got[-1]
        want = "sha256=" + hmac.new(b"s3cret", body, hashlib.sha256).hexdigest()
        assert headers["X-Weighbill-Signature"] == want, "签名必须是对原始请求体的 HMAC"
        assert headers["Content-Type"].startswith("application/cloudevents+json")
    finally:
        srv.shutdown()


def test_webhook_failure_raises():
    with pytest.raises(Exception):
        WebhookEventSink("http://127.0.0.1:9/nowhere", timeout=0.5).publish({"id": "x"})


def test_scripted_vision_contract():
    v = ScriptedVision(seg=[[{"x": 1, "y": 1, "w": 50, "h": 50}]], rec=[{"序号": "1"}])
    contracts.check_vision(v)
    assert isinstance(v, ports.VisionModel)


def test_openai_adapter_request_shape():
    """真适配器的出站请求:只替换传输层,验证 URL、鉴权头、模型、提示词、图片在前文字在后。"""
    seen = []
    def handler(req: httpx.Request):
        seen.append((str(req.url), req.headers.get("authorization"), json.loads(req.content)))
        return httpx.Response(200, json={"choices": [{"message": {"content": '```json\n[{"x":1,"y":2,"w":3,"h":4}]\n```'}}]})
    v = OpenAICompatibleVision("http://vllm.local/v1/", "k-123", "seg-m", "rec-m",
                               transport=httpx.MockTransport(handler))
    im = receipt()
    assert asyncio.run(v.segment(im)) == [{"x": 1, "y": 2, "w": 3, "h": 4}]
    asyncio.run(v.recognize(im)); asyncio.run(v.locate_signature(im))
    urls, auths, bodies = zip(*seen)
    assert set(urls) == {"http://vllm.local/v1/chat/completions"}
    assert set(auths) == {"Bearer k-123"}
    assert [b["model"] for b in bodies] == ["seg-m", "rec-m", "seg-m"]
    assert [b["messages"][0]["content"][1]["text"] for b in bodies] == [SEG_PROMPT, REC_PROMPT, SIG_PROMPT]
    for b in bodies:
        c = b["messages"][0]["content"]
        assert c[0]["type"] == "image_url" and c[0]["image_url"]["url"].startswith("data:image/jpeg;base64,")
        assert b["temperature"] == 0 and b["max_tokens"] == 2000
    assert "k-123" not in json.dumps(v.describe()), "describe 不得泄露密钥"


def test_openai_adapter_refuses_without_key():
    with pytest.raises(RuntimeError):
        asyncio.run(OpenAICompatibleVision("http://x", "", "a", "b").segment(receipt()))


@pytest.mark.parametrize("cls,proto", [(SQLiteRecordStore, ports.RecordStore), (LocalBlobStore, ports.BlobStore),
                                       (HeaderIdentity, ports.IdentityResolver), (JsonlEventSink, ports.EventSink),
                                       (OpenAICompatibleVision, ports.VisionModel)])
def test_builtin_adapters_satisfy_protocols(tmp_path, cls, proto):
    inst = {SQLiteRecordStore: lambda: cls(tmp_path / "a.db"), LocalBlobStore: lambda: cls(tmp_path),
            JsonlEventSink: lambda: cls(tmp_path / "e.jsonl"),
            OpenAICompatibleVision: lambda: cls("http://x", "", "a", "b")}.get(cls, cls)()
    assert isinstance(inst, proto)



def test_openai_adapter_converts_native_bbox_2d():
    """Qwen 原生角点格式 bbox_2d(0-1000)由适配器换算成百分比框;旧格式原样放行。"""
    replies = iter([
        '```json\n[{"bbox_2d": [45, 209, 496, 817], "label": "称重单"}, {"bbox_2d": [517, 213, 967, 812]}]\n```',
        '{"序号": "1", "签名框": {"bbox_2d": [350, 800, 650, 900]}}',
        '[{"bbox_2d": [100, 200, 300, 260]}]',
        '[{"x": 4, "y": 8, "w": 43, "h": 84}]',
    ])
    def handler(req):
        return httpx.Response(200, json={"choices": [{"message": {"content": next(replies)}}]})
    v = OpenAICompatibleVision("http://x/v1", "k", "s", "r", transport=httpx.MockTransport(handler))
    im = receipt()
    seg = asyncio.run(v.segment(im))
    assert seg == [{"x": 4.5, "y": 20.9, "w": 45.1, "h": 60.8}, {"x": 51.7, "y": 21.3, "w": 45.0, "h": 59.9}]
    assert asyncio.run(v.recognize(im))["签名框"] == {"x": 35.0, "y": 80.0, "w": 30.0, "h": 10.0}
    assert asyncio.run(v.locate_signature(im)) == {"x": 10.0, "y": 20.0, "w": 20.0, "h": 6.0}
    assert asyncio.run(v.segment(im)) == [{"x": 4, "y": 8, "w": 43, "h": 84}], "旧格式必须原样放行"



def test_openai_adapter_reread_weights_uses_rec_model_and_weight_prompt():
    from weighbill.prompts import WEIGHT_PROMPT
    seen = []
    def handler(req):
        seen.append(json.loads(req.content))
        return httpx.Response(200, json={"choices": [{"message": {"content": '{"总重":"1","皮重":"0","净重":"1"}'}}]})
    v = OpenAICompatibleVision("http://x/v1", "k", "seg-m", "rec-m", transport=httpx.MockTransport(handler))
    assert asyncio.run(v.reread_weights(receipt())) == {"总重": "1", "皮重": "0", "净重": "1"}
    assert seen[0]["model"] == "rec-m" and seen[0]["messages"][0]["content"][1]["text"] == WEIGHT_PROMPT
