# -*- coding: utf-8 -*-
"""多台服务器共用一个库(私有部署预案):两个互不相干的服务实例——各自的进程内锁、各自的缓存——指向同一份数据。
进程内的锁管不到另一台机器,能靠的只有库:版本号核对、库里发号、设置存库。"""
from __future__ import annotations

import json

import pytest

from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.ports import StaleRecord
from weighbill.service import Conflict
from tests.fixtures import CUSTOMER_NAMING, photo
from tests.test_workflow import F, BOX

import asyncio


def node(data, recs=()):
    s = Settings(api_key="k", data_dir=str(data), **CUSTOMER_NAMING)
    return build_service(s, vision=ScriptedVision(seg=[BOX] * len(recs), rec=list(recs), sig=[None] * len(recs)))


def T(plate, net, sn):
    return F(plate, "2026-10-10", "08:00", "08:10", str(10000 + net), "10000", str(net), sn=sn)


def test_edit_on_one_server_is_not_overwritten_by_the_other(tmp_path):
    a = node(tmp_path, [T("粤B1", 1000, "GZD26101000000001")]); b = node(tmp_path)
    rid = asyncio.run(a.ingest(photo(1), "现场", doc_type="site_in"))[0].id
    stale = a.store.get(rid)                                    # 服务器 A 读出来
    b.review(rid, {"净重": "900", "总重": "10900"}, "审核员乙")   # 服务器 B 改了
    stale.fields = dict(stale.fields, 备注="甲的修改")
    with pytest.raises(StaleRecord):
        a.store.update(stale)                                   # A 拿旧的写回去:拒绝
    assert a.get(rid).fields["净重"] == "900", "B 的修改还在"


def test_service_reports_conflict_instead_of_overwriting(tmp_path):
    a = node(tmp_path, [T("粤B1", 1000, "GZD26101000000001")]); b = node(tmp_path)
    rid = asyncio.run(a.ingest(photo(1), "现场", doc_type="site_in"))[0].id
    real_get = a.store.get

    def get_then_other_server_edits(x):
        r = real_get(x)
        a.store.get = real_get
        b.review(rid, {"净重": "900", "总重": "10900"}, "审核员乙")      # 另一台机器,A 的锁管不到
        return r
    a.store.get = get_then_other_server_edits
    res = a.approve([rid], "审核员甲", True)
    assert res["approved"] == [] and "刚被别人改过" in res["skipped"][0]["reason"]
    r = a.get(rid)
    assert (r.fields["净重"], r.stage) == ("900", "draft"), "没把别人刚改的数当成已审核"


def test_registration_numbers_unique_across_servers(tmp_path):
    recs = [T(f"粤B{i}", 1000 + i, f"GZD2610100000{i:04d}") for i in range(6)]
    a, b = node(tmp_path, recs[0::2]), node(tmp_path, recs[1::2])
    got = []
    for i in range(3):
        got += [asyncio.run(n.ingest(photo(1), "现场", doc_type="site_in"))[0].ref_no for n in (a, b)]
    assert len(set(got)) == 6 and sorted(int(x[-4:]) for x in got) == [1, 2, 3, 4, 5, 6], "两台交替发号:不重、不跳"


def test_thresholds_are_shared_and_old_file_is_migrated(tmp_path):
    (tmp_path / "thresholds.json").write_text(json.dumps({"diff_alert_pct": 2.5}), "utf-8")
    a, b = node(tmp_path), node(tmp_path)
    assert a.thresholds()["diff_alert_pct"] == 2.5, "0.5 版存在文件里的阈值导入一次"
    a.set_thresholds({"diff_alert_kg": 120}, "审核员甲", True)
    assert b.thresholds()["diff_alert_kg"] == 120, "在 A 上改的阈值,B 立刻看到(存库,不存本机文件)"


def test_export_refuses_silent_image_loss_when_storage_is_down(tmp_path):
    """完整报表不得在存储故障时悄悄省略图片。"""
    import io
    from openpyxl import load_workbook
    from weighbill.ports import RecordQuery
    a = node(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    asyncio.run(a.ingest(photo(1), "现场", doc_type="site_in"))

    def down(key):
        raise ConnectionError("对象存储连不上")
    a.blobs.open = down
    import pytest
    from weighbill.export_xlsx import ExportImageError
    with pytest.raises(ExportImageError):
        a.export_records_xlsx("site_in", RecordQuery())
    assert a.store.query(RecordQuery()), "台账仍可查询"
