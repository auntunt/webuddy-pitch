# -*- coding: utf-8 -*-
"""0.3.0 流程:现场拍 → 监磅员确认提交(实时可见、未审核)→ 审核员对照纸质磅单批量审核。"""
from __future__ import annotations

import io

from fastapi.testclient import TestClient
from openpyxl import load_workbook

from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.http_api import create_app
from tests.fixtures import CUSTOMER_NAMING, photo

BOX = [{"x": 3.8, "y": 7.7, "w": 90.0, "h": 84.5}]
SIG = {"x": 35, "y": 80, "w": 30, "h": 10}


_sn = iter(range(12345678, 99999999))


def F(plate, date, tin, tout, gross, tare, net, sn=None):
    sn = sn or f"GZD261010{next(_sn):08d}"     # 每张单默认一个新单号:同号会被当成同一张磅单(防重复登记)
    return {"客户名": "广富源", "序号": sn, "日期": date, "入站时间": tin, "出站时间": tout, "车号": plate,
            "货名": "汽车切片打包块", "收费": None, "总重": gross, "皮重": tare, "净重": net, "签名框": SIG}


def make(tmp_path, recs, **settings):
    s = Settings(api_key="k", data_dir=str(tmp_path / "d"), **{**CUSTOMER_NAMING, **settings})
    svc = build_service(s, vision=ScriptedVision(seg=[BOX] * len(recs), rec=recs, sig=[None] * len(recs)))
    return svc, TestClient(create_app(svc))


def up(c, doc_type="site_in", user="zhangsan", customer=""):
    return c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
                  data={"doc_type": doc_type, "customer": customer},
                  headers={"X-Portal-User": user})


def up_confirmed(c, doc_type="site_in", user="zhangsan", customer=""):
    """上传并由现场确认提交(进汇总和磅差的前提:待现场确认的单据不算)。返回提交后的记录。"""
    r = up(c, doc_type, user, customer).json()["records"][0]
    return c.post(f"/api/v1/records/{r['id']}/submit", json={}, headers={"X-Portal-User": user}).json()


def test_new_upload_is_draft_until_site_confirms(tmp_path):
    svc, c = make(tmp_path, [F("粤B12345", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160")])
    r = up(c).json()["records"][0]
    assert (r["stage"], r["stage_label"], r["doc_type_label"]) == ("draft", "待现场确认", "原材料入库")
    s = c.post(f"/api/v1/records/{r['id']}/submit", json={"fields": {"货名": "废钢"}},
               headers={"X-Portal-User": "zhangsan"}).json()
    assert (s["stage"], s["stage_label"], s["submitted_by"], s["fields"]["货名"]) == ("submitted", "未审核", "zhangsan", "废钢")
    assert c.get("/api/v1/records?stage=submitted").json()["count"] == 1, "提交后实时可见"


def test_legacy_upload_stays_immediately_visible(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160")])
    rec = c.post("/api/upload", files={"photo": ("a.jpg", photo(1), "image/jpeg")}).json()["records"][0]
    assert rec["stage"] == "submitted", "0.1 版页面传完就在台账里,不能因为新流程变成草稿"


def test_batch_approve_reports_each_record(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160"),
                             F("粤B2", "2026-10-10", "09:00", "09:20", "1", "1", None)], reviewers=["rong"])
    a, b = (up(c).json()["records"][0]["id"] for _ in range(2))
    c.post(f"/api/v1/records/{a}/submit", json={})
    res = c.post("/api/v1/records/approve", json={"ids": [a, b, "nope", a]}, headers={"X-Portal-User": "rong"}).json()
    assert res["approved"] == [a]
    assert {x["id"]: x["reason"] for x in res["skipped"]} == {b: "净重为空,先补录", "nope": "记录不存在"}
    ap = c.get(f"/api/v1/records/{a}").json()
    assert (ap["stage"], ap["approved_by"]) == ("approved", "rong")


def test_only_reviewers_approve_or_edit_after_submit(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160")], reviewers=["rong"])
    rid = up(c).json()["records"][0]["id"]
    c.post(f"/api/v1/records/{rid}/submit", json={}, headers={"X-Portal-User": "zhangsan"})
    assert c.post("/api/v1/records/approve", json={"ids": [rid]}, headers={"X-Portal-User": "zhangsan"}).status_code == 403
    assert c.patch(f"/api/v1/records/{rid}", json={"fields": {"净重": "1"}},
                   headers={"X-Portal-User": "zhangsan"}).status_code == 403, "提交后普通用户不能改"
    assert c.patch(f"/api/records/{rid}", json={"fields": {"净重": "1"}},
                   headers={"X-Portal-User": "zhangsan"}).status_code == 403, "0.1 版接口不能成为绕过权限的后门"
    assert c.patch(f"/api/v1/records/{rid}", json={"fields": {"净重": "30160"}},
                   headers={"X-Portal-User": "rong"}).status_code == 200


def test_editing_an_approved_record_requires_reapproval(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160")])
    rid = up(c).json()["records"][0]["id"]
    H = {"X-Portal-User": "rong"}
    c.post(f"/api/v1/records/{rid}/submit", json={}, headers=H)
    c.post("/api/v1/records/approve", json={"ids": [rid]}, headers=H)
    r = c.patch(f"/api/v1/records/{rid}", json={"fields": {"净重": "30100", "总重": "48480"}}, headers=H).json()
    assert (r["stage"], r["approved_by"]) == ("submitted", None), "改了已审核的单据,必须重新审核"


def test_reconciliation_and_excel_with_images(tmp_path):
    svc, c = make(tmp_path, [F("粤B·12345", "2026-10-10", "08:10", "08:30", "48540", "18380", "30160"),
                             F("粤B12345", "2026-10-10", "09:42", "09:50", "48100", "18380", "29720"),
                             F("粤B99999", "2026-10-10", "10:00", "10:20", "20000", "10000", "10000")])
    up_confirmed(c, "supplier_out"); up_confirmed(c, "site_in"); up_confirmed(c, "supplier_out")
    d = c.get("/api/v1/reconciliation?date_from=2026-10-10&date_to=2026-10-10").json()["days"][0]
    # 日合计:当天加工厂全部车 − 当天比亚迪全部车(客户手工表是反方向,数值相同);配对另列
    assert (d["supplier_count"], d["supplier_net"], d["site_count"], d["site_net"], d["diff"]) == (2, 40160, 1, 29720, -10440)
    assert (d["trucks"], d["unmatched"]) == (1, 1)
    assert d["pairs"][0]["diff"] == -440 and d["pairs"][0]["diff_alert"] is True and d["pairs"][0]["gap_min"] == 72
    assert d["pairs"][0]["supplier"]["crop_path"].startswith("/files/images/"), "穿透要能看到两边影像"

    x = c.get("/api/v1/export.xlsx?kind=reconciliation&ticket_from=2026-10-10&ticket_to=2026-10-10")
    assert x.status_code == 200 and x.headers["content-type"].startswith("application/vnd.openxmlformats")
    wb = load_workbook(io.BytesIO(x.content))
    assert wb.sheetnames == ["月度磅差汇总表", "每车磅差明细", "没配上的"]
    ws = wb["月度磅差汇总表"]
    assert ws["A1"].value == "比亚迪&新岚月度磅差汇总表" and [ws.cell(3, i).value for i in range(3, 6)] == ["总总重", "总空重", "总净重"]
    assert [ws.cell(4, i).value for i in range(2, 12)] == ["2026-10-10", 68540, 28380, 40160, 48100, 18380, 29720,
                                                           -20440, -10000, -10440]
    assert len(wb["每车磅差明细"]._images) == 2 and len(wb["没配上的"]._images) == 1 and len(ws._images) == 0

    y = load_workbook(io.BytesIO(c.get("/api/v1/export.xlsx?kind=supplier_out").content))
    assert y.sheetnames == ["月度出厂汇总表", "10月10日"], "照客户台账:月度汇总 + 每天一张"
    day = y["10月10日"]
    assert day["A1"].value == "比亚迪循环废钢出厂过磅信息记录表" and day["A2"].value == "日期：10月10日"
    assert [cc.value for cc in day[3]][:12] == ["序号", "磅单号", "入站时间", "出站时间", "车牌号", "货名", "装点",
                                                 "总重", "空重", "净重", "监磅员", "备注"]
    assert len(day._images) == 2 and day.cell(4, 10).value == 30160, "净重是数值"
    assert [day.cell(6, i).value for i in (1, 2, 8, 10)] == [3, "合计", 68540, 40160]


def test_site_out_keeps_customer(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160")])
    r = up(c, "site_out", customer="湛江钢铁").json()["records"][0]
    assert (r["doc_type_label"], r["customer"]) == ("产成品出库", "湛江钢铁")
    assert c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
                  data={"doc_type": "dock"}).status_code == 422, "码头不做;未知类型拒收"


def test_capture_link_works_without_login_and_is_fenced(tmp_path):
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:20", "48540", "18380", "30160"),
                             F("粤B2", "2026-10-10", "09:00", "09:20", "48540", "18380", "30160")],
                  capture_links={"tok-supplier": {"label": "比亚迪现场", "doc_type": "supplier_out"}}, reviewers=["rong"])
    assert c.get("/c/tok-supplier").status_code == 200 and c.get("/c/wrong").status_code == 404
    r = c.post("/api/v1/capture/tok-supplier/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
               data={"name": "李四", "doc_type": "site_in"}).json()["records"][0]
    assert r["doc_type"] == "supplier_out", "链接固定了类型,页面传什么都按链接来"
    assert r["uploader"] == "李四(比亚迪现场)"
    assert r["crop_path"].startswith("/api/v1/capture/tok-supplier/files/images/")
    assert c.get(r["crop_path"]).status_code == 200, "不登录也能看到自己刚拍的单据"
    assert c.get("/api/v1/capture/tok-supplier/files/ledger.db").status_code == 404
    other = up(c, user="rong").json()["records"][0]["id"]
    assert c.post(f"/api/v1/capture/tok-supplier/records/{other}/submit", json={}).status_code == 404, "只能提交本链接传的"
    s = c.post(f"/api/v1/capture/tok-supplier/records/{r['id']}/submit", json={"fields": {"货名": "冲压边角料"}}).json()
    assert s["stage"] == "submitted"
    assert c.post(f"/api/v1/capture/tok-supplier/records/{r['id']}/submit",
                  json={"fields": {"净重": "1"}}).status_code == 403, "提交后现场不能再改,要找审核员"


def test_capture_links_are_secret_in_manifest(tmp_path):
    svc, c = make(tmp_path, [], capture_links={"sekret-token": {"label": "x"}})
    assert "sekret-token" not in c.get("/api/v1/manifest").text


def test_thresholds_editable_by_reviewers_and_persisted(tmp_path):
    recs = [F("粤B1", "2026-10-10", "08:10", "08:30", "18000", "10000", "8000"),
            F("粤B1", "2026-10-10", "09:42", "09:50", "18090", "10000", "8090")]
    svc, c = make(tmp_path, recs, reviewers=["rong"], diff_alert_pct=1.0)
    up_confirmed(c, "supplier_out"); up_confirmed(c, "site_in")
    pair = lambda: c.get("/api/v1/reconciliation").json()["days"][0]["pairs"][0]
    assert pair()["diff_alert"] is True and pair()["diff"] == 90
    r = c.put("/api/v1/settings/thresholds", json={"diff_alert_kg": 100}, headers={"X-Portal-User": "zhangsan"})
    assert r.status_code == 403, "监磅员不能改阈值"
    assert c.put("/api/v1/settings/thresholds", json={"diff_alert_pct": "abc"}, headers={"X-Portal-User": "rong"}).status_code == 422
    assert c.put("/api/v1/settings/thresholds", json={"nope": 1}, headers={"X-Portal-User": "rong"}).status_code == 422
    r = c.put("/api/v1/settings/thresholds", json={"diff_alert_kg": 100, "diff_alert_pct": 0.8}, headers={"X-Portal-User": "rong"})
    assert r.status_code == 200 and r.json()["diff_alert_kg"] == 100
    assert pair()["diff_alert"] is False, "改完立刻生效"
    assert c.get("/api/v1/reconciliation").json()["params"]["diff_alert_pct"] == 0.8
    # 重启(重新装配)后仍是改过的值:存在数据目录,不改 config.json
    svc2, c2 = make(tmp_path, [], reviewers=["rong"], diff_alert_pct=1.0)
    assert c2.get("/api/v1/settings/thresholds").json()["diff_alert_kg"] == 100
    assert c2.get("/api/v1/stats").json()["params"]["diff_alert_kg"] == 100
