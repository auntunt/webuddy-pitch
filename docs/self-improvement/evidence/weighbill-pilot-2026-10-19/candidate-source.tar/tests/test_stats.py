# -*- coding: utf-8 -*-
"""统计看板:口径与会议一致——按磅单日期、按净重、失败单不计吨位,磅差只看比亚迪 ↔ 加工厂。"""
from __future__ import annotations

from weighbill.reconcile import reconcile
from weighbill.stats import summarize
from tests.test_reconcile import rec
from tests.test_workflow import F, make, up


def _data():
    supplier = [rec("粤B1", "2026-10-10", "07:50", "08:30", "20000", model="m"),
           rec("粤B1", "2026-10-10", "12:00", "13:00", "19000", model="m", reviewed_by="荣经理"),
           rec("粤B2", "2026-10-10", "08:10", "08:40", "15000"),
           rec("粤B3", "2026-10-11", "09:00", "09:30", None, status="failed", model="m")]
    site = [rec("粤B1", "2026-10-10", "09:42", "09:50", "20250"),
             rec("粤B1", "2026-10-10", "14:00", "14:10", "18990"),
             rec("粤B2", "2026-10-10", "09:20", "09:30", "15000")]
    prod = [rec("鄂A1", "2026-10-11", None, "10:56", "32180", customer="湛江钢铁"),
            rec("鄂A2", "2026-10-11", None, "11:10", "33090", customer="广富源")]
    return supplier, site, prod


def test_totals_days_and_recon_follow_meeting_rules():
    supplier, site, prod = _data()
    s = summarize({"supplier_out": supplier, "site_in": site, "site_out": prod}, reconcile(supplier, site))
    k = s["kinds"]
    assert (k["supplier_out"]["tickets"], k["supplier_out"]["net"], k["supplier_out"]["trucks"], k["supplier_out"]["failed"]) == (4, 54000, 2, 1), \
        "识别失败的单据计张数、不计吨位和车辆"
    assert (k["site_in"]["net"], k["site_out"]["net"], k["site_out"]["trucks"]) == (54240, 65270, 2)

    days = {d["date"]: d for d in s["days"]}
    assert set(days) == {"2026-10-10", "2026-10-11"}
    d10, d11 = days["2026-10-10"], days["2026-10-11"]
    assert (d10["supplier_out_net"], d10["site_in_net"], d10["diff"], d10["pairs"]) == (54000, 54240, 240, 3)
    assert (d11["site_out_net"], d11["site_out_tickets"]) == (65270, 2)
    assert d11["diff"] is None, "产成品出库只采集,不算磅差"

    r = s["recon"]
    assert (r["pairs"], r["diff"], r["pair_sum"]) == (3, 240, 240)
    assert sum(b["n"] for b in r["bins"]) == 3
    assert [b["n"] for b in r["bins"] if b["label"] in ("-50 ~ 0", "0", "≥ 200")] == [1, 1, 1]
    assert [w["diff"] for w in r["worst"]] == [250, -10, 0], "按绝对值从大到小"
    assert r["alerts"] == 1 and r["within_alert"] == 2
    assert r["gap_min"] == {"n": 3, "min": 40, "p50": 60, "p90": 72, "max": 72}
    pts = {p["supplier_id"]: p for p in r["points"]}
    assert pts[supplier[0].id]["minute"] == 8 * 60 + 30 and pts[supplier[0].id]["gap_min"] == 72


def test_vehicles_hours_mix_quality():
    supplier, site, prod = _data()
    s = summarize({"supplier_out": supplier, "site_in": site, "site_out": prod}, reconcile(supplier, site))
    v = {x["plate"]: x for x in s["vehicles"]}
    assert s["vehicles"][0]["plate"] == "粤B1"
    assert (v["粤B1"]["supplier_out"], v["粤B1"]["site_in"], v["粤B1"]["net"], v["粤B1"]["diff"], v["粤B1"]["pairs"]) == (2, 2, 39000, 240, 2)
    assert s["hours"]["supplier_out"][8] == 2 and s["hours"]["site_in"][9] == 2 and s["hours"]["site_out"][11] == 1
    assert sum(s["hours"]["supplier_out"]) == 3, "按出站时刻;失败单不计"
    assert [(m["name"], m["net"]) for m in s["mix"]["out_customers"]] == [("广富源", 33090), ("湛江钢铁", 32180)]
    q = s["quality"]
    assert (q["tickets"], q["edited"], q["failed"]) == (3, 1, 1), "只统计拍照识别进来的(有模型名),台账导入的不算"


def test_empty_range_is_not_an_error():
    s = summarize({}, {"days": [], "params": {}})
    assert s["days"] == [] and s["recon"]["pairs"] == 0 and s["recon"]["diff_pct"] is None and s["recon"]["gap_min"] is None


def test_stats_endpoint_uses_ticket_dates(tmp_path):
    svc, c = make(tmp_path, [F("粤B12345", "2026-10-10", "08:10", "08:30", "48540", "18380", "30160"),
                             F("粤B12345", "2026-10-10", "09:42", "09:50", "48100", "18380", "29720"),
                             F("粤B99999", "2026-10-12", "10:00", "10:20", "20000", "10000", "10000")])
    from tests.test_workflow import up_confirmed
    up_confirmed(c, "supplier_out"); up_confirmed(c, "site_in"); up(c, "site_out", customer="湛江钢铁")
    s = c.get("/api/v1/stats?date_from=2026-10-10&date_to=2026-10-10").json()
    assert s["kinds"]["site_out"]["tickets"] == 0, "日期筛选按磅单日期,不按上传时间"
    assert (s["recon"]["pairs"], s["recon"]["diff"]) == (1, -440)
    assert s["kinds"]["supplier_out"]["stages"]["submitted"] == 1
    whole = c.get("/api/v1/stats").json()["kinds"]["site_out"]
    assert (whole["net"], whole["stages"]["draft"], whole["draft_tickets"], whole["draft_net"]) == (0, 1, 1, 10000), \
        "待现场确认的不算进吨位,但审核进度和「另有待确认」里看得到"
    assert s["params"]["site_name"]
    page = c.get("/report").text
    assert 'data-v="stats"' in page and "/api/v1/stats" in page
