# -*- coding: utf-8 -*-
"""预览:列表用缩略图、详情用中图,第一次被看时从原图生成并存下;图片地址不变、浏览器缓存、只放行单据图。"""
from __future__ import annotations

import io

from PIL import Image

from tests.fixtures import photo
from tests.test_workflow import F, make, up


def T():
    return F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")


def test_thumb_and_preview_are_made_on_first_view_and_kept(tmp_path):
    svc, c = make(tmp_path, [T()])
    r = up(c, "site_in").json()["records"][0]
    assert r["thumb_path"].endswith("_r1_t.jpg") and r["preview_path"].endswith("_r1_m.jpg")
    key = r["thumb_path"][len("/files/"):]
    try:
        svc.blobs.open(key); assert False, "还没人看,不应已经有"
    except FileNotFoundError:
        pass
    t = c.get(r["thumb_path"])
    assert t.status_code == 200 and Image.open(io.BytesIO(t.content)).width <= 360
    assert svc.blobs.open(key) == t.content, "做好了存下,下次直接给"
    full = c.get(r["crop_path"]).content
    assert len(t.content) < len(full), "缩略图比原图小"
    m = Image.open(io.BytesIO(c.get(r["preview_path"]).content))
    assert max(m.size) <= 1400


def test_browser_cache_and_304(tmp_path):
    svc, c = make(tmp_path, [T()])
    r = up(c, "site_in").json()["records"][0]
    a = c.get(r["thumb_path"])
    assert "immutable" in a.headers["cache-control"] and a.headers["etag"]
    b = c.get(r["thumb_path"], headers={"If-None-Match": a.headers["etag"]})
    assert b.status_code == 304 and not b.content


def test_only_ticket_images_are_served(tmp_path):
    svc, c = make(tmp_path, [T()])
    up(c, "site_in")
    for bad in ("/files/ledger.db", "/files/images/../ledger.db", "/files/spool/inbox/x.bin", "/files/thresholds.json"):
        assert c.get(bad).status_code == 404, bad


def test_capture_link_previews_are_own_only(tmp_path):
    svc, c = make(tmp_path, [T()], capture_links={"a": {"label": "甲"}, "b": {"label": "乙"}})
    r = c.post("/api/v1/capture/a/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")}).json()["records"][0]
    assert r["thumb_path"].startswith("/api/v1/capture/a/files/images/")
    assert c.get(r["thumb_path"]).status_code == 200
    assert c.get(r["thumb_path"].replace("/capture/a/", "/capture/b/")).status_code == 404
