# -*- coding: utf-8 -*-
"""登记编号:系统发的号,登记时定下,之后不变、不复用(2026-10-14 用户:「做好一个独立编号」)。"""
from __future__ import annotations

import datetime as dt
import re
import sqlite3

from weighbill.adapters.store_sqlite import SQLiteRecordStore
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from tests.test_workflow import F, make, up, CUSTOMER_NAMING

TODAY = dt.date.today().strftime("%Y%m%d")


def T(plate, net):
    return F(plate, "2026-10-11", "09:36", "09:42", str(10000 + int(net)), "10000", str(net))


def test_numbers_are_per_type_per_day_and_use_configured_prefixes(tmp_path):
    svc, c = make(tmp_path, [T("湘A00001", 100), T("湘A00002", 200), T("湘A00003", 300), T("湘A00004", 400)])
    a, b = up(c, "site_in").json()["records"][0], up(c, "site_in").json()["records"][0]
    x, y = up(c, "supplier_out").json()["records"][0], up(c, "site_out", customer="某客户").json()["records"][0]
    assert (a["ref_no"], b["ref_no"]) == (f"RK-{TODAY}-0001", f"RK-{TODAY}-0002"), "客户配置的进场前缀 RK"
    assert x["ref_no"] == f"CC-{TODAY}-0001" and y["ref_no"] == f"CK-{TODAY}-0001", "每类各自从 1 起"


def test_neutral_default_prefixes(tmp_path):
    svc, c = make(tmp_path, [T("湘A00001", 100)], ref_prefixes={})
    assert up(c, "site_in").json()["records"][0]["ref_no"] == f"JC-{TODAY}-0001"


def test_number_never_changes_after_edits_or_type_change(tmp_path):
    svc, c = make(tmp_path, [T("湘A00001", 100)])
    r = up(c, "site_in").json()["records"][0]
    body = {"fields": dict(r["fields"], 车号="湘A00009"), "doc_type": "supplier_out"}
    after = c.patch(f"/api/v1/records/{r['id']}", json=body, headers={"X-Portal-User": "rong"}).json()
    assert after["doc_type"] == "supplier_out" and after["ref_no"] == r["ref_no"], "改字段、改类型,编号都不变"


def test_duplicate_upload_reports_the_existing_number(tmp_path):
    t = T("湘A00001", 100)
    svc, c = make(tmp_path, [t, dict(t)])
    first = up(c, "site_in").json()["records"][0]
    again = up(c, "site_in").json()["records"][0]
    assert again["duplicate"] and again["ref_no"] == first["ref_no"]


def test_failed_recognition_still_gets_a_number(tmp_path):
    from tests.test_workflow import ScriptedVision, TestClient, create_app
    from tests.fixtures import photo
    s = Settings(api_key="k", data_dir=str(tmp_path / "d"), **CUSTOMER_NAMING)
    c = TestClient(create_app(build_service(s, vision=ScriptedVision(seg=[[]], rec=[], sig=[]))))
    r = c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")}, data={"doc_type": "site_in"}).json()["records"][0]
    assert r["status"] == "failed" and re.fullmatch(rf"RK-{TODAY}-\d{{4}}", r["ref_no"]), "传上来就有号,方便说「哪一张没认出来」"


def test_search_by_number(tmp_path):
    svc, c = make(tmp_path, [T("湘A00001", 100), T("湘A00002", 200)])
    up(c, "site_in"); r2 = up(c, "site_in").json()["records"][0]
    hits = c.get(f"/api/v1/records?q={r2['ref_no']}").json()["records"]
    assert [h["id"] for h in hits] == [r2["id"]]


def test_old_records_are_numbered_once_in_registration_order(tmp_path):
    data = tmp_path / "d"; data.mkdir()
    SQLiteRecordStore(data / "ledger.db")
    with sqlite3.connect(data / "ledger.db") as con:
        for i, (t, at) in enumerate([("site_in", "2026-10-11T08:00:00"), ("site_in", "2026-10-11T07:00:00"),
                                     ("supplier_out", "2026-10-12T09:00:00")]):
            con.execute("INSERT INTO records(id, created_at, uploader, batch_id, seq_in_batch, fields, warnings, weight_ok,"
                        " weight_msg, status, doc_type) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (f"old{i}", at, "t", "b", 1, "{}", "[]", 0, "", "auto_ok", t))
    s = Settings(api_key="k", data_dir=str(data), **CUSTOMER_NAMING)
    svc = build_service(s)
    got = {r.id: r.ref_no for r in svc.store.query(__import__("weighbill.ports", fromlist=["RecordQuery"]).RecordQuery())}
    assert got == {"old1": "RK-20261011-0001", "old0": "RK-20261011-0002", "old2": "CC-20261012-0001"}, "按登记先后,登记日期"
    assert build_service(s).ensure_ref_numbers() == 0, "再启动不重发"
    assert {r.id: r.ref_no for r in svc.store.query(__import__("weighbill.ports", fromlist=["RecordQuery"]).RecordQuery())} == got


def test_numbers_in_excel_after_the_customers_own_columns(tmp_path):
    import io
    from openpyxl import load_workbook
    svc, c = make(tmp_path, [F("湘A00001", "2026-10-11", "08:10", "08:30", "18000", "10000", "8000"),
                             F("湘A00001", "2026-10-11", "09:40", "09:50", "18050", "10000", "8050")])
    from tests.test_workflow import up_confirmed
    s_ = up_confirmed(c, "supplier_out"); i_ = up_confirmed(c, "site_in")
    wb = load_workbook(io.BytesIO(c.get("/api/v1/export.xlsx?kind=site_in").content))
    day = wb["10月11日"]
    head = [x.value for x in day[3]]
    assert head[-6:] == ["磅单图片", "审核状态", "审核人", "登记编号", "来源单位", "来源编号"] and day.cell(4, head.index("登记编号") + 1).value == i_["ref_no"]
    rc = load_workbook(io.BytesIO(c.get("/api/v1/export.xlsx?kind=reconciliation").content))["每车磅差明细"]
    assert [rc.cell(2, 14).value, rc.cell(2, 15).value] == [s_["ref_no"], i_["ref_no"]]


def test_capture_link_duplicate_brief_carries_the_number(tmp_path):
    from tests.fixtures import photo
    t = T("湘A00001", 100)
    svc, c = make(tmp_path, [t, dict(t)], capture_links={"tok": {"label": "现场", "doc_type": "site_in"}})
    first = up(c, "site_in").json()["records"][0]
    c.post("/api/v1/records/approve", json={"ids": [first["id"]]}, headers={"X-Portal-User": "rong"})
    r = c.post("/api/v1/capture/tok/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
               data={"name": "张三"}).json()["records"][0]
    assert r["duplicate"] and r["ref_no"] == first["ref_no"], "现场的人能报出编号去找审核员"
