# -*- coding: utf-8 -*-
"""防丢:照片先落服务器暂存区再回「已收到」,后面任何一步失败都自动重试,不多登记、不少登记。
(2026-10-14 用户:「不能网卡一下就不能上传了……服务器也要有缓存……做很好的数据防丢策略」)"""
from __future__ import annotations

import asyncio
import json

from fastapi.testclient import TestClient

from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.http_api import create_app
from tests.fixtures import CUSTOMER_NAMING, photo
from tests.test_workflow import BOX, F

H = {"X-Portal-User": "zhangsan"}


def T(plate, net, sn):
    return F(plate, "2026-10-10", "08:00", "08:10", str(10000 + net), "10000", str(net), sn=sn)


def make(tmp_path, recs, boxes=None, **kw):
    s = Settings(api_key="k", data_dir=str(tmp_path / "d"), **{**CUSTOMER_NAMING, **kw})
    vision = ScriptedVision(seg=boxes or [BOX] * len(recs), rec=list(recs), sig=[None] * len(recs))
    svc = build_service(s, vision=vision)
    return svc, TestClient(create_app(svc))


def send(c, upload_id, doc_type="site_in"):
    return c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
                  data={"doc_type": doc_type, "upload_id": upload_id}, headers=H)


def count(svc):
    from weighbill.ports import RecordQuery
    return len(svc.store.query(RecordQuery(limit=None, voided="all")))


def test_database_down_upload_is_kept_and_finished_later(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")] * 2)
    real_insert = svc.store.insert

    def down(rec):
        raise ConnectionError("数据库连不上")
    svc.store.insert = down
    r = send(c, "upload-0001")
    assert r.status_code == 202 and r.json()["status"] == "queued", "库挂了照样「已收到」,不是失败"
    assert count(svc) == 0 and svc.spool.get("upload-0001")["status"] == "retry"
    assert svc.health()["checks"]["spool"]["pending"] == 1

    svc.store.insert = real_insert                                       # 库恢复
    for m in svc.spool.due("2999-01-01T00:00:00"):                      # 到点重试
        asyncio.run(svc.process_upload(m["upload_id"]))
    assert count(svc) == 1, "恢复后自动登记,恰好一条"
    st = c.get("/api/v1/uploads/upload-0001", headers=H).json()
    assert st["status"] == "done" and st["records"][0]["fields"]["车号"] == "粤B1"


def test_phone_retry_with_same_upload_id_registers_once(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")] * 3)
    a = send(c, "upload-0002").json()["records"]
    b = send(c, "upload-0002").json()["records"]                        # 手机没收到回应,原样重发
    assert [x["id"] for x in a] == [x["id"] for x in b] and count(svc) == 1
    assert b[0]["ref_no"] == a[0]["ref_no"]


def test_crash_between_two_tickets_of_one_photo_does_not_duplicate(tmp_path):
    recs = [T("粤B1", 1000, "GZD26101000000001"), T("粤B2", 2000, "GZD26101000000002")]
    svc, c = make(tmp_path, recs * 2, boxes=[BOX * 2, BOX * 2])
    real_insert, n = svc.store.insert, {"k": 0}

    def second_fails(rec):
        n["k"] += 1
        if n["k"] == 2:
            raise ConnectionError("写第二张时断了")
        real_insert(rec)
    svc.store.insert = second_fails
    assert send(c, "upload-0003").status_code == 202
    assert count(svc) == 1, "第一张已经写进去了"
    first = svc.store.query(__import__("weighbill.ports", fromlist=["RecordQuery"]).RecordQuery(limit=None))[0]
    svc.store.insert = real_insert
    asyncio.run(svc.process_upload("upload-0003"))
    assert count(svc) == 2, "补上第二张,第一张不重复"
    again = svc.store.get(first.id)
    assert again.ref_no == first.ref_no, "第一张的登记编号没被重发"
    assert sorted(r.fields["车号"] for r, _ in svc.upload_result(svc.spool.get("upload-0003"))) == ["粤B1", "粤B2"]


def test_pending_uploads_survive_a_restart(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    svc.store.insert = lambda rec: (_ for _ in ()).throw(ConnectionError("库连不上"))
    assert send(c, "upload-0004").status_code == 202
    svc2, c2 = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])  # 重启:新进程、新服务
    import datetime as _dt
    svc2.clock = lambda: _dt.datetime(2030, 1, 1, 9, 0, 0)               # 补处理在很久以后
    m = svc2.spool.get("upload-0004")
    svc2.spool.update("upload-0004", next_at="2000-01-01T00:00:00")
    assert asyncio.run(svc2.drain_spool()) == 1 and count(svc2) == 1, "重启前没处理完的,重启后接着处理"
    assert m["received_at"] and svc2.store.query(__import__("weighbill.ports", fromlist=["RecordQuery"]).RecordQuery())[0].created_at == m["received_at"], \
        "登记时间按收到照片的时刻,不按补处理的时刻"


def test_slow_recognition_returns_received_then_finishes_in_background(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")], spool_sync_wait=1)
    real = svc.vision.segment

    async def slow(im):
        await asyncio.sleep(2)
        return await real(im)
    svc.vision.segment = slow
    with c:                                                              # 进 lifespan:后台处理在跑
        r = send(c, "upload-0005")
        assert r.status_code == 202
        import time
        for _ in range(50):
            if svc.spool.get("upload-0005")["status"] == "done":
                break
            time.sleep(0.1)
    assert svc.spool.get("upload-0005")["status"] == "done" and count(svc) == 1


def test_broken_photo_is_rejected_not_retried_forever(tmp_path):
    svc, c = make(tmp_path, [])
    r = c.post("/api/v1/records", files={"photo": ("a.jpg", b"not an image", "image/jpeg")},
               data={"doc_type": "site_in", "upload_id": "upload-0006"}, headers=H)
    assert r.status_code == 422 and svc.spool.get("upload-0006")["status"] == "rejected"
    assert svc.spool.due("2999-01-01T00:00:00") == [] and svc.health()["checks"]["spool"]["rejected"] == 1


def test_spool_files_are_complete_or_absent(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")])
    send(c, "upload-0007")
    root = svc.spool.root
    assert not list(root.rglob(".*.tmp")), "没有留下写了一半的临时文件"
    done = json.loads((root / "done" / "upload-0007.json").read_text("utf-8"))
    assert (root / "done" / "upload-0007.bin").read_bytes() == photo(1) and done["status"] == "done"


def test_other_people_cannot_read_my_upload_status(tmp_path):
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")], reviewers=["rong"])
    send(c, "upload-0008")
    assert c.get("/api/v1/uploads/upload-0008", headers={"X-Portal-User": "lisi"}).status_code == 404
    assert c.get("/api/v1/uploads/upload-0008", headers={"X-Portal-User": "rong"}).status_code == 200


def test_a_truncated_retry_never_overwrites_the_photo_already_received(tmp_path):
    """手机重发时网断了一半,第二份是残的:暂存区里已经收好的那份不能被它盖掉。"""
    svc, c = make(tmp_path, [T("粤B1", 1000, "GZD26101000000001")] * 2)
    svc.store.insert = lambda rec: (_ for _ in ()).throw(ConnectionError("库连不上"))
    assert send(c, "upload-0009").status_code == 202
    r = c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1)[:500], "image/jpeg")},
               data={"doc_type": "site_in", "upload_id": "upload-0009"}, headers=H)
    assert r.status_code == 202
    assert svc.spool.raw("upload-0009") == photo(1), "第一次完整收到的照片原样保留"


def test_transient_ocr_failure_remains_queued_until_recovery(tmp_path):
    svc, c = make(tmp_path, [T('粤B12345', 1000, 'GZD26101000000001')])
    original = svc.vision.segment
    async def down(im):
        raise ConnectionError('OCR temporarily unavailable')
    svc.vision.segment = down
    response = send(c, 'ocr-retry-001')
    assert response.status_code == 202
    assert svc.spool.get('ocr-retry-001')['status'] == 'retry'
    assert count(svc) == 0
    svc.vision.segment = original
    asyncio.run(svc.process_upload('ocr-retry-001'))
    assert count(svc) == 1
    assert svc.spool.get('ocr-retry-001')['status'] == 'done'


def test_two_spool_instances_keep_metadata_and_photo_together(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from weighbill.spool import Spool
    a, b = Spool(tmp_path / 'shared'), Spool(tmp_path / 'shared')
    def put(i):
        return (a if i % 2 else b).put('same-upload', str(i).encode(), {'uploader': str(i)})
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(put, range(40)))
    assert sum(created for _, created in results) == 1
    assert a.raw('same-upload') == a.get('same-upload')['uploader'].encode()


def test_spool_recovers_photo_after_interrupted_move(tmp_path):
    from weighbill.spool import Spool
    import os
    spool = Spool(tmp_path / 'shared')
    spool.put('move-crash-01', b'original', {'uploader': 'a'})
    os.replace(spool.inbox / 'move-crash-01.bin', spool.done / 'move-crash-01.bin')
    assert Spool(tmp_path / 'shared').raw('move-crash-01') == b'original'
    spool.finish('move-crash-01', ['record'])
    assert spool.raw('move-crash-01') == b'original'


def test_reusing_another_upload_id_cannot_read_their_photo(tmp_path):
    svc, c = make(tmp_path, [T('粤B12345', 1000, 'GZD26101000000001')])
    assert send(c, 'private-upload-01').status_code == 201
    response = c.post('/api/v1/records', files={'photo': ('a.jpg',photo(1),'image/jpeg')},
                      data={'upload_id':'private-upload-01'}, headers={'X-Portal-User':'other'})
    assert response.status_code == 409
    assert 'records' not in response.json()


def test_cross_node_upload_id_is_scoped_to_source_and_photo(tmp_path):
    # Independent spools, shared store and blobs: a guessed upload ID cannot alias another record.
    a, _ = make(tmp_path/'a', [T('粤B12345',1000,'GZD26101000000001')])
    b, _ = make(tmp_path/'b', [T('粤B54321',2000,'GZD26101000000002')])
    b.store, b.blobs = a.store, a.blobs
    ra = asyncio.run(a.ingest_detailed(photo(1),'a',upload_id='shared-id-001'))[0][0]
    rb = asyncio.run(b.ingest_detailed(photo(1),'b',upload_id='shared-id-001'))[0][0]
    assert ra.id != rb.id and ra.orig_key != rb.orig_key
    assert rb.uploader == 'b' and rb.fields['净重'] == '2000'


def test_status_never_reports_done_if_registration_was_lost(tmp_path):
    from tests.test_verify import lose_record
    svc, c = make(tmp_path, [T('粤B12345',1000,'GZD26101000000001')]*2)
    response = send(c, 'lost-receipt-01')
    rid = response.json()['records'][0]['id']
    lose_record(svc, rid)
    status = c.get('/api/v1/uploads/lost-receipt-01',headers=H).json()
    assert status['status'] == 'received' and not status['records']
    asyncio.run(svc.process_upload('lost-receipt-01'))
    assert c.get('/api/v1/uploads/lost-receipt-01',headers=H).json()['status'] == 'done'
