# -*- coding: utf-8 -*-
"""可选:把整套测试搬到私有部署的目标栈上跑(OceanBase + S3 对象存储),不改任何用例。

    WB_TEST_STACK=ob+s3 WB_OB=host:port:user@tenant:pw WB_S3_ENDPOINT=… WB_S3_KEY=… WB_S3_SECRET=… pytest

开了以后,凡是配置成 sqlite / local 的服务,台账改建在 OceanBase(每个数据目录一个新库)、图片改存对象存储
(每个数据目录一个新桶)。同一个数据目录的两个服务实例(多节点用例)落到同一个库和桶,和真实部署一样。
跑完把建的库和桶都删掉。不开就什么都不做。
"""
from __future__ import annotations

import hashlib
import os

import pytest

STACK = os.environ.get("WB_TEST_STACK", "")


def _ob():
    host, port, user, pw = os.environ["WB_OB"].split(":", 3)
    return host, int(port), user, pw


if STACK == "ob+s3":
    from weighbill import adapters as _adapters

    _real_build = _adapters.build
    _made = {"dbs": set(), "buckets": set()}

    def _tag(settings) -> str:
        return hashlib.sha1(str(settings.data_path.resolve()).encode()).hexdigest()[:12]

    def _build(port, settings):
        if port == "record_store" and settings.record_store == "sqlite":
            import pymysql
            from weighbill.adapters.store_oceanbase import OceanBaseRecordStore
            host, p, user, pw = _ob()
            name = "wbs_" + _tag(settings)
            if name not in _made["dbs"]:
                c = pymysql.connect(host=host, port=p, user=user, password=pw)
                c.cursor().execute(f"CREATE DATABASE IF NOT EXISTS {name}"); c.close()
                _made["dbs"].add(name)
            return OceanBaseRecordStore(host, p, user, pw, name)
        if port == "blob_store" and settings.blob_store == "local":
            import boto3
            from weighbill.adapters.blob_s3 import S3BlobStore
            name = "wbs-" + _tag(settings)
            if name not in _made["buckets"]:
                s3 = boto3.client("s3", endpoint_url=os.environ["WB_S3_ENDPOINT"], aws_access_key_id=os.environ["WB_S3_KEY"],
                                  aws_secret_access_key=os.environ["WB_S3_SECRET"], region_name="us-east-1")
                try:
                    s3.create_bucket(Bucket=name)
                except s3.exceptions.BucketAlreadyOwnedByYou:
                    pass
                _made["buckets"].add(name)
            return S3BlobStore(os.environ["WB_S3_ENDPOINT"], os.environ["WB_S3_KEY"], os.environ["WB_S3_SECRET"], name,
                               cache_dir=settings.data_path / "blob-cache")
        return _real_build(port, settings)

    _adapters.build = _build

    @pytest.fixture(scope="session", autouse=True)
    def _cleanup_stack():
        yield
        import boto3, pymysql
        host, p, user, pw = _ob()
        c = pymysql.connect(host=host, port=p, user=user, password=pw)
        for name in _made["dbs"]:
            c.cursor().execute(f"DROP DATABASE IF EXISTS {name}")
        c.close()
        s3 = boto3.client("s3", endpoint_url=os.environ["WB_S3_ENDPOINT"], aws_access_key_id=os.environ["WB_S3_KEY"],
                          aws_secret_access_key=os.environ["WB_S3_SECRET"], region_name="us-east-1")
        for b in _made["buckets"]:
            for o in s3.list_objects_v2(Bucket=b).get("Contents", []):
                s3.delete_object(Bucket=b, Key=o["Key"])
            s3.delete_bucket(Bucket=b)


# 这些用例本身就是在查本机文件(与 0.1 版逐字节比落盘、本地库文件不可下载、直接往 SQLite 文件里写老数据),
# 换成数据库 + 对象存储后没有对应的本机文件可查——跳过并写明原因,不是功能不通过。
LOCAL_ONLY = ("tests/test_equivalence.py", "test_ledger_db_is_not_downloadable",
              "test_old_records_are_numbered_once_in_registration_order")


def pytest_collection_modifyitems(config, items):
    if not STACK:
        return
    skip = pytest.mark.skip(reason=f"查的是本机文件,目标栈 {STACK} 上不适用")
    for it in items:
        if any(k in it.nodeid for k in LOCAL_ONLY):
            it.add_marker(skip)


def pytest_report_header(config):
    return f"目标栈: {STACK or 'sqlite + 本地盘(默认)'}"
