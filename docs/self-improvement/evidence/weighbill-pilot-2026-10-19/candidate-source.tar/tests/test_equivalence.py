# -*- coding: utf-8 -*-
"""重构等价性:0.1 版 app.py 与 0.2 子系统,喂同一份模型原始输出,比对

  1. 每条记录的业务字段(fields/warnings/weight/status/model/error/seq)
  2. 落盘的原图、单据图、签名图,逐字节
  3. 模型调用序列:(模型, 提示词种类, 送入图片的尺寸与像素哈希)——增强与否、
     用哪个模型、调用先后,任何一项变了这里都会红

有意的行为差异不在这里,见 test_intended_differences.py。
"""
from __future__ import annotations

import asyncio, datetime, hashlib, importlib.util, json, shutil
from collections import deque
from pathlib import Path

import pytest

from weighbill import prompts
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from tests.fixtures import photo

LEGACY_SRC = Path(__file__).parent / "_legacy" / "app_v01.py"
def KIND(prompt):
    """按内容认调用种类:0.1 版与 0.2 版提示词原文不同,但特征词两版都有。"""
    if "三行重量" in prompt: return "weights"
    if "字段" in prompt: return "rec"
    if "若干张" in prompt: return "seg"
    if "签名" in prompt: return "sig"
    raise AssertionError("认不出的提示词: " + prompt[:30])


class ModelScript:
    """两边共用的「模型」:按提示词种类出队原始文本,并记录每次调用。"""
    def __init__(self, seg, rec, sig, weights=()):
        self.q = {"seg": deque(seg), "rec": deque(rec), "sig": deque(sig), "weights": deque(weights)}
        self.calls = []

    async def __call__(self, model, prompt, im):
        kind = KIND(prompt)
        self.calls.append((model, kind, im.size, hashlib.md5(im.tobytes()).hexdigest()))
        if kind == "weights" and not self.q[kind]:
            return "null"                               # 没安排复读结果 = 复读帮不上忙
        item = self.q[kind].popleft()
        if isinstance(item, BaseException):
            raise item
        return item


def run_legacy(tmp: Path, raw: bytes, script: ModelScript):
    d = tmp / "legacy"; d.mkdir(parents=True)
    shutil.copy(LEGACY_SRC, d / "app.py")
    (d / "static").mkdir()                          # 旧版导入时挂载同目录 static/
    spec = importlib.util.spec_from_file_location(f"legacy_app_{id(script)}", d / "app.py")
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    mod.llm = lambda client, model, prompt, im: script(model, prompt, im)
    recs = asyncio.run(mod.process_upload(raw, "tester"))
    return recs, mod.DATA


def run_new(tmp: Path, raw: bytes, script: ModelScript):
    s = Settings(api_key="k", data_dir=str(tmp / "new"))
    svc = build_service(s)
    svc.vision._chat = script                         # 只替换最底层的网络调用,提示词/增强/解析走真代码
    recs = asyncio.run(svc.ingest(raw, "tester"))
    return recs, svc


def blob(data_root: Path, key):
    return None if key is None else (data_root / key).read_bytes()


BIZ = ("seq_in_batch", "fields", "warnings", "weight_ok", "weight_msg", "status", "model", "error", "uploader")


def compare(tmp, raw, seg, rec, sig):
    a_script, b_script = ModelScript(seg, rec, sig), ModelScript(seg, rec, sig)
    old, old_root = run_legacy(tmp, raw, a_script)
    new, svc = run_new(tmp, raw, b_script)

    # 0.1 版没有重量复读;复读帮不上忙时,除了多出的复读调用,其余必须与 0.1 版逐项一致
    assert a_script.calls == [c for c in b_script.calls if c[1] != "weights"], "模型调用序列不一致"
    assert len(old) == len(new), f"记录条数 旧{len(old)} 新{len(new)}"
    for o, n in zip(old, new):
        o_biz = {k: (json.loads(o[k]) if k in ("fields", "warnings") else o[k]) for k in BIZ}
        n_biz = {k: getattr(n, k) for k in BIZ}
        # 0.3.1 新增的台账列(装点/监磅员/供应商/备注)旧版没有:识别不出就是空,其余逐字段一致
        added = {k: n_biz["fields"].pop(k, None) for k in ("装点", "监磅员", "供应商", "备注")}
        assert added == {k: None for k in added}, f"新增列在旧格式输入下应为空: {added}"
        assert o_biz == n_biz
        for ok, nk in (("orig_path", n.orig_key), ("crop_path", n.crop_key), ("sig_path", n.sig_key)):
            assert (o[ok] is None) == (nk is None), f"{ok} 有无不一致"
            if ok == "orig_path":
                assert blob(svc.settings.data_path, nk) == raw, "原图必须保留上传字节(有意修复旧版重编码)"
            else:
                assert blob(old_root, o[ok]) == blob(svc.settings.data_path, nk), f"{ok} 字节不一致"
    return old, new, a_script.calls


FIELDS_OK = {"客户名": "华东建材", "序号": "20260922031", "日期": "2026-09-22", "入站时间": "08:15",
             "出站时间": "09:02", "车号": "苏A38756", "货名": "河砂", "收费": "120",
             "总重": "38560", "皮重": "12340", "净重": "26220"}


# 一张照片里的第二张单:另一辆车、另一个单号(「双张」用例测的是框的单位换算,两张得是不同的单)
FIELDS_OK_2 = dict(FIELDS_OK, 序号="20260922032", 车号="苏A38757", 总重="38660", 净重="26320")


def rec_text(fields=FIELDS_OK, sig=None):
    return "```json\n" + json.dumps({**fields, "签名框": sig}, ensure_ascii=False) + "\n```"


BOX1 = [{"x": 3.8, "y": 7.7, "w": 90.0, "h": 84.5}]
BOX2_1000 = [{"x": 37, "y": 77, "w": 445, "h": 845}, {"x": 525, "y": 77, "w": 445, "h": 845}]
BOX2_MIXED = [{"x": 37, "y": 77, "w": 44, "h": 84}, {"x": 525, "y": 77, "w": 44, "h": 84}]

CASES = {
    "单张_百分比框_签名附带框成功": (1, [json.dumps(BOX1)], [rec_text(sig={"x": 35, "y": 80, "w": 30, "h": 10})], []),
    "单张_签名框缺失_专项定位成功": (1, [json.dumps(BOX1)], [rec_text(sig=None)], [json.dumps({"x": 35, "y": 80, "w": 30, "h": 10})]),
    "单张_专项定位抛错": (1, [json.dumps(BOX1)], [rec_text(sig=None)], [RuntimeError("upstream 502")]),
    "单张_签名0到1000坐标": (1, [json.dumps(BOX1)], [rec_text(sig={"x": 350, "y": 800, "w": 300, "h": 100})], []),
    "双张_0到1000框": (2, [json.dumps(BOX2_1000)], [rec_text(), rec_text(FIELDS_OK_2)], ["null", "null"]),
    "双张_同框混用单位": (2, [json.dumps(BOX2_MIXED)], [rec_text(), rec_text(FIELDS_OK_2)], ["null", "null"]),
    "分割返回空数组": (1, ["[]"], [], []),
    "字段触发校验警告与重量不符": (1, [json.dumps(BOX1)], [rec_text(dict(FIELDS_OK, 车号="苏AO8756", 入站时间="10:00", 出站时间="09:00", 净重="1"))], ["null"]),
    "识别给出全空字段": (1, [json.dumps(BOX1)], [rec_text({k: "" for k in FIELDS_OK})], ["null"]),
}


@pytest.mark.parametrize("name", list(CASES))
def test_equivalent(tmp_path, name):
    n, seg, rec, sig = CASES[name]
    old, new, calls = compare(tmp_path, photo(n, seed=len(name)), seg, rec, sig)
    assert calls, "脚本没有被调用——等价比对是空转"


def test_cases_cover_every_outcome(tmp_path):
    """防止用例集在修改中悄悄退化成只测好路径。"""
    seen = set()
    for name, (n, seg, rec, sig) in CASES.items():
        _, new, _ = compare(tmp_path / name, photo(n, seed=len(name)), seg, rec, sig)
        for r in new:
            seen.add(r.status)
            seen.add("有签名" if r.sig_key else "无签名")
    assert {"auto_ok", "needs_review", "failed", "有签名", "无签名"} <= seen, seen
