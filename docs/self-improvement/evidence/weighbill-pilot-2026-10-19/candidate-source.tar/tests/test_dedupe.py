# -*- coding: utf-8 -*-
"""同一张磅单传两次只登记一次(2026-10-14 用户:「很标准的正确性需求」)。
两个方向都要守:同一张不能登记两条;不同的两张(尤其同一辆车连跑两趟、单号只差一个字)绝不能并成一条。"""
from __future__ import annotations

from weighbill.domain import same_ticket
from tests.test_workflow import F, make, up

A = {"序号": "CZD26101110064142889", "车号": "湘EC5529", "净重": "9930", "总重": "26390", "皮重": "16460",
     "入站时间": "09:36:27", "出站时间": "09:42:34"}


def test_rule_same_ticket_variants():
    assert same_ticket(A, dict(A)), "完全一样"
    assert same_ticket(A, dict(A, 序号="CZD26101110064142B89")), "单号读错一个字,其余都一样"
    assert same_ticket(A, dict(A, 序号=None, 车号="湘EC5529")), "单号没读出来,车号+净重+时间一样"
    assert same_ticket(A, dict(A, 序号=None, 车号=None)), "单号车号都没读出来,三个重量一样"
    assert same_ticket(A, dict(A, 车号="湘E05529")), "单号一样,车号读错——仍是同一张"


def test_rule_never_merges_different_tickets():
    second_trip = dict(A, 序号="CZD26101110064142888", 净重="9930", 入站时间="13:10:02", 出站时间="13:16:40")
    assert not same_ticket(A, second_trip), "同一辆车第二趟:单号只差一个字、净重碰巧一样,但时间不同"
    assert not same_ticket(A, dict(A, 序号="CZD26101110064142888", 车号="湘EC5530")), "相邻单号、另一辆车"
    assert not same_ticket(A, dict(A, 序号=None, 出站时间="15:00:00", 入站时间="14:50:00")), "无单号、时间不同"
    only_net = {"序号": "CZD26101110064142889", "净重": "9930"}
    assert not same_ticket(only_net, {"序号": "CZD26101110064142888", "净重": "9930"}), \
        "相邻单号、只读出净重(整数吨的净重很常见):一样对得上的不够两样,不合并"
    assert not same_ticket(A, dict(A, 序号="CZD99999999999999999", 车号="粤B12345", 净重="1000")), "单号不同"
    assert not same_ticket(A, dict(A, 车号="粤B12345", 净重="1000")), "单号一样但车号净重全对不上:读错了别处,不合并"


def test_second_upload_of_same_ticket_is_not_registered_again(tmp_path):
    t = F("湘EC5529", "2026-10-11", "09:36", "09:42", "26390", "16460", "9930")
    svc, c = make(tmp_path, [t, dict(t)])
    first = up(c, "site_in").json()["records"]
    again = up(c, "site_in").json()["records"]
    assert first[0]["duplicate"] is None
    assert again[0]["duplicate"] and again[0]["id"] == first[0]["id"], "返回已有那条,告诉上传的人"
    assert len(c.get("/api/v1/records?doc_type=site_in").json()["records"]) == 1, "台账里只有一条"


def test_same_ticket_cut_twice_from_one_photo_is_one_record(tmp_path):
    from tests.test_workflow import BOX, ScriptedVision, Settings, build_service, create_app, TestClient, CUSTOMER_NAMING
    from tests.fixtures import photo
    t = F("湘EC5529", "2026-10-11", "09:36", "09:42", "26390", "16460", "9930")
    s = Settings(api_key="k", data_dir=str(tmp_path / "d"), **CUSTOMER_NAMING)
    svc = build_service(s, vision=ScriptedVision(seg=[BOX * 2], rec=[t, dict(t)], sig=[None, None]))
    c = TestClient(create_app(svc))
    recs = c.post("/api/v1/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")}, data={"doc_type": "site_in"}).json()["records"]
    assert [r["duplicate"] is None for r in recs] == [True, False]
    assert len(c.get("/api/v1/records").json()["records"]) == 1


def test_different_doc_types_are_not_compared(tmp_path):
    t = F("湘EC5529", "2026-10-11", "09:36", "09:42", "26390", "16460", "9930")
    svc, c = make(tmp_path, [t, dict(t)])
    up(c, "supplier_out")
    assert up(c, "site_in").json()["records"][0]["duplicate"] is None, "厂商出厂单和进场单本来就成对,不是重复"


def test_capture_link_gets_only_a_brief_of_someone_elses_record(tmp_path):
    t = F("湘EC5529", "2026-10-11", "09:36", "09:42", "26390", "16460", "9930")
    svc, c = make(tmp_path, [t, dict(t)], capture_links={"tok": {"label": "现场", "doc_type": "site_in"}})
    first = up(c, "site_in", user="rong").json()["records"][0]
    c.post("/api/v1/records/approve", json={"ids": [first["id"]]}, headers={"X-Portal-User": "rong"})
    from tests.fixtures import photo
    r = c.post("/api/v1/capture/tok/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")},
               data={"name": "张三"}).json()["records"][0]
    assert r["duplicate"] and r["uploader"] == "rong"
    assert "crop_path" not in r and "orig_path" not in r and set(r["fields"]) == {"车号", "净重", "序号"}


def test_reshoot_that_misreads_the_date_is_still_caught(tmp_path):
    """重拍时把日期读错了一天之外(实测出现过):按「最近上传」也要找得到。"""
    t = F("湘EC5529", "2026-10-11", "09:36", "09:42", "26390", "16460", "9930")
    svc, c = make(tmp_path, [t, dict(t, 日期="2026-10-17")])
    first = up(c, "site_in").json()["records"][0]
    again = up(c, "site_in").json()["records"][0]
    assert again["duplicate"] and again["id"] == first["id"]


def test_someone_elses_unapproved_record_cannot_block_a_real_ticket(tmp_path):
    """占号攻击(安全审计复现):现场链接把自己草稿的单号改成下一个号并提交,真单子来了不能被吞掉。"""
    from tests.fixtures import photo
    fake = F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")
    real = F("粤B9", "2026-10-10", "09:00", "09:10", "30000", "10000", "20000", sn="GZD26101000000099")
    svc, c = make(tmp_path, [fake, real], capture_links={"tok": {"label": "B", "doc_type": "site_in"}})
    r = c.post("/api/v1/capture/tok/records", files={"photo": ("a.jpg", photo(1), "image/jpeg")}, data={"name": "mallory"}).json()["records"][0]
    c.post(f"/api/v1/capture/tok/records/{r['id']}/submit", json={"fields": {"序号": "GZD26101000000099"}})
    got = up(c, "site_in", user="weigher-a").json()["records"][0]
    assert got["duplicate"] is None and got["fields"]["车号"] == "粤B9", "真单子照样登记"
    assert any("疑似与" in w for w in got["warnings"]), "并标成疑似重复,交审核员核对"


def test_same_truck_on_another_day_is_a_different_ticket():
    a = dict(A, 日期="2026-09-20", 序号="JC26092000003")
    b = dict(A, 日期="2026-10-05", 序号="JC26100500011")
    assert not same_ticket(a, b), "两个号都读出来且明显不同 = 两张单(数据审计复现:新单被当成重复吞掉)"
    assert not same_ticket(dict(a, 序号=None), dict(b, 序号=None)), "号没读出来时,日期不同也不算同一张"
    assert same_ticket(dict(A, 净重="17,200"), dict(A, 净重="17200")) , "重量按数比"
