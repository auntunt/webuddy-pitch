# -*- coding: utf-8 -*-
"""测试用图:只需要真实的「纸+表格线+墨迹」,文字内容由脚本化的模型给出。"""
from __future__ import annotations

import io, random
from PIL import Image, ImageDraw


def receipt(w=700, h=930, seed=0) -> Image.Image:
    rnd = random.Random(seed)
    im = Image.new("RGB", (w, h), (252, 251, 246))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, w - 1, h - 1], outline=(190, 185, 175), width=3)
    for i in range(12):                                  # 表格横线
        y = int(h * (0.12 + i * 0.062))
        d.line([(w * 0.07, y), (w * 0.93, y)], fill=(200, 196, 188), width=2)
        for j in range(rnd.randint(4, 9)):               # 印刷字样的小块
            x = int(w * 0.34) + j * 22
            d.rectangle([x, y - 26, x + 14, y - 8], fill=(30, 30, 60))
    sy = int(h * 0.86)                                   # 签名墨迹
    pts = [(w * 0.40, sy), (w * 0.44, sy - h * 0.035), (w * 0.47, sy), (w * 0.51, sy - h * 0.03),
           (w * 0.55, sy - h * 0.004), (w * 0.59, sy - h * 0.033), (w * 0.64, sy - h * 0.006)]
    d.line(pts, fill=(25, 25, 110), width=5, joint="curve")
    return im


def photo(n=1, seed=0) -> bytes:
    """n 张单据平铺在灰色桌面上,返回 JPEG 字节。"""
    W = 80 + n * 780
    bg = Image.new("RGB", (W, 1100), (198, 194, 186))
    for i in range(n):
        bg.paste(receipt(seed=seed + i), (60 + i * 780, 85))
    buf = io.BytesIO(); bg.save(buf, "JPEG", quality=92)
    return buf.getvalue()


# 当前客户(2026-10 试点)的叫法。产品代码里不写这些,客户的 config.json 里配;
# 测 Excel 版式与客户线下台账逐格一致的用例用它。
CUSTOMER_NAMING = dict(
    supplier_name="比亚迪", site_name="新岚",
    doc_labels={"supplier_out": "比亚迪出厂", "site_in": "原材料入库", "site_out": "产成品出库"},
    doc_titles={"supplier_out": "比亚迪循环废钢出厂过磅信息记录表", "site_in": "循环废钢原材料入库过磅信息记录表",
                "site_out": "循环废钢产成品出库过磅信息记录表"},
    summary_titles={"supplier_out": "比亚迪循环废钢{m}月份出厂汇总表", "site_in": "循环废钢原材料{m}月份入库汇总表",
                    "site_out": "循环废钢{m}月份产成品出库汇总表"},
    doc_notes={"supplier_out": "说明：1、如实记录，信息准确清晰，一车一磅单一记录，不得涂改；2、装点填写以下信息：1#厂房、2#厂房、"
                               "10#厂房、11#厂房、19#厂房、20#厂房；3、如遇异常情况，及时上报并在备注栏记录。"},
    summary_sheets={"supplier_out": "月度出厂汇总表", "site_in": "月度原材料入库汇总表", "site_out": "月度产成品出库汇总表"},
    out_sheet_suffix="（{customer}出船）",
    customers=["广富源", "湛江钢铁"],
    ref_prefixes={"site_in": "RK"},
)
