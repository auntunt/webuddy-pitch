# -*- coding: utf-8 -*-
"""跨服务器查重:两台节点同一秒识别到同一张单,只能登记一条。
两个互不相干的服务实例指向同一份数据(进程内的东西互相看不见),A 在「查完重、还没写」时故意停住,B 这时来登记同一张。"""
from __future__ import annotations

import asyncio, threading, time

from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.ports import RecordQuery
from tests.fixtures import CUSTOMER_NAMING, photo
from tests.test_workflow import BOX, F

TICKET = F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000", sn="GZD26101000000001")


def node(data, **kw):
    s = Settings(api_key="k", data_dir=str(data), **{**CUSTOMER_NAMING, **kw})
    return build_service(s, vision=ScriptedVision(seg=[BOX], rec=[dict(TICKET)], sig=[None]))


def race(a, b):
    """A 写库前停 0.8 秒(这时它已经查完重);B 在这 0.8 秒里登记同一张。返回库里最后有几条。"""
    real = a.store.insert
    def slow(rec):
        time.sleep(0.8); real(rec)
    a.store.insert = slow
    out = {}
    ta = threading.Thread(target=lambda: out.setdefault("a", asyncio.run(a.ingest_detailed(photo(1), "现场甲", "site_in"))))
    tb = threading.Thread(target=lambda: out.setdefault("b", asyncio.run(b.ingest_detailed(photo(1), "现场乙", "site_in"))))
    ta.start(); time.sleep(0.3); tb.start(); ta.join(); tb.join()
    return out, len(a.store.query(RecordQuery(limit=None)))


def test_two_servers_same_ticket_same_moment(tmp_path):
    a, b = node(tmp_path), node(tmp_path)
    out, n = race(a, b)
    # 两个人传的、第一条还没审核:按「不挡别人」的规则(防占号)登记第二条,但必须标疑似重复交审核员——
    # 没有锁时 B 根本看不见 A 那条,会悄悄登记成两条干净的记录
    assert n == 2 and [w for w in out["b"][0][0].warnings if "疑似与" in w], "B 看得见 A 刚登记的那条"


def test_same_person_on_two_servers_registers_once(tmp_path):
    """同一个人(同一条链接)的重传被两台节点同时处理:只登记一条。"""
    a, b = node(tmp_path), node(tmp_path)
    real = a.store.insert
    a.store.insert = lambda rec: (time.sleep(0.8), real(rec))[1]
    out = {}
    ta = threading.Thread(target=lambda: out.setdefault("a", asyncio.run(a.ingest_detailed(photo(1), "现场甲", "site_in"))))
    tb = threading.Thread(target=lambda: out.setdefault("b", asyncio.run(b.ingest_detailed(photo(1), "现场甲", "site_in"))))
    ta.start(); time.sleep(0.3); tb.start(); ta.join(); tb.join()
    assert len(a.store.query(RecordQuery(limit=None))) == 1
    assert out["b"][0][1], "B 返回的是「已登记过」"
