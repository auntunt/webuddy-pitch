# -*- coding: utf-8 -*-
"""迁移:台账、图片(含预览)、修改记录、设置原样搬过去;可反复跑、断了接着跑;最后逐条逐字节核对。"""
from __future__ import annotations

import asyncio, json

import pytest

from weighbill import migrate as M
from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.ports import RecordQuery
from tests.fixtures import CUSTOMER_NAMING, photo
from tests.test_workflow import BOX, F

H = {"X-Portal-User": "rong"}


def svc_at(path, recs=(), **kw):
    s = Settings(api_key="k", data_dir=str(path), **{**CUSTOMER_NAMING, **kw})
    return build_service(s, vision=ScriptedVision(seg=[BOX] * len(recs), rec=list(recs), sig=[None] * len(recs)))


def T(plate, net, sn, date="2026-10-10"):
    return F(plate, date, "08:00", "08:10", str(10000 + net), "10000", str(net), sn=sn)


@pytest.fixture
def source(tmp_path):
    """一套「用过一阵」的试点数据:两类单据配上对、有修改记录、有作废、有疑问、生成过预览、阈值存在老文件里。"""
    recs = [T("粤B1", 1000, "GZD26101000000001"), T("粤B1", 1010, "GZD26101000000002"),
            T("粤B2", 2000, "GZD26101000000003"), T("粤B3", 3000, "GZD26101000000004")]
    s = svc_at(tmp_path / "src", recs)
    a = asyncio.run(s.ingest(photo(1), "现场", "supplier_out", submit=True))[0]
    b = asyncio.run(s.ingest(photo(2), "现场", "site_in", submit=True))[0]
    c = asyncio.run(s.ingest(photo(3), "现场", "site_in", submit=True))[0]
    d = asyncio.run(s.ingest(photo(1), "现场", "site_out", "某客户", submit=True))[0]
    s.review(b.id, {"备注": "核过纸单"}, "rong")
    s.approve([a.id, b.id], "rong", True)
    s.void(c.id, "rong", "拍错了", True)
    s.flag(d.id, "rong", "纸单找不到", True)
    s.image(s.blobs.url(a.crop_key)[len("/files/"):].replace("_r1.jpg", "_r1_t.jpg"))   # 生成过缩略图
    (s.settings.data_path / "thresholds.json").write_text(json.dumps({"diff_alert_pct": 2.5}), "utf-8")
    return s


def test_full_migration_is_exact(tmp_path, source):
    dst = svc_at(tmp_path / "dst")
    rep = M.migrate(source, dst)
    assert rep.ok, rep.as_dict()
    assert (rep.records_total, rep.records_copied) == (4, 4) and rep.history_rows_copied >= 4
    for r in source.store.query(RecordQuery(limit=None, voided="all")):
        t = dst.store.get(r.id)
        assert (t.ref_no, t.stage, t.voided_at, t.flag_note, t.fields) == (r.ref_no, r.stage, r.voided_at, r.flag_note, r.fields)
        assert dst.history(r.id) == source.history(r.id)
    a = [r for r in source.store.query(RecordQuery(limit=None)) if r.doc_type == "supplier_out"][0]
    thumb = a.crop_key.replace("_r1.jpg", "_r1_t.jpg")
    assert dst.blobs.open(thumb) == source.blobs.open(thumb), "生成过的预览图也搬过去"
    assert dst.thresholds()["diff_alert_pct"] == 2.5, "老版本存在文件里的阈值也搬过去"
    assert rep.checks["reconciliation"]["ok"] and rep.checks["totals"]["ok"]


def test_rerun_copies_nothing(tmp_path, source):
    dst = svc_at(tmp_path / "dst")
    M.migrate(source, dst)
    rep = M.migrate(source, dst)
    assert rep.ok and (rep.records_copied, rep.images_copied, rep.history_rows_copied) == (0, 0, 0)


def test_interrupted_migration_resumes_without_duplicates(tmp_path, source):
    dst = svc_at(tmp_path / "dst")
    with pytest.raises(RuntimeError):
        M.migrate(source, dst, stop_after=2)                    # 搬到第 3 条时断了
    assert len(dst.store.query(RecordQuery(limit=None, voided="all"))) == 2
    rep = M.migrate(source, dst)
    assert rep.ok and rep.records_copied == 2 and rep.records_already == 2
    for r in source.store.query(RecordQuery(limit=None, voided="all")):
        assert len(dst.history(r.id)) == len(source.history(r.id)), "修改记录不重复"


def test_refuses_while_source_has_unprocessed_photos(tmp_path, source):
    source.accept_upload(photo(2), "pending-0001", "现场", "site_in", None, None)
    rep = M.migrate(source, svc_at(tmp_path / "dst"))
    assert not rep.ok and rep.problems[0]["kind"] == "source_spool_pending"
    assert rep.records_copied == 0


def test_new_tickets_after_migration_do_not_collide(tmp_path, source):
    dst = svc_at(tmp_path / "dst", [T("粤B9", 900, "GZD26101000000099")])
    M.migrate(source, dst)
    old = {r.ref_no for r in dst.store.query(RecordQuery(limit=None, voided="all"))}
    new = asyncio.run(dst.ingest(photo(1), "现场", "site_in"))[0]
    assert new.ref_no not in old, (new.ref_no, old)


def test_dry_run_writes_nothing(tmp_path, source):
    dst = svc_at(tmp_path / "dst")
    rep = M.migrate(source, dst, dry_run=True)
    assert rep.records_copied == 4 and dst.store.query(RecordQuery(limit=None, voided="all")) == []


def test_verify_catches_a_tampered_image(tmp_path, source):
    dst = svc_at(tmp_path / "dst")
    M.migrate(source, dst)
    r = source.store.query(RecordQuery(limit=None))[0]
    dst.blobs.put(r.crop_key, b"\xff\xd8broken", "image/jpeg")
    rep = M.verify_into(M.Report(), source, dst)
    assert not rep.ok and rep.checks["images"]["mismatch"][0]["key"] == r.crop_key


def test_cli(tmp_path, source, capsys):
    from weighbill import cli
    (tmp_path / "src.json").write_text(json.dumps({**CUSTOMER_NAMING, "data_dir": str(source.settings.data_path)}), "utf-8")
    (tmp_path / "dst.json").write_text(json.dumps({**CUSTOMER_NAMING, "data_dir": str(tmp_path / "cli-dst")}), "utf-8")
    assert cli.main(["migrate", "--source-config", str(tmp_path / "src.json"), "--target-config", str(tmp_path / "dst.json")]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["ok"] and out["records_copied"] == 4
