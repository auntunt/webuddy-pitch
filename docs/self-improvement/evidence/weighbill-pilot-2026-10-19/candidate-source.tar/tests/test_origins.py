"""Business provenance is independent of ticket type and authenticated upload channel."""
import io
import sqlite3
import pytest
from openpyxl import load_workbook
from tests.test_workflow import F, make
from tests.fixtures import photo
from tests.test_reconcile import rec, pairs
from weighbill.reconcile import reconcile
from weighbill.adapters.store_sqlite import SQLiteRecordStore
from weighbill.ports import RecordQuery

ORIGINS = [{"id": "legacy", "name": "来源甲", "enabled": True},
           {"id": "mill_b", "name": "来源乙", "enabled": True}]
def ticket():
    return F("湘A12345", "2026-10-11", "08:00", "08:10", "18000", "10000", "8000")
def upload(c, origin, kind="supplier_out", route="/api/v1/records", **kw):
    return c.post(route, files={"photo": ("a.jpg", photo(1), "image/jpeg")},
                  data={"doc_type": kind, "origin_id": origin, "name": "现场", **kw}, headers={"X-Portal-User": "rong"})

def test_same_number_in_two_origins_is_not_a_duplicate(tmp_path):
    t = ticket()
    svc, c = make(tmp_path, [dict(t) for _ in range(3)], origins=ORIGINS)
    a = upload(c, "legacy").json()["records"][0]
    b = upload(c, "mill_b").json()["records"][0]
    again = upload(c, "mill_b").json()["records"][0]
    assert a["id"] != b["id"] and b["duplicate"] is None
    assert again["duplicate"] and again["id"] == b["id"]
    assert c.get("/api/v1/records?origin_id=mill_b").json()["count"] == 1
    for r in (a, b):
        assert c.post(f"/api/v1/records/{r['id']}/submit", json={}, headers={"X-Portal-User":"rong"}).status_code == 200
    assert c.get("/api/v1/stats?origin_id=mill_b").json()["kinds"]["supplier_out"]["tickets"] == 1
    response = c.get("/api/v1/export.xlsx?kind=supplier_out&origin_id=mill_b")
    assert response.status_code == 200
    wb = load_workbook(io.BytesIO(response.content)); day = wb["10月11日"]
    headers = [v.value for v in day[3]]
    assert day.cell(4, headers.index("来源编号")+1).value == "mill_b"
    assert day.cell(4, headers.index("来源单位")+1).value == "来源乙"
    assert len(day._images) == 1

def test_pairing_and_plate_correction_do_not_cross_origins(tmp_path):
    a = rec("湘A12345", "2026-10-11", "08:00", "08:10", "8000", origin_id="legacy")
    b = rec("湘A12345", "2026-10-11", "09:00", "09:10", "8010", origin_id="mill_b")
    assert pairs(reconcile([a], [b])) == []
    b.origin_id = "legacy"
    assert pairs(reconcile([a], [b])) == [(a.id, b.id)]
    svc, c = make(tmp_path, [ticket()], origins=ORIGINS)
    upload(c, "legacy")
    fields = {"车号":"湘A12346", "日期":"2026-10-11"}
    assert svc._snap_plate(fields, "mill_b") is None and fields["车号"] == "湘A12346"
    assert svc._snap_plate(fields, "legacy") and fields["车号"] == "湘A12345"

def test_multiple_sources_require_choice_and_outbound_stays_unassigned(tmp_path):
    svc, c = make(tmp_path, [ticket()], origins=ORIGINS)
    assert upload(c, "").status_code == 422
    assert upload(c, "missing").status_code == 422
    r = upload(c, "", "site_out").json()["records"][0]
    assert r["origin_id"] == ""

def test_capture_link_pins_origin_and_review_keeps_audit(tmp_path):
    svc, c = make(tmp_path, [ticket()], origins=ORIGINS,
                  capture_links={"tok":{"label":"乙现场", "doc_type":"supplier_out", "origin_id":"mill_b"}})
    r = upload(c, "legacy", route="/api/v1/capture/tok/records").json()["records"][0]
    assert r["origin_id"] == "mill_b"
    got = c.post(f"/api/v1/capture/tok/records/{r['id']}/submit", json={"origin_id":"legacy"})
    assert got.status_code == 200 and got.json()["origin_id"] == "mill_b"
    c.post("/api/v1/records/approve",json={"ids":[r["id"]]}, headers={"X-Portal-User":"rong"})
    edited = c.patch(f"/api/v1/records/{r['id']}",json={"origin_id":"legacy"},headers={"X-Portal-User":"rong"})
    assert edited.status_code == 200
    assert edited.json()["stage"] == "submitted" and edited.json()["ref_no"] == r["ref_no"]
    assert any("来源单位" in str(h) for h in svc.history(r["id"]))

def test_legacy_database_backfill_keeps_ids_and_outbound_unknown(tmp_path):
    db = tmp_path / "old.db"
    store = SQLiteRecordStore(db)
    for kind in ("supplier_out", "site_in", "site_out"):
        r = rec("湘A12345", "2026-10-11", "08:00", "08:10", "8000",doc_type=kind,ref_no=kind)
        store.insert(r)
    with sqlite3.connect(db) as con:
        con.execute("DROP INDEX idx_origin_type")
        con.execute("ALTER TABLE records DROP COLUMN origin_id")
    migrated = SQLiteRecordStore(db)
    rows = migrated.query(RecordQuery(limit=None))
    assert {r.ref_no:r.origin_id for r in rows} == {"supplier_out":"legacy","site_in":"legacy","site_out":""}
    assert len({r.id for r in rows}) == 3

def test_spool_origin_survives_retry_and_disabled_catalog(tmp_path):
    svc, c = make(tmp_path, [ticket()], origins=ORIGINS)
    meta, created = svc.accept_upload(photo(1), "a"*32, "rong", "supplier_out", None, None, "mill_b")
    assert created and meta["origin_id"] == "mill_b"
    svc.settings.origins = [dict(o, enabled=o["id"]!="mill_b") for o in ORIGINS]
    meta, created = svc.accept_upload(photo(1), "a"*32, "rong", "supplier_out", None, None)
    assert not created and meta["origin_id"] == "mill_b"
    assert upload(c,"mill_b").status_code == 422

def test_migration_requires_matching_catalog_before_copying(tmp_path):
    from weighbill.migrate import migrate
    src, c = make(tmp_path / 'src', [ticket()], origins=ORIGINS)
    r = upload(c, "mill_b").json()["records"][0]
    dst, _ = make(tmp_path / 'dst', [], origins=[ORIGINS[0]])
    report = migrate(src, dst)
    assert not report.ok and report.problems[0]['kind'] == 'origin_catalog_mismatch'
    assert dst.store.get(r['id']) is None
    dst.settings.origins = ORIGINS
    assert migrate(src, dst).ok
    assert dst.store.get(r['id']).origin_id == 'mill_b'
