"""The source photo and exported media must survive byte-for-byte."""
import io
import zipfile

import pytest
from PIL import Image
from openpyxl import load_workbook

from tests.test_workflow import F, make
from weighbill.blob_keys import variant_key, variant_of, is_image_key
from weighbill.export_xlsx import ExportImageError, _thumb


@pytest.mark.parametrize('fmt,extension,mime', [('JPEG','jpg','image/jpeg'), ('PNG','png','image/png'), ('WEBP','webp','image/webp')])
def test_original_download_preserves_uploaded_file(tmp_path, fmt, extension, mime):
    buf = io.BytesIO()
    Image.new('RGB', (3100, 2100), '#918273').save(buf, fmt)
    raw = buf.getvalue()
    svc, client = make(tmp_path, [F('粤B12345','2026-10-10','08:00','08:10','11000','10000','1000')])
    response = client.post('/api/v1/records', files={'photo': ('photo.'+extension, raw, mime)})
    assert response.status_code == 201
    rec = response.json()['records'][0]
    full = client.get(rec['orig_path'])
    assert full.content == raw
    assert full.headers['content-type'] == mime
    key = rec['orig_path'].removeprefix('/files/')
    preview = variant_key(key, 't')
    assert is_image_key(preview) and variant_of(preview) == (key, 't')
    assert client.get('/files/' + preview).status_code == 200
    if fmt == 'WEBP':
        # openpyxl would transcode WebP silently; refuse instead.
        assert client.get('/api/v1/export.xlsx?kind=site_in').status_code == 503
        return
    exported = client.get('/api/v1/export.xlsx?kind=site_in')
    assert exported.status_code == 200
    with zipfile.ZipFile(io.BytesIO(exported.content)) as archive:
        media = [archive.read(k) for k in archive.namelist() if k.startswith('xl/media/')]
    assert media == [raw]
    wb = load_workbook(io.BytesIO(exported.content))
    images = [im for ws in wb for im in ws._images]
    assert len(images) == 1 and images[0].width == 3100 and images[0].height == 2100


def test_missing_image_aborts_export_instead_of_omitting(tmp_path):
    svc, client = make(tmp_path, [F('粤B12345','2026-10-10','08:00','08:10','11000','10000','1000')])
    from tests.test_workflow import up
    up(client)
    svc.blobs.open = lambda key: (_ for _ in ()).throw(ConnectionError('offline'))
    response = client.get('/api/v1/export.xlsx?kind=site_in')
    assert response.status_code == 503
    assert response.json()['error']['code'] == 'ExportImageUnavailable'


def test_corrupt_image_is_not_silently_dropped():
    with pytest.raises(ExportImageError):
        _thumb(lambda key: b'broken', 'image.jpg')
