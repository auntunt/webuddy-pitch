# -*- coding: utf-8 -*-
"""读-改-写互不覆盖(数据审计复现:审核和修改同时发生,修改被盖回旧值,而且旧值被审核通过了)。"""
from __future__ import annotations

import threading, time

from tests.test_workflow import F, make, up


def test_edit_during_approve_is_not_lost(tmp_path):
    svc, c = make(tmp_path, [F("鲁A12345", "2026-10-05", "08:50", "09:00", "19900", "10000", "9900")])
    rid = up(c, "site_in").json()["records"][0]["id"]
    real_get, b_done = svc.store.get, threading.Event()

    def b_edits():
        svc.review(rid, {"净重": "9000", "总重": "19000"}, "reviewerB")
        b_done.set()

    def slow_get(x):
        r = real_get(x)
        if threading.current_thread() is main:
            svc.store.get = real_get
            threading.Thread(target=b_edits).start()
            time.sleep(0.3)                        # A 读完还没写:B 这时候来改
            assert not b_done.is_set(), "B 必须等 A 写完再读,不能插到 A 的读和写中间"
        return r
    main = threading.current_thread()
    svc.store.get = slow_get
    svc.approve([rid], "reviewerA", True)
    assert b_done.wait(5)
    r = svc.get(rid)
    assert (r.fields["净重"], r.fields["总重"]) == ("9000", "19000"), "B 的修改留下来了"
    assert r.stage == "submitted", "改了已审核的单据,回到未审核——没有把没核对过的新数字当成已审核"
    assert [h["action"] for h in svc.history(rid)][-2:] == ["审核通过", "修改"]
