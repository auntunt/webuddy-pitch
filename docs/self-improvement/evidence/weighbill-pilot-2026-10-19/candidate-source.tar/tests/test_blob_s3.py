# -*- coding: utf-8 -*-
"""S3 协议对象存储:对真实的服务跑契约。默认跳过;本机起一个 RustFS 再跑:
    docker run -d -p 19000:9000 -e RUSTFS_ACCESS_KEY=… -e RUSTFS_SECRET_KEY=… rustfs/rustfs
    WB_S3_ENDPOINT=http://127.0.0.1:19000 WB_S3_KEY=… WB_S3_SECRET=… pytest tests/test_blob_s3.py
"""
from __future__ import annotations

import itertools, os, uuid

import pytest

from weighbill.testing import contracts

pytestmark = pytest.mark.skipif(not os.environ.get("WB_S3_ENDPOINT"), reason="没配 WB_S3_ENDPOINT(真实对象存储)")


def store(tmp_path, bucket, cache=True):
    from weighbill.adapters.blob_s3 import S3BlobStore
    return S3BlobStore(os.environ["WB_S3_ENDPOINT"], os.environ["WB_S3_KEY"], os.environ["WB_S3_SECRET"], bucket,
                       cache_dir=tmp_path / f"cache-{uuid.uuid4().hex[:6]}" if cache else None, cache_max_mb=1)


@pytest.fixture
def bucket():
    import boto3
    s3 = boto3.client("s3", endpoint_url=os.environ["WB_S3_ENDPOINT"], aws_access_key_id=os.environ["WB_S3_KEY"],
                      aws_secret_access_key=os.environ["WB_S3_SECRET"], region_name="us-east-1")
    name = "wbtest-" + uuid.uuid4().hex[:10]
    s3.create_bucket(Bucket=name)
    yield name
    for o in s3.list_objects_v2(Bucket=name).get("Contents", []):
        s3.delete_object(Bucket=name, Key=o["Key"])
    s3.delete_bucket(Bucket=name)


def test_contract_with_and_without_cache(tmp_path, bucket):
    contracts.check_blob_store(lambda: store(tmp_path, bucket))
    contracts.check_blob_store(lambda: store(tmp_path, bucket, cache=False))


def test_cache_serves_reads_when_storage_blips(tmp_path, bucket):
    b = store(tmp_path, bucket)
    k = "images/20261014/abcdef012345_r1.jpg"
    b.put(k, b"\xff\xd8photo", "image/jpeg")

    class Down:
        def __getattr__(self, name):
            raise ConnectionError("对象存储连不上")
    real, b.s3 = b.s3, Down()
    assert b.open(k) == b"\xff\xd8photo", "看过/刚存的图,对象存储抖一下也照样能看"
    b.s3 = real


def test_cache_is_size_capped(tmp_path, bucket):
    b = store(tmp_path, bucket)                       # 上限 1MB
    for i in range(6):
        b.put(f"images/20261014/abcdef01234{i}_r1.jpg", os.urandom(300 * 1024), "image/jpeg")
    total = sum(f.stat().st_size for f in b.cache_dir.iterdir())
    assert total <= 1024 * 1024, total


def test_whole_app_on_object_storage(tmp_path, bucket):
    """整个上传 → 预览 → 导出,图片全在对象存储里。"""
    import io
    from openpyxl import load_workbook
    from tests.test_workflow import F, make, up
    svc, c = make(tmp_path, [F("粤B1", "2026-10-10", "08:00", "08:10", "11000", "10000", "1000")],
                  blob_store="s3", s3_endpoint=os.environ["WB_S3_ENDPOINT"], s3_access_key=os.environ["WB_S3_KEY"],
                  s3_secret_key=os.environ["WB_S3_SECRET"], s3_bucket=bucket)
    assert svc.health()["checks"]["blob_store"]["ok"]
    r = up(c, "site_in").json()["records"][0]
    assert c.get(r["thumb_path"]).status_code == 200 and c.get(r["crop_path"]).status_code == 200
    assert svc.blobs.exists(r["thumb_path"][len("/files/"):]), "预览图也存进了对象存储"
    wb = load_workbook(io.BytesIO(c.get("/api/v1/export.xlsx?kind=site_in").content))
    assert len(wb["10月10日"]._images) == 1
