"""Execute the actual queue worker in Node, with network/storage failures injected."""
import json
import shutil
import subprocess
from pathlib import Path

import pytest

NODE = shutil.which('node')
ROOT = Path(__file__).parents[1]


@pytest.mark.skipif(not NODE, reason='Node required for browser queue logic test')
@pytest.mark.parametrize('state,response,expected', [
    ('waiting','rejected','rejected'), ('received','rejected','rejected'),
    ('waiting','retry','waiting'), ('waiting','queued','received'),
    ('waiting','done',None), ('received','done',None),
])
def test_queue_keeps_photo_until_registration(state, response, expected):
    html = (ROOT / 'weighbill/static/capture.html').read_text()
    worker = html[html.index('let flushing = false;'):html.index('async function drawOutbox()')]
    script = '''const assert = require('node:assert/strict');
let item = {id:'test-photo',state:STATE,blob:Buffer.from('original-photo')};
const original = item.blob;
const outbox = {all: async()=>item?[item]:[], put: async x=>{item=x}, del: async()=>{item=null}};
const navigator = {onLine:true};
const API='/api/v1';
const fetch=async()=>({ok:true,json:async()=>({status:RESPONSE,records:[{id:'record'}]})});
const sendItem=async()=>({kind:RESPONSE,body:{error:{message:'rejected'}},status:422,records:[{id:'record'}]});
const banner=()=>{},toast=()=>{},loadRecent=()=>{},drawOutbox=()=>{};
''' .replace('STATE',json.dumps(state)).replace('RESPONSE',json.dumps(response))
    script += worker + '\n(async()=>{await flushOutbox();'
    if expected is None:
        script += 'assert.equal(item,null);'
    else:
        script += f'assert.equal(item.state,{json.dumps(expected)});assert.equal(item.blob,original);'
    script += '})().catch(e=>{console.error(e);process.exit(1)});'
    result = subprocess.run([NODE, '-e', script], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


@pytest.mark.skipif(not NODE, reason='Node required for JavaScript syntax check')
def test_frontend_scripts_parse():
    import re
    for filename in ('capture.html','report.html'):
        html = (ROOT / 'weighbill/static' / filename).read_text()
        script = '\n'.join(re.findall(r'<script>(.*?)</script>', html, re.S))
        result = subprocess.run([NODE,'--check'], input=script, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
