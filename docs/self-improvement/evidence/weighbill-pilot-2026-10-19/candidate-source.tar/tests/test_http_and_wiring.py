# -*- coding: utf-8 -*-
"""HTTP 契约与接线。接线测试针对「每个环节都对,组合起来没接上」。"""
from __future__ import annotations

import json, os, subprocess, sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import weighbill.bootstrap as bootstrap
from weighbill import cli
from weighbill.adapters.vision_scripted import ScriptedVision
from weighbill.bootstrap import build_service
from weighbill.config import Settings, load_settings
from weighbill.http_api import create_app
from tests.fixtures import photo

LEGACY_KEYS = {"id", "created_at", "uploader", "batch_id", "seq_in_batch", "orig_path", "crop_path", "sig_path",
               "fields", "warnings", "weight_ok", "weight_msg", "status", "model", "error"}
BOX = [{"x": 3.8, "y": 7.7, "w": 90.0, "h": 84.5}]
FIELDS = {"客户名": "华东建材", "序号": "20260922031", "日期": "2026-09-22", "入站时间": "08:15",
          "出站时间": "09:02", "车号": "苏A38756", "货名": "河砂", "收费": "120",
          "总重": "38560", "皮重": "12340", "净重": "26220"}


def make(tmp_path, n=1, **settings):
    s = Settings(api_key="k", data_dir=str(tmp_path / "data"), **settings)
    v = ScriptedVision(seg=[BOX] * n, rec=[dict(FIELDS, 签名框={"x": 35, "y": 80, "w": 30, "h": 10})] * n,
                       sig=[None] * n)
    svc = build_service(s, vision=v)
    return svc, TestClient(create_app(svc))


def upload(c, path="/api/upload", user=None):
    h = {"X-Portal-User": user.encode("utf-8")} if user else {}
    return c.post(path, files={"photo": ("a.jpg", photo(1), "image/jpeg")}, headers=h)


# ------------------------------------------------------------ 0.1 版接口不变
def test_legacy_upload_shape(tmp_path):
    svc, c = make(tmp_path)
    r = upload(c)
    assert r.status_code == 200
    rec = r.json()["records"][0]
    assert LEGACY_KEYS <= set(rec), f"缺少 0.1 版字段: {LEGACY_KEYS - set(rec)}"
    assert rec["orig_path"].startswith("/files/images/") and rec["status"] == "auto_ok"
    assert c.get(rec["crop_path"]).status_code == 200, "页面引用的图片 URL 必须可访问"


def test_legacy_errors(tmp_path):
    s = Settings(api_key="", data_dir=str(tmp_path / "d"))
    c = TestClient(create_app(build_service(s)))
    r = upload(c)
    assert r.status_code == 500 and r.json()["detail"] == "服务端未配置 LLM_API_KEY(config.json 或环境变量)"
    svc, c = make(tmp_path, max_upload_bytes=100)
    assert upload(c).status_code == 413
    assert c.get("/api/records/nope").status_code == 404
    assert c.get("/api/records/nope").json()["detail"] == "记录不存在"


def test_legacy_review_and_csv(tmp_path):
    svc, c = make(tmp_path)
    rid = upload(c).json()["records"][0]["id"]
    r = c.patch(f"/api/records/{rid}", json={"fields": {"净重": "1", "不存在的键": "x"}},
                headers={"X-Portal-User": "李四".encode("utf-8")})
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "reviewed" and body["fields"]["净重"] == "1" and "不存在的键" not in body["fields"]
    assert body["weight_ok"] == 0 and body["reviewed_by"] == "李四"
    csv = c.get("/api/export.csv")
    assert csv.headers["content-disposition"] == "attachment; filename=weighbill_ledger.csv"
    assert csv.text.startswith("﻿登记时间,上传人,状态,重量校验,客户名")


def test_pages_and_config(tmp_path):
    svc, c = make(tmp_path)
    cap = c.get("/").text
    assert 'const API = TOKEN ? `/api/v1/capture/' in cap and 'x.open("POST", `${API}/records`)' in cap
    rep = c.get("/report").text
    assert '/api/v1/records?' in rep and '/api/v1/records/approve' in rep and '/api/v1/reconciliation?' in rep
    assert c.get("/api/config").json() == {"seg_model": svc.settings.seg_model, "rec_model": svc.settings.rec_model,
                                           "base_url": svc.settings.base_url, "key_set": True}


# ------------------------------------------------------------ 修掉的洞
def test_ledger_db_is_not_downloadable(tmp_path):
    svc, c = make(tmp_path, event_sink="jsonl")
    upload(c)
    assert (svc.settings.data_path / "ledger.db").exists() and (svc.settings.data_path / "events.jsonl").exists()
    assert c.get("/files/ledger.db").status_code == 404
    assert c.get("/files/events.jsonl").status_code == 404
    assert c.get("/files/images/../ledger.db").status_code == 404


def test_utf8_uploader_header(tmp_path):
    svc, c = make(tmp_path)
    assert upload(c, user="张三").json()["records"][0]["uploader"] == "张三"


# ------------------------------------------------------------ v1
def test_v1_create_list_get_review(tmp_path):
    svc, c = make(tmp_path)
    r = upload(c, "/api/v1/records", user="王五")
    assert r.status_code == 201
    rid = r.json()["records"][0]["id"]
    lst = c.get("/api/v1/records").json()
    assert lst["count"] == 1 and lst["records"][0]["id"] == rid
    assert c.get(f"/api/v1/records/{rid}").json()["uploader"] == "王五"
    assert c.patch(f"/api/v1/records/{rid}", json={"fields": {}}).json()["status"] == "reviewed"


def test_v1_error_body(tmp_path):
    svc, c = make(tmp_path)
    r = c.get("/api/v1/records/nope")
    assert r.status_code == 404 and r.json() == {"error": {"code": "RecordNotFound", "message": "记录不存在"}}
    r = c.post("/api/v1/records", files={"photo": ("a.jpg", b"not an image", "image/jpeg")})
    assert r.status_code == 422 and r.json()["error"]["code"] == "InvalidImage"


def test_v1_export_is_not_swallowed_by_record_id_route(tmp_path):
    svc, c = make(tmp_path)
    r = c.get("/api/v1/records/export.csv")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")


def test_v1_health_reports_unconfigured_vision(tmp_path):
    c = TestClient(create_app(build_service(Settings(api_key="", data_dir=str(tmp_path)))))
    h = c.get("/api/v1/health").json()
    assert h["status"] == "degraded" and h["capabilities"]["ingest"] is False and h["capabilities"]["query"] is True
    assert "api_key" not in json.dumps(h)


def test_manifest_has_no_secrets(tmp_path):
    svc, c = make(tmp_path, webhook_secret="topsecret")
    m = c.get("/api/v1/manifest").json()
    assert m["subsystem"] == "weighbill" and "topsecret" not in json.dumps(m) and "k" != m.get("api_key")
    assert m["ports"]["vision"]["available"] == ["cpu_ocr", "openai_compatible"]


# ------------------------------------------------------------ 接线
def test_events_are_actually_emitted(tmp_path):
    svc, c = make(tmp_path, event_sink="jsonl")
    rid = upload(c).json()["records"][0]["id"]
    c.patch(f"/api/records/{rid}", json={"fields": {}}, headers={"X-Portal-User": "rong"})
    evs = [json.loads(l) for l in (svc.settings.data_path / "events.jsonl").read_text("utf-8").splitlines()]
    assert [e["type"] for e in evs] == ["com.weighbill.record.created", "com.weighbill.record.reviewed"]
    assert all(e["specversion"] == "1.0" and e["subject"] == rid for e in evs)
    assert evs[1]["data"]["status"] == "reviewed", "reviewed 事件必须携带复核后的状态,不是复核前"


def test_event_failure_is_visible_not_silent(tmp_path):
    class Broken:
        def publish(self, e): raise ConnectionError("下游挂了")
        def describe(self): return {"adapter": "broken", "delivery": "at-most-once"}
    s = Settings(api_key="k", data_dir=str(tmp_path))
    svc = build_service(s, vision=ScriptedVision(seg=[BOX], rec=[FIELDS], sig=[None]), event_sink=Broken())
    c = TestClient(create_app(svc))
    assert upload(c).status_code == 200, "下游通知失败不应让已入账的记录失败"
    h = c.get("/api/v1/health").json()
    assert h["status"] == "degraded" and h["checks"]["event_sink"]["failed"] == 1
    assert "下游挂了" in h["checks"]["event_sink"]["last_error"]


def test_cli_goes_through_the_single_assembly_point(tmp_path, monkeypatch, capsys):
    calls = []
    real = bootstrap.build_service
    def spy(*a, **k):
        calls.append(1); return real(Settings(api_key="k", data_dir=str(tmp_path)))
    monkeypatch.setattr(bootstrap, "build_service", spy)
    assert cli.main(["health"]) == 0
    assert calls, "CLI 没有走 bootstrap.build_service——出现了第二条装配路径"


def test_http_default_goes_through_the_single_assembly_point(tmp_path, monkeypatch):
    calls = []
    real = bootstrap.build_service
    monkeypatch.setattr("weighbill.http_api.build_service",
                        lambda *a, **k: calls.append(1) or real(Settings(data_dir=str(tmp_path))))
    create_app()
    assert calls


def test_manifest_cli_touches_no_database(tmp_path):
    data = tmp_path / "never-created"
    env = dict(os.environ, WEIGHBILL_DATA_DIR=str(data), WEIGHBILL_CONFIG=str(tmp_path / "none.json"))
    for cmd in (["version"], ["manifest"]):
        r = subprocess.run([sys.executable, "-m", "weighbill", *cmd], env=env, capture_output=True, text=True)
        assert r.returncode == 0, r.stderr
    assert not data.exists(), "version/manifest 不得创建数据目录或数据库"


def test_unknown_adapter_and_config_key_fail_loudly(tmp_path):
    with pytest.raises(ValueError, match="可选"):
        build_service(Settings(data_dir=str(tmp_path), record_store="mysql"))
    cfg = tmp_path / "c.json"; cfg.write_text(json.dumps({"api_kye": "typo"}), "utf-8")
    with pytest.raises(ValueError, match="api_kye"):
        load_settings(env={}, config_path=cfg)
    with pytest.raises(TypeError):
        build_service(Settings(data_dir=str(tmp_path)), visoin=object())


def test_config_precedence_matches_v01(tmp_path):
    cfg = tmp_path / "c.json"; cfg.write_text(json.dumps({"rec_model": "from-file"}), "utf-8")
    s = load_settings(env={"REC_MODEL": "from-env", "SEG_MODEL": "seg-env"}, config_path=cfg)
    assert s.rec_model == "from-file" and s.seg_model == "seg-env", "0.1 版:环境变量 < config.json"


def test_pages_load_only_same_origin_assets(tmp_path):
    """内网私有化部署:页面不得依赖任何外部字体/CDN,引用的本站资源必须都能取到。"""
    import re
    svc, c = make(tmp_path)
    for page in ("/", "/report"):
        html = c.get(page).text
        refs = re.findall(r'(?:href|src)="([^"#]+)"', html)
        external = [u for u in refs if re.match(r"^(https?:)?//", u)]
        assert not external, f"{page} 引用了外部资源: {external}"
        for u in refs:
            if u.startswith("/static/"):
                r = c.get(u)
                assert r.status_code == 200, f"{page} 引用的 {u} 取不到"
                assert r.headers.get("cache-control") == "no-cache", f"{u} 会被浏览器缓存,升级后样式不更新"
        assert any(u.startswith("/static/app.css") for u in refs)
        assert c.get(page).headers.get("cache-control") == "no-cache", "页面必须回源校验,否则升级后看到旧页面"


def test_every_static_file_is_packaged():
    """页面文件得进安装包:漏了的话本地测试全绿(读的是源码目录),装到服务器上却没有(0.7.0 sw.js 就这样被发布检查拦下)。"""
    import fnmatch, re, tomllib
    root = Path(__file__).resolve().parent.parent
    pats = tomllib.loads((root / "pyproject.toml").read_text("utf-8"))["tool"]["setuptools"]["package-data"]["weighbill"]
    files = [p.relative_to(root / "weighbill").as_posix() for p in (root / "weighbill" / "static").iterdir() if p.is_file()]
    missing = [f for f in files if not any(fnmatch.fnmatch(f, pat) for pat in pats)]
    assert missing == [], f"这些页面文件不会进安装包: {missing}"
