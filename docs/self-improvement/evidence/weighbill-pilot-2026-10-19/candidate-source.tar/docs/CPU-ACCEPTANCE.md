# CPU OCR 素材验收

使用本地 RapidOCR / PP-OCRv6 small，经 ONNX Runtime CPUExecutionProvider 运行。脚本在识别前读取三路模型会话的实际执行器；只要不是纯 CPU 就停止。模型文件需事先安装缓存；识别不调用 OpenRouter。

```bash
.venv/bin/python bench/cpu_ocr_acceptance.py \
  --config config.json --data-dir data \
  --output /tmp/weighbill-cpu-acceptance \
  --serial-prefix CZD
```

前缀是该批素材已有地磅的配置，不是通用规则。新地磅必须先确认自己的编号格式；不提供此参数时沿用配置中的 serial_prefixes。不应为追求高分，根据每张真值去改识别结果。

脚本只读已审核、未作废记录，以原图重走切单、识别、重量复读、同来源车牌纠错、查重流程。另建临时SQLite/本地图片库，事件输出关闭。不会覆盖生产记录，也不会改变正式识别模式。

逐项核对车号、总重、空重、净重、磅单号、日期、入站时间、出站时间。人工台账只精确到分钟时只比较分钟；台账含秒时比较秒；台账含日期的时间还核对日期。原始真值与完整识别值均保存在 details.json，不裁掉秒数或改写素材。真值未填写的字段不参与正确率分母。

summary.json 保存整体、字段和单据类型统计；details.json 保存每张素材哈希、尺寸、耗时、所有识别值、真值、错误项和警告。结果含客户信息，应留在本机或指定私有环境，不提交Git。

退出码0表示本批没有未提醒的错误且没有执行异常；退出码2表示未通过这个门槛或没有素材。**这不等于无人审核可用，也不能证明新来源、新票面全都正确。** 仍须对所有非全对项进行人工核对。当前样本是历史回归集，不是独立盲测集；新增来源还需新增已核对样本和盲测。

时延在本机测得，不能当成服务器承诺；正式CPU服务器应运行同一命令复测吞吐和延迟。

## 模型对照

增加 `--profile` 可选：`v6-small`（默认）、`v6-mixed`（small检测＋medium识别）、`v6-medium`（完整medium）、`v5-server`（server检测＋识别）。方向分类器保持相同，以隔离变量。每组使用同样的地磅前缀、样本和业务规则。

每组单独指定输出目录，按顺序运行避免CPU争抢。首次运行会下载官方模型并验证哈希；总耗时可能含下载，比较推理使用 `inference_seconds`、单张耗时中位数和P95。新增的 `peak_rss_mib` 为整个进程峰值常驻内存，不等于部署所需内存上限。

```bash
.venv/bin/python bench/cpu_ocr_acceptance.py --profile v6-mixed --output /tmp/weighbill-v6-mixed --serial-prefix CZD
.venv/bin/python bench/cpu_ocr_acceptance.py --profile v6-medium --output /tmp/weighbill-v6-medium --serial-prefix CZD
.venv/bin/python bench/cpu_ocr_acceptance.py --profile v5-server --output /tmp/weighbill-v5-server --serial-prefix CZD
```

`--ref-no` 可重复传入以定向复测。但车队纠错会使用同批出厂单，子集结果不能直接与全量结果混比。正式比较使用全部102张，并核对各组逐张的原图哈希与真值一致。
