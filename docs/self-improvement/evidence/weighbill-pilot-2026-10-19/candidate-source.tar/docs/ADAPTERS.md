# 接入其他系统：端口与适配器

子系统的业务编排（`service.py`）只依赖 `ports.py` 里的五个协议。接入一个新系统，就是给对应端口写一个适配器。

## 三步接入

1. **写实现**：新建 `weighbill/adapters/<名字>.py`，按 `ports.py` 里该协议的方法与「约定」实现。
2. **登记**：在 `weighbill/adapters/__init__.py` 对应的表里加一行 `"<名字>": lambda s: 你的类(...)`；需要的新配置项加到 `config.py` 的 `Settings`。
3. **过契约**：在测试里调用 `weighbill.testing.contracts` 里对应的检查，然后在 `config.json` 里把配置项改成 `<名字>`。

适配器是**固定清单**，刻意不支持「在配置里写模块路径动态加载」——配置文件不应成为执行任意代码的入口。配置里写了不存在的名字，启动时会报错并列出可选项。

## 五个端口

### VisionModel —— 换模型 / 换 OCR 引擎

```python
async def segment(image) -> list[dict]           # [{"x","y","w","h"}, ...] 推荐百分比 0-100
async def recognize(receipt) -> dict             # domain.FIELDS 的键 + 可选 "签名框"
async def locate_signature(receipt) -> dict|None
def describe() -> dict                            # 含 configured、seg_model、rec_model;不得含密钥
```

- 调用失败就**抛异常**，不要返回空结果。空结果会被当成「看了但没认出」，在台账上与「没调通」无法区分。
- 业务层会用 `imaging.norm_box` 兜底 0–1000 坐标和同框混用单位，但这是兜底，适配器应尽量直接给百分比。
- 不是大模型的 OCR（PaddleOCR、云厂商票据识别等）不需要 `prompts.py`。
- 契约：`contracts.check_vision(适配器实例)` —— 会真的调用一次模型。

内置 `openai_compatible` 覆盖所有兼容 `/v1/chat/completions` + `image_url` 的服务（OpenRouter、vLLM、各家兼容网关）。换模型只改配置，不需要新适配器。

### RecordStore —— 换数据库 / 写到对方系统的库

```python
def insert(record) -> None        # 重复 id 必须抛异常,不得覆盖
def get(id) -> Record | None
def query(RecordQuery) -> list    # created_at 倒序;date_to 含当天 23:59:59;q 在字段值里子串匹配
def update(record) -> None        # 只改可变列;不存在抛 KeyError
def ping() -> None                # 健康检查:要真写一次
```

契约：`contracts.check_record_store(lambda: 你的实现(全新空库))`。

### BlobStore —— 换对象存储（S3 / MinIO / OSS）

```python
def put(key, data, content_type) -> key   # 非法 key(绝对路径、..、反斜杠)必须抛 ValueError
def open(key) -> bytes
def url(key) -> str                       # 调用方可直接访问的地址,对象存储可返回预签名 URL
def ping() -> None
```

契约：`contracts.check_blob_store(lambda: 你的实现(空桶))`。换成非本地存储后，HTTP 层不再挂载 `/files/images`，页面直接使用 `url()` 返回的地址。

### EventSink —— 通知 ERP / 结算 / 消息总线

```python
def publish(event: dict) -> None   # 失败就抛;业务层计数并在 /api/v1/health 报出,不回滚已入账记录
def describe() -> dict             # 必须声明 delivery 语义
```

事件是 **CloudEvents 1.0** 结构化 JSON：

```json
{
  "specversion": "1.0",
  "id": "5f0c…",
  "source": "/weighbill",
  "type": "com.weighbill.record.created",
  "subject": "<记录 id>",
  "time": "2026-09-23T04:41:56+00:00",
  "datacontenttype": "application/json",
  "dataschema": "weighbill/record/0.2.0",
  "data": { "id": "…", "status": "auto_ok", "fields": { "序号": "…" }, "…": "与 GET /api/v1/records/{id} 相同" }
}
```

| type | 何时 |
|---|---|
| `com.weighbill.record.created` | 每条记录入账后（含 failed 记录） |
| `com.weighbill.record.reviewed` | 人工复核保存后；`data` 是复核**后**的记录 |

内置出口：

| 名字 | 投递语义 | 用法 |
|---|---|---|
| `null` | 不投递 | 默认 |
| `jsonl` | 本地落盘即成功 | 对方系统 tail 或定时拉取 `data/events.jsonl` |
| `webhook` | at-most-once，单次不重试 | `webhook_url`；配 `webhook_secret` 时带 `X-Weighbill-Signature: sha256=<HMAC-SHA256(secret, 原始请求体)>` |

契约：`contracts.check_event_sink(工厂, read_back=可选的读回函数)`。

### IdentityResolver —— 换身份来源

```python
def resolve(headers) -> str   # 认不出返回固定匿名标识,不抛;头名大小写不敏感
```

内置 `header` 读 `identity_header`（默认 `X-Portal-User`），会把按 latin-1 解码后的 UTF-8 中文还原。契约：`contracts.check_identity(工厂)`。

## 宿主系统怎么发现本子系统

- `GET /api/v1/manifest` 或 `weighbill manifest`：版本、接口、每个端口的可选与当前适配器、事件类型、记录字段、配置键。**不连库、不联网、不含密钥**，宿主可以在启用之前读它。
- `GET /api/v1/health` 或 `weighbill health`：分端口的可用性与 `capabilities`（ingest / query / review / export 各自是否可用）。模型未配置时 `ingest=false` 但查询照常；`down` 时 HTTP 503、CLI 退出码 1。
- 进程内：`weighbill.bootstrap.build_service()` 返回 `WeighbillService`。**只从这里拿服务**，不要自己 new 适配器再拼一个——两条装配路径迟早会分叉。

## 测试替身

```python
from weighbill.bootstrap import build_service
from weighbill.config import Settings
from weighbill.adapters.vision_scripted import ScriptedVision

svc = build_service(Settings(api_key="x", data_dir=tmp),
                    vision=ScriptedVision(seg=[[{"x": 2, "y": 2, "w": 90, "h": 90}]],
                                          rec=[{"序号": "20260922031"}], sig=[None]))
```

`overrides` 的键只能是端口名（`vision` / `record_store` / `blob_store` / `event_sink` / `identity`），写错会报 `TypeError`。
